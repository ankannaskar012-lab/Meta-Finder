// =========================================================================
    // META FINDER — CORE APPLICATION STATE & UTILITIES
    // =========================================================================
    const state = {
      files: [],
      activeIndex: -1,
      activeTab: 'all',
      searchQuery: '',
      liveStream: null,
      liveGeo: null
    };

    function showToast(message, type = 'info') {
      const container = document.getElementById('toastContainer');
      if (!container) return;
      const el = document.createElement('div');
      const colors = {
        info: 'bg-slate-800 border-sky-500/40 text-sky-200',
        success: 'bg-slate-800 border-emerald-500/40 text-emerald-200',
        warn: 'bg-slate-800 border-amber-500/40 text-amber-200'
      };
      el.className = `px-3.5 py-2.5 rounded-xl border shadow-xl text-xs font-medium transition-all duration-300 pointer-events-auto ${colors[type] || colors.info}`;
      el.textContent = message;
      container.appendChild(el);
      setTimeout(() => {
        el.style.opacity = '0';
        setTimeout(() => el.remove(), 300);
      }, 2800);
    }

    function formatBytes(bytes) {
      if (!bytes || bytes <= 0) return '0 Bytes';
      const k = 1024;
      const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
      const i = Math.min(sizes.length - 1, Math.floor(Math.log(bytes) / Math.log(k)));
      return `${(bytes / Math.pow(k, i)).toFixed(i === 0 ? 0 : 2)} ${sizes[i]} (${bytes.toLocaleString()} B)`;
    }

    function escapeHtml(str) {
      return String(str ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
    }

    function copyTextToClipboard(text, label = 'Copied to clipboard') {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(String(text ?? '')).then(() => showToast(label, 'success')).catch(() => fallbackCopy(String(text ?? ''), label));
      } else {
        fallbackCopy(String(text ?? ''), label);
      }
    }

    function fallbackCopy(text, label) {
      const ta = document.createElement('textarea');
      ta.value = text;
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      try {
        document.execCommand('copy');
        showToast(label, 'success');
      } catch (e) {
        showToast('Copy failed', 'warn');
      }
      ta.remove();
    }

    function triggerDownloadBlob(blob, filename) {
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      a.style.display = 'none';
      document.body.appendChild(a);
      a.click();
      setTimeout(() => {
        a.remove();
        URL.revokeObjectURL(url);
      }, 400);
    }

    // =========================================================================
    // CRYPTOGRAPHIC HASHES (CRC32, MD5, SHA-1, SHA-256) & ENTROPY
    // =========================================================================
    const CRC32_TABLE = (() => {
      const table = new Uint32Array(256);
      for (let i = 0; i < 256; i++) {
        let c = i;
        for (let k = 0; k < 8; k++) {
          c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
        }
        table[i] = c >>> 0;
      }
      return table;
    })();

    function computeCRC32(u8) {
      let crc = 0xFFFFFFFF;
      const limit = Math.min(u8.length, 16 * 1024 * 1024);
      for (let i = 0; i < limit; i++) {
        crc = CRC32_TABLE[(crc ^ u8[i]) & 0xFF] ^ (crc >>> 8);
      }
      return ((crc ^ 0xFFFFFFFF) >>> 0).toString(16).padStart(8, '0').toUpperCase();
    }

    function computeMD5(u8) {
      const sample = u8.length > 8 * 1024 * 1024 ? u8.subarray(0, 8 * 1024 * 1024) : u8;
      function leftRotate(x, c) { return (x << c) | (x >>> (32 - c)); }
      const s = [
        7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22,
        5,  9, 14, 20, 5,  9, 14, 20, 5,  9, 14, 20, 5,  9, 14, 20,
        4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23,
        6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21
      ];
      const K = new Uint32Array(64);
      for (let i = 0; i < 64; i++) K[i] = Math.floor(Math.abs(Math.sin(i + 1)) * 0x100000000) >>> 0;

      const origLen = sample.length;
      const bitLenLow = (origLen * 8) >>> 0;
      const bitLenHigh = Math.floor((origLen * 8) / 0x100000000) >>> 0;
      const padLen = ((56 - (origLen + 1) % 64) + 64) % 64;
      const totalLen = origLen + 1 + padLen + 8;
      const buf = new Uint8Array(totalLen);
      buf.set(sample);
      buf[origLen] = 0x80;
      const dv = new DataView(buf.buffer);
      dv.setUint32(totalLen - 8, bitLenLow, true);
      dv.setUint32(totalLen - 4, bitLenHigh, true);

      let a0 = 0x67452301, b0 = 0xefcdab89, c0 = 0x98badcfe, d0 = 0x10325476;
      const M = new Uint32Array(16);

      for (let offset = 0; offset < totalLen; offset += 64) {
        for (let j = 0; j < 16; j++) M[j] = dv.getUint32(offset + j * 4, true);
        let A = a0, B = b0, C = c0, D = d0;
        for (let i = 0; i < 64; i++) {
          let F, g;
          if (i < 16) { F = (B & C) | ((~B) & D); g = i; }
          else if (i < 32) { F = (D & B) | ((~D) & C); g = (5 * i + 1) % 16; }
          else if (i < 48) { F = B ^ C ^ D; g = (3 * i + 5) % 16; }
          else { F = C ^ (B | (~D)); g = (7 * i) % 16; }
          F = (F + A + K[i] + M[g]) >>> 0;
          A = D;
          D = C;
          C = B;
          B = (B + leftRotate(F, s[i])) >>> 0;
        }
        a0 = (a0 + A) >>> 0;
        b0 = (b0 + B) >>> 0;
        c0 = (c0 + C) >>> 0;
        d0 = (d0 + D) >>> 0;
      }
      const out = new Uint8Array(16);
      const outDv = new DataView(out.buffer);
      outDv.setUint32(0, a0, true);
      outDv.setUint32(4, b0, true);
      outDv.setUint32(8, c0, true);
      outDv.setUint32(12, d0, true);
      const hex = Array.from(out).map(b => b.toString(16).padStart(2, '0')).join('');
      return u8.length > 8 * 1024 * 1024 ? `${hex} (first 8MB)` : hex;
    }

    async function computeWebCryptoHash(alg, buffer) {
      try {
        if (window.crypto && window.crypto.subtle) {
          const hashBuf = await window.crypto.subtle.digest(alg, buffer);
          return Array.from(new Uint8Array(hashBuf)).map(b => b.toString(16).padStart(2, '0')).join('');
        }
      } catch (e) {}
      return 'Unavailable in non-secure context';
    }

    function computeShannonEntropy(u8) {
      if (!u8.length) return { entropy: 0, assessment: 'Empty file', nullBytes: 0, asciiRatio: 0 };
      const counts = new Uint32Array(256);
      let asciiCount = 0;
      const sampleLen = Math.min(u8.length, 512 * 1024);
      for (let i = 0; i < sampleLen; i++) {
        const b = u8[i];
        counts[b]++;
        if ((b >= 32 && b <= 126) || b === 9 || b === 10 || b === 13) asciiCount++;
      }
      let entropy = 0;
      for (let i = 0; i < 256; i++) {
        if (counts[i] > 0) {
          const p = counts[i] / sampleLen;
          entropy -= p * Math.log2(p);
        }
      }
      let assessment = 'Plain Text / Structured Data';
      if (entropy > 7.8) assessment = 'High Entropy (Compressed / Encrypted / Media Stream)';
      else if (entropy > 6.2) assessment = 'Moderate-High Entropy (Binary Container / Packed)';
      else if (entropy > 4.5) assessment = 'Moderate Entropy (Rich Document / Markup / Code)';

      return {
        entropy: Number(entropy.toFixed(4)),
        assessment,
        nullBytes: counts[0],
        asciiRatio: Number(((asciiCount / sampleLen) * 100).toFixed(1))
      };
    }

    // =========================================================================
    // MAGIC BYTE / FILE SIGNATURE DETECTION
    // =========================================================================
    function detectMagicSignature(u8, fileName) {
      const hex4 = Array.from(u8.subarray(0, 4)).map(b => b.toString(16).padStart(2, '0')).join('').toUpperCase();
      const hex8 = Array.from(u8.subarray(0, 8)).map(b => b.toString(16).padStart(2, '0')).join('').toUpperCase();
      const ascii16 = new TextDecoder('latin1').decode(u8.subarray(0, 16));
      const ext = (fileName.split('.').pop() || '').toLowerCase();

      if (hex4.startsWith('FFD8FF')) return { format: 'JPEG Photograph', family: 'image', mime: 'image/jpeg', magicHex: hex4, validExt: ['jpg', 'jpeg', 'jpe', 'jfif'] };
      if (hex8 === '89504E470D0A1A0A') return { format: 'PNG Image', family: 'image', mime: 'image/png', magicHex: hex8, validExt: ['png'] };
      if (ascii16.startsWith('GIF87a') || ascii16.startsWith('GIF89a')) return { format: 'GIF Image', family: 'image', mime: 'image/gif', magicHex: hex8, validExt: ['gif'] };
      if (ascii16.startsWith('RIFF') && ascii16.slice(8, 12) === 'WEBP') return { format: 'WebP Photograph', family: 'image', mime: 'image/webp', magicHex: hex8, validExt: ['webp', 'jpg', 'jpeg'] };
      if (ascii16.startsWith('RIFF') && ascii16.slice(8, 12) === 'WAVE') return { format: 'WAV Audio (RIFF)', family: 'audio', mime: 'audio/wav', magicHex: hex8, validExt: ['wav', 'wave'] };
      if (ascii16.startsWith('RIFF') && ascii16.slice(8, 12) === 'AVI ') return { format: 'AVI Video (RIFF)', family: 'video', mime: 'video/x-msvideo', magicHex: hex8, validExt: ['avi'] };
      if (hex4 === '49492A00' || hex4 === '4D4D002A') return { format: 'TIFF / RAW Photograph', family: 'image', mime: 'image/tiff', magicHex: hex4, validExt: ['tif', 'tiff', 'dng', 'cr2', 'nef', 'arw'] };
      if (hex4.startsWith('424D')) return { format: 'BMP Bitmap Image', family: 'image', mime: 'image/bmp', magicHex: hex4.slice(0, 4), validExt: ['bmp', 'dib'] };
      if (ascii16.startsWith('%PDF-')) return { format: `PDF Document (${ascii16.slice(0, 8)})`, family: 'pdf', mime: 'application/pdf', magicHex: hex8, validExt: ['pdf', 'ai'] };
      if (hex8 === 'D0CF11E0A1B11AE1') return { format: 'OLE2 Compound Document (Legacy DOC/XLS/PPT/MSG)', family: 'ole2', mime: 'application/x-ole-storage', magicHex: hex8, validExt: ['doc', 'xls', 'ppt', 'msg', 'msi', 'vsd'] };
      if (hex4 === '504B0304' || hex4 === '504B0506') {
        if (ext === 'docx') return { format: 'Microsoft Word OpenXML (.docx)', family: 'zip-office', mime: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', magicHex: hex4, validExt: ['docx'] };
        if (ext === 'pptx') return { format: 'Microsoft PowerPoint OpenXML (.pptx)', family: 'zip-office', mime: 'application/vnd.openxmlformats-officedocument.presentationml.presentation', magicHex: hex4, validExt: ['pptx'] };
        if (ext === 'xlsx') return { format: 'Microsoft Excel OpenXML (.xlsx)', family: 'zip-office', mime: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', magicHex: hex4, validExt: ['xlsx'] };
        if (ext === 'epub') return { format: 'EPUB Digital Publication (.epub)', family: 'zip-epub', mime: 'application/epub+zip', magicHex: hex4, validExt: ['epub'] };
        if (['odt', 'ods', 'odp'].includes(ext)) return { format: `OpenDocument (${ext.toUpperCase()})`, family: 'zip-odf', mime: 'application/vnd.oasis.opendocument', magicHex: hex4, validExt: ['odt', 'ods', 'odp'] };
        return { format: 'ZIP / OpenXML / EPUB Container', family: 'zip', mime: 'application/zip', magicHex: hex4, validExt: ['zip', 'docx', 'pptx', 'xlsx', 'epub', 'jar', 'apk', 'odt'] };
      }
      if (ascii16.slice(4, 8) === 'ftyp') {
        const brand = ascii16.slice(8, 12).trim();
        if (['heic', 'heix', 'mif1', 'avif', 'msf1'].includes(brand)) {
          return { format: `HEIF/AVIF Photograph (${brand})`, family: 'isobmff-image', mime: 'image/heic', magicHex: hex8, validExt: ['heic', 'heif', 'avif', 'jpg', 'jpeg'] };
        }
        if (['M4A', 'M4B'].includes(brand)) {
          return { format: `MPEG-4 Audio (${brand})`, family: 'isobmff', mime: 'audio/mp4', magicHex: hex8, validExt: ['m4a', 'm4b', 'mp4'] };
        }
        return { format: `MP4 / QuickTime Media Container (ftyp:${brand})`, family: 'isobmff', mime: 'video/mp4', magicHex: hex8, validExt: ['mp4', 'mov', 'm4v', 'm4a', '3gp'] };
      }
      if (hex4 === '1A45DFA3') return { format: 'Matroska / WebM Media Container (EBML)', family: 'ebml', mime: 'video/webm', magicHex: hex4, validExt: ['mkv', 'webm', 'mka'] };
      if (ascii16.startsWith('ID3') || hex4.startsWith('FFFB') || hex4.startsWith('FFF3') || hex4.startsWith('FFF2')) {
        return { format: 'MP3 Audio (MPEG Layer III)', family: 'mp3', mime: 'audio/mpeg', magicHex: hex4, validExt: ['mp3'] };
      }
      if (ascii16.startsWith('fLaC')) return { format: 'FLAC Lossless Audio', family: 'flac', mime: 'audio/flac', magicHex: hex4, validExt: ['flac'] };
      if (ascii16.startsWith('OggS')) return { format: 'Ogg Multimedia Container', family: 'ogg', mime: 'audio/ogg', magicHex: hex4, validExt: ['ogg', 'oga', 'ogv', 'opus'] };
      if (hex4.startsWith('4D5A')) return { format: 'Windows PE Executable (MZ)', family: 'binary', mime: 'application/x-msdownload', magicHex: hex4.slice(0, 4), validExt: ['exe', 'dll', 'sys'] };
      if (hex4 === '7F454C46') return { format: 'Linux ELF Binary', family: 'binary', mime: 'application/x-executable', magicHex: hex4, validExt: ['elf', 'so', 'bin', 'out'] };

      if (ext === 'csv' || ext === 'tsv') return { format: `${ext.toUpperCase()} Tabular Dataset`, family: 'csv', mime: 'text/csv', magicHex: hex4, validExt: ['csv', 'tsv'] };
      if (ext === 'svg' || ascii16.includes('<svg')) return { format: 'SVG Vector Graphic', family: 'svg', mime: 'image/svg+xml', magicHex: hex4, validExt: ['svg'] };
      if (ext === 'json') return { format: 'JSON Document', family: 'text', mime: 'application/json', magicHex: hex4, validExt: ['json'] };
      if (['txt', 'md', 'xml', 'html', 'htm', 'js', 'py', 'css', 'yaml', 'yml', 'ini', 'log', 'rtf'].includes(ext)) {
        return { format: `Text / Code Document (.${ext.toUpperCase()})`, family: 'text', mime: 'text/plain', magicHex: hex4, validExt: [ext] };
      }

      return { format: `Binary / Unclassified (.${ext || 'bin'})`, family: 'generic', mime: 'application/octet-stream', magicHex: hex4 || 'N/A', validExt: [ext] };
    }

    // =========================================================================
    // DEEP EXIF / TIFF / GPS / IPTC / XMP / AI PROVENANCE / EDIT HISTORY PARSER
    // =========================================================================
    const EXIF_TAGS = {
      0x0100: 'ImageWidth', 0x0101: 'ImageHeight', 0x0102: 'BitsPerSample', 0x0103: 'Compression',
      0x0106: 'PhotometricInterpretation', 0x010D: 'DocumentName', 0x010E: 'ImageDescription',
      0x010F: 'CameraMake', 0x0110: 'CameraModel', 0x0112: 'Orientation',
      0x011A: 'XResolution', 0x011B: 'YResolution', 0x0128: 'ResolutionUnit',
      0x0131: 'Software', 0x0132: 'ModifyDate', 0x013B: 'Artist', 0x013C: 'HostComputer',
      0x013E: 'WhitePoint', 0x013F: 'PrimaryChromaticities', 0x014A: 'SubIFDs',
      0x0213: 'YCbCrPositioning', 0x8298: 'Copyright',
      0x8769: 'ExifIFDPointer', 0x8825: 'GPSInfoIFDPointer',
      0x829A: 'ExposureTime', 0x829D: 'FNumber', 0x8822: 'ExposureProgram', 0x8827: 'ISO',
      0x8830: 'SensitivityType', 0x8832: 'RecommendedExposureIndex', 0x8833: 'ISOSpeed',
      0x9000: 'ExifVersion', 0x9003: 'DateTimeOriginal', 0x9004: 'DateTimeDigitized',
      0x9010: 'OffsetTime', 0x9011: 'OffsetTimeOriginal', 0x9012: 'OffsetTimeDigitized',
      0x9101: 'ComponentsConfiguration', 0x9102: 'CompressedBitsPerPixel',
      0x9201: 'ShutterSpeedValue', 0x9202: 'ApertureValue', 0x9203: 'BrightnessValue',
      0x9204: 'ExposureCompensation', 0x9205: 'MaxApertureValue', 0x9206: 'SubjectDistance',
      0x9207: 'MeteringMode', 0x9208: 'LightSource', 0x9209: 'Flash', 0x920A: 'FocalLength',
      0x927C: 'MakerNote', 0x9286: 'UserComment',
      0x9290: 'SubSecTime', 0x9291: 'SubSecTimeOriginal', 0x9292: 'SubSecTimeDigitized',
      0xA000: 'FlashpixVersion', 0xA001: 'ColorSpace', 0xA002: 'ExifImageWidth', 0xA003: 'ExifImageHeight',
      0xA004: 'RelatedSoundFile', 0xA005: 'InteroperabilityIFDPointer',
      0xA20E: 'FocalPlaneXResolution', 0xA20F: 'FocalPlaneYResolution',
      0xA210: 'FocalPlaneResolutionUnit', 0xA217: 'SensingMethod', 0xA300: 'FileSource',
      0xA301: 'SceneType', 0xA401: 'CustomRendered', 0xA402: 'ExposureMode',
      0xA403: 'WhiteBalance', 0xA404: 'DigitalZoomRatio', 0xA405: 'FocalLengthIn35mmFormat',
      0xA406: 'SceneCaptureType', 0xA407: 'GainControl', 0xA408: 'Contrast',
      0xA409: 'Saturation', 0xA40A: 'Sharpness', 0xA40C: 'SubjectDistanceRange',
      0xA420: 'ImageUniqueID', 0xA430: 'CameraOwnerName', 0xA431: 'BodySerialNumber',
      0xA432: 'LensSpecification', 0xA433: 'LensMake', 0xA434: 'LensModel', 0xA435: 'LensSerialNumber',
      0xA460: 'CompositeImage', 0xC612: 'DNGVersion', 0xC614: 'UniqueCameraModel', 0xC615: 'LocalizedCameraModel'
    };

    const GPS_TAGS = {
      0x0000: 'GPSVersionID', 0x0001: 'GPSLatitudeRef', 0x0002: 'GPSLatitude',
      0x0003: 'GPSLongitudeRef', 0x0004: 'GPSLongitude', 0x0005: 'GPSAltitudeRef',
      0x0006: 'GPSAltitude', 0x0007: 'GPSTimeStamp', 0x0008: 'GPSSatellites',
      0x0009: 'GPSStatus', 0x000A: 'GPSMeasureMode', 0x000B: 'GPSDOP',
      0x000C: 'GPSSpeedRef', 0x000D: 'GPSSpeed', 0x000E: 'GPSTrackRef', 0x000F: 'GPSTrack',
      0x0010: 'GPSImgDirectionRef', 0x0011: 'GPSImgDirection', 0x0012: 'GPSMapDatum',
      0x0017: 'GPSDestBearingRef', 0x0018: 'GPSDestBearing',
      0x001B: 'GPSProcessingMethod', 0x001C: 'GPSAreaInformation',
      0x001D: 'GPSDateStamp', 0x001E: 'GPSDifferential', 0x001F: 'GPSHPositioningError'
    };

    const ORIENTATION_MAP = {
      1: '1 — Horizontal (normal)',
      2: '2 — Mirror horizontal',
      3: '3 — Rotate 180°',
      4: '4 — Mirror vertical',
      5: '5 — Mirror horizontal and rotate 270° CW',
      6: '6 — Rotate 90° CW',
      7: '7 — Mirror horizontal and rotate 90° CW',
      8: '8 — Rotate 270° CW'
    };

    function parseTiffBlock(dv, tiffStart) {
      const results = [];
      const gpsRaw = {};
      const exifMap = {};
      if (tiffStart < 0 || tiffStart + 8 > dv.byteLength) return { results, gpsRaw, exifMap };
      const byteOrder = dv.getUint16(tiffStart, false);
      const le = byteOrder === 0x4949;
      if (byteOrder !== 0x4949 && byteOrder !== 0x4D4D) return { results, gpsRaw, exifMap };

      results.push({ section: 'EXIF / TIFF Header', key: 'TIFF Byte Order', value: le ? 'Little-Endian (II / Intel)' : 'Big-Endian (MM / Motorola)' });
      const firstIFDOffset = dv.getUint32(tiffStart + 4, le);
      const visitedIFDs = new Set();

      function readIfdOffset(entryPos, type) {
        if (type === 3) {
          let v = dv.getUint16(entryPos + 8, le);
          if (!le && v === 0) v = dv.getUint16(entryPos + 10, false);
          return v;
        }
        return dv.getUint32(entryPos + 8, le);
      }

      function readTagValue(type, count, valueOffsetField, pos) {
        const typeSizes = { 1: 1, 2: 1, 3: 2, 4: 4, 5: 8, 6: 1, 7: 1, 8: 2, 9: 4, 10: 8, 11: 4, 12: 8, 13: 4 };
        const unitSize = typeSizes[type] || 1;
        const totalBytes = unitSize * count;
        if (totalBytes <= 0 || totalBytes > 131072) return null;
        const dataOffset = totalBytes <= 4 ? (pos + 8) : (tiffStart + valueOffsetField);
        if (dataOffset < 0 || dataOffset + totalBytes > dv.byteLength) return null;

        if (type === 2) {
          if (totalBytes <= 4) {
            const span = Math.min(4, dv.byteLength - (pos + 8));
            const inlineBytes = new Uint8Array(dv.buffer, dv.byteOffset + pos + 8, span);
            const hasControlOrHigh = Array.from(inlineBytes).some(b => (b > 0 && b < 32) || b >= 127);
            const hasPrintable = Array.from(inlineBytes).some(b => b >= 32 && b <= 126);
            if (!hasControlOrHigh && hasPrintable) {
              return new TextDecoder('utf-8', { fatal: false }).decode(inlineBytes).replace(/\0+/g, ' ').trim();
            }
            if (valueOffsetField > 0 && tiffStart + valueOffsetField + count <= dv.byteLength) {
              const ptrBytes = new Uint8Array(dv.buffer, dv.byteOffset + tiffStart + valueOffsetField, count);
              return new TextDecoder('utf-8', { fatal: false }).decode(ptrBytes).replace(/\0+/g, ' ').trim();
            }
          }
          const bytes = new Uint8Array(dv.buffer, dv.byteOffset + dataOffset, count);
          return new TextDecoder('utf-8', { fatal: false }).decode(bytes).replace(/\0+/g, ' ').trim();
        }
        if (type === 1 || type === 6 || type === 7) {
          if (totalBytes === 1 && !le) {
            let b = type === 6 ? dv.getInt8(dataOffset) : dv.getUint8(dataOffset);
            if (b === 0 && dataOffset + 3 < dv.byteLength) {
              const bRight = type === 6 ? dv.getInt8(dataOffset + 3) : dv.getUint8(dataOffset + 3);
              if (bRight !== 0) b = bRight;
            }
            return b;
          }
          const bytes = new Uint8Array(dv.buffer, dv.byteOffset + dataOffset, Math.min(count, 2048));
          if (count >= 4) {
            const header8 = new TextDecoder('ascii').decode(bytes.subarray(0, Math.min(8, bytes.length)));
            if (header8.startsWith('ASCII')) {
              return new TextDecoder('utf-8', { fatal: false }).decode(bytes.subarray(Math.min(8, bytes.length))).replace(/\0+/g, ' ').trim();
            }
            if (header8.startsWith('UNICODE')) {
              return new TextDecoder(le ? 'utf-16le' : 'utf-16be', { fatal: false }).decode(bytes.subarray(Math.min(8, bytes.length))).replace(/\0+/g, ' ').trim();
            }
            const printable = Array.from(bytes.subarray(0, Math.min(64, bytes.length))).filter(b => (b >= 32 && b <= 126) || b === 0).length;
            const nonZeroPrintable = Array.from(bytes.subarray(0, Math.min(64, bytes.length))).filter(b => b >= 32 && b <= 126).length;
            if (nonZeroPrintable >= 3 && printable >= Math.min(bytes.length, 64) * 0.8) {
              return new TextDecoder('utf-8', { fatal: false }).decode(bytes).replace(/\0+/g, ' ').trim();
            }
          }
          const arr = Array.from(bytes.subarray(0, Math.min(count, 16)));
          return count === 1 ? arr[0] : arr.join('.');
        }
        if (type === 3 || type === 8) {
          if (count === 1 && !le && dataOffset + 4 <= dv.byteLength) {
            let v = type === 3 ? dv.getUint16(dataOffset, false) : dv.getInt16(dataOffset, false);
            const vRight = type === 3 ? dv.getUint16(dataOffset + 2, false) : dv.getInt16(dataOffset + 2, false);
            if (v === 0 && vRight !== 0) v = vRight;
            return v;
          }
          const arr = [];
          for (let i = 0; i < Math.min(count, 16); i++) {
            arr.push(type === 3 ? dv.getUint16(dataOffset + i * 2, le) : dv.getInt16(dataOffset + i * 2, le));
          }
          return count === 1 ? arr[0] : arr;
        }
        if (type === 4 || type === 9 || type === 13) {
          const arr = [];
          for (let i = 0; i < Math.min(count, 16); i++) {
            arr.push(type === 9 ? dv.getInt32(dataOffset + i * 4, le) : dv.getUint32(dataOffset + i * 4, le));
          }
          return count === 1 ? arr[0] : arr;
        }
        if (type === 5 || type === 10) {
          const arr = [];
          for (let i = 0; i < Math.min(count, 8); i++) {
            const num = type === 5 ? dv.getUint32(dataOffset + i * 8, le) : dv.getInt32(dataOffset + i * 8, le);
            const den = type === 5 ? dv.getUint32(dataOffset + i * 8 + 4, le) : dv.getInt32(dataOffset + i * 8 + 4, le);
            arr.push(den === 0 ? 0 : Number((num / den).toFixed(6)));
          }
          return count === 1 ? arr[0] : arr;
        }
        if (type === 11) {
          const arr = [];
          for (let i = 0; i < Math.min(count, 8); i++) arr.push(Number(dv.getFloat32(dataOffset + i * 4, le).toFixed(6)));
          return count === 1 ? arr[0] : arr;
        }
        if (type === 12) {
          const arr = [];
          for (let i = 0; i < Math.min(count, 8); i++) arr.push(Number(dv.getFloat64(dataOffset + i * 8, le).toFixed(6)));
          return count === 1 ? arr[0] : arr;
        }
        return null;
      }

      function parseIFD(ifdOffset, sectionName, tagDict, isGps = false) {
        if (!ifdOffset || visitedIFDs.has(ifdOffset)) return;
        visitedIFDs.add(ifdOffset);
        const absOffset = tiffStart + ifdOffset;
        if (absOffset < 0 || absOffset + 2 > dv.byteLength) return;
        const numEntries = dv.getUint16(absOffset, le);
        if (numEntries <= 0 || numEntries > 400) return;

        for (let i = 0; i < numEntries; i++) {
          const entryPos = absOffset + 2 + i * 12;
          if (entryPos + 12 > dv.byteLength) break;
          const tag = dv.getUint16(entryPos, le);
          const type = dv.getUint16(entryPos + 2, le);
          const count = dv.getUint32(entryPos + 4, le);
          const valOffset = dv.getUint32(entryPos + 8, le);

          if (tag === 0x8769 && !isGps) {
            parseIFD(readIfdOffset(entryPos, type), 'EXIF SubIFD (Camera, Lens & Timestamps)', EXIF_TAGS, false);
            continue;
          }
          if (tag === 0x8825 && !isGps) {
            parseIFD(readIfdOffset(entryPos, type), 'GPS / Geolocation IFD', GPS_TAGS, true);
            continue;
          }
          if (tag === 0xA005 && !isGps) {
            parseIFD(readIfdOffset(entryPos, type), 'EXIF Interoperability IFD', EXIF_TAGS, false);
            continue;
          }
          if (tag === 0x014A && !isGps) {
            parseIFD(readIfdOffset(entryPos, type), 'TIFF SubIFD', EXIF_TAGS, false);
            continue;
          }
          if (tag === 0x927C && !isGps) {
            const mnOffset = count <= 4 ? (entryPos + 8) : (tiffStart + valOffset);
            let mnSummary = `Vendor Binary Block (${count.toLocaleString()} bytes)`;
            if (mnOffset >= 0 && mnOffset + Math.min(count, 32768) <= dv.byteLength) {
              const mnBytes = new Uint8Array(dv.buffer, dv.byteOffset + mnOffset, Math.min(count, 32768));
              const mnText = new TextDecoder('latin1').decode(mnBytes);
              const strings = [...new Set((mnText.match(/[A-Za-z0-9][A-Za-z0-9 ._/:+-]{4,48}/g) || []).map(s => s.trim()).filter(s => /[A-Za-z]{2,}/.test(s)))].slice(0, 8);
              if (strings.length > 0) mnSummary += ` | Embedded Strings: ${strings.join(', ')}`;
            }
            exifMap.MakerNote = mnSummary;
            results.push({ section: sectionName, key: 'MakerNote (Vendor Camera/Lens Data)', value: mnSummary, tagHex: '0x927C' });
            continue;
          }

          const val = readTagValue(type, count, valOffset, entryPos);
          if (val === null || val === '') continue;

          const tagName = tagDict[tag] || `Tag_0x${tag.toString(16).toUpperCase().padStart(4, '0')}`;
          let formattedVal = Array.isArray(val) ? val.join(', ') : String(val);

          if (tag === 0x0112 && ORIENTATION_MAP[val]) formattedVal = ORIENTATION_MAP[val];
          if (tag === 0x829A && typeof val === 'number') {
            formattedVal = val < 1 && val > 0 ? `1/${Math.round(1 / val)} sec (${val}s)` : `${val} sec`;
          }
          if (tag === 0x829D && typeof val === 'number') formattedVal = `f/${val}`;
          if ((tag === 0x920A || tag === 0xA405) && typeof val === 'number') formattedVal = `${val} mm`;
          if (tag === 0xA432 && Array.isArray(val) && val.length === 4) {
            formattedVal = `${val[0]}–${val[1]} mm, f/${val[2]}–f/${val[3]}`;
          }

          if (isGps) {
            gpsRaw[tagName] = val;
          } else {
            if (!exifMap[tagName]) exifMap[tagName] = formattedVal;
          }

          results.push({
            section: sectionName,
            key: tagName,
            value: formattedVal,
            tagHex: `0x${tag.toString(16).toUpperCase().padStart(4, '0')}`,
            isPII: isGps || ['Artist', 'CameraOwnerName', 'BodySerialNumber', 'LensSerialNumber', 'Copyright', 'HostComputer'].includes(tagName)
          });
        }

        // Follow chained nextIFDOffset (IFD1, IFD2...)
        const nextIfdPtrPos = absOffset + 2 + numEntries * 12;
        if (!isGps && nextIfdPtrPos + 4 <= dv.byteLength) {
          const nextIfdOffset = dv.getUint32(nextIfdPtrPos, le);
          if (nextIfdOffset > 0 && nextIfdOffset < dv.byteLength) {
            parseIFD(nextIfdOffset, 'EXIF IFD1 (Chained / Thumbnail IFD)', EXIF_TAGS, false);
          }
        }
      }

      parseIFD(firstIFDOffset, 'EXIF IFD0 (Camera & Primary Image)', EXIF_TAGS, false);

      // Compute APEX fallback for ExposureTime / FNumber if camera only wrote ShutterSpeedValue / ApertureValue
      if (!exifMap.ExposureTime && exifMap.ShutterSpeedValue !== undefined) {
        const sv = parseFloat(exifMap.ShutterSpeedValue);
        if (!Number.isNaN(sv)) {
          const sec = Math.pow(2, -sv);
          exifMap.ExposureTime = sec < 1 ? `1/${Math.round(1 / sec)} sec` : `${sec.toFixed(2)} sec`;
        }
      }
      if (!exifMap.FNumber && exifMap.ApertureValue !== undefined) {
        const av = parseFloat(exifMap.ApertureValue);
        if (!Number.isNaN(av)) {
          exifMap.FNumber = `f/${Math.pow(Math.sqrt(2), av).toFixed(1)}`;
        }
      }

      // Compute Decimal & DMS GPS Coordinates (supports 3-elem DMS, 2-elem DM, 1-elem decimal, or string)
      function toDmsAndDec(rawCoord, refStr, isLon = false) {
        let deg = 0, min = 0, sec = 0;
        let ref = String(refStr || (isLon ? 'E' : 'N')).trim().toUpperCase();
        if (Array.isArray(rawCoord)) {
          deg = Number(rawCoord[0]) || 0;
          min = Number(rawCoord[1]) || 0;
          sec = Number(rawCoord[2]) || 0;
          if (sec === 0 && min % 1 !== 0) {
            sec = Number(((min % 1) * 60).toFixed(3));
            min = Math.floor(min);
          }
        } else if (typeof rawCoord === 'number') {
          const abs = Math.abs(rawCoord);
          deg = Math.floor(abs);
          min = Math.floor((abs - deg) * 60);
          sec = Number((((abs - deg) * 60 - min) * 60).toFixed(3));
          if (rawCoord < 0) ref = isLon ? 'W' : 'S';
        } else if (typeof rawCoord === 'string') {
          const m = rawCoord.match(/([+-]?\d+(?:\.\d+)?)/g);
          if (m && m.length >= 1) {
            deg = Math.abs(parseFloat(m[0]) || 0);
            min = Math.abs(parseFloat(m[1]) || 0);
            sec = Math.abs(parseFloat(m[2]) || 0);
            if (/[SW]/i.test(rawCoord) || String(m[0]).startsWith('-')) ref = isLon ? 'W' : 'S';
            if (/[NE]/i.test(rawCoord)) ref = isLon ? 'E' : 'N';
          }
        } else {
          return null;
        }
        let dec = deg + min / 60 + sec / 3600;
        if (ref.startsWith('S') || ref.startsWith('W')) dec = -Math.abs(dec);
        return { dec, dms: `${deg}° ${min}' ${sec}" ${ref[0] || (isLon ? 'E' : 'N')}` };
      }

      if (gpsRaw.GPSLatitude !== undefined && gpsRaw.GPSLongitude !== undefined) {
        const latObj = toDmsAndDec(gpsRaw.GPSLatitude, gpsRaw.GPSLatitudeRef, false);
        const lonObj = toDmsAndDec(gpsRaw.GPSLongitude, gpsRaw.GPSLongitudeRef, true);
        if (latObj && lonObj && (latObj.dec !== 0 || lonObj.dec !== 0)) {
          const coordStr = `${latObj.dec.toFixed(6)}, ${lonObj.dec.toFixed(6)} (${latObj.dms}, ${lonObj.dms})`;
          gpsRaw.formattedCoordinates = coordStr;
          results.unshift({
            section: 'GPS / Geolocation IFD',
            key: 'GPS Coordinates (Decimal & DMS)',
            value: coordStr,
            isPII: true
          });
        }
      }

      if (gpsRaw.GPSAltitude !== undefined) {
        const ref = Number(gpsRaw.GPSAltitudeRef) === 1 ? 'Below Sea Level' : 'Above Sea Level';
        const altStr = `${gpsRaw.GPSAltitude} m (${ref})`;
        gpsRaw.formattedAltitude = altStr;
        results.push({
          section: 'GPS / Geolocation IFD',
          key: 'GPS Altitude (Formatted)',
          value: altStr,
          isPII: true
        });
      }

      if (Array.isArray(gpsRaw.GPSTimeStamp) && gpsRaw.GPSTimeStamp.length >= 2) {
        const [h, m, s = 0] = gpsRaw.GPSTimeStamp.map(n => String(Math.floor(Number(n) || 0)).padStart(2, '0'));
        const datePart = gpsRaw.GPSDateStamp ? String(gpsRaw.GPSDateStamp).replace(/:/g, '-') : '';
        const tsStr = `${datePart ? datePart + ' ' : ''}${h}:${m}:${s} UTC`;
        gpsRaw.formattedTimestamp = tsStr;
        results.push({
          section: 'GPS / Geolocation IFD',
          key: 'GPS Satellite Timestamp (UTC)',
          value: tsStr,
          isPII: true
        });
      }

      return { results, gpsRaw, exifMap };
    }

    // Parse IPTC IIM Dataset Records (inside JPEG APP13 Photoshop IRB 0x0404)
    function parseIptcBlock(u8, start, len) {
      const props = [];
      const iptcMap = {};
      const datasetNames = {
        5: 'ObjectName (Title)',
        25: 'Keywords',
        55: 'DateCreated',
        60: 'TimeCreated',
        62: 'DigitalCreationDate',
        63: 'DigitalCreationTime',
        80: 'By-line (Photographer / Creator)',
        85: 'By-lineTitle (Creator Job Title)',
        90: 'City',
        95: 'Province / State',
        101: 'Country / PrimaryLocationName',
        105: 'Headline',
        110: 'Credit',
        115: 'Source',
        116: 'CopyrightNotice',
        120: 'Caption / Abstract',
        122: 'Writer / Editor'
      };
      let p = start;
      const end = Math.min(u8.length, start + len);
      while (p + 5 <= end) {
        if (u8[p] === 0x1C && u8[p + 1] === 0x02) {
          const ds = u8[p + 2];
          const size = (u8[p + 3] << 8) | u8[p + 4];
          if (p + 5 + size <= end && size > 0 && size < 4096) {
            const val = new TextDecoder('utf-8', { fatal: false }).decode(u8.subarray(p + 5, p + 5 + size)).trim();
            const name = datasetNames[ds] || `IPTC_2:${ds}`;
            if (val) {
              iptcMap[name] = iptcMap[name] ? `${iptcMap[name]}, ${val}` : val;
              props.push({
                section: 'IPTC Press & Creator Metadata (APP13)',
                key: name,
                value: val,
                isPII: [80, 110, 116, 122].includes(ds)
              });
            }
          }
          p += 5 + size;
        } else {
          p++;
        }
      }
      return { props, iptcMap };
    }

    // Parse XMP Packet including Edit History Log (stEvt), Camera Raw, Creator/Rights, and AI Provenance
    function extractXmpAndEditHistory(xmlText) {
      const props = [];
      const xmpData = {
        editHistory: [],
        cameraRaw: [],
        fields: {}
      };
      try {
        const historyBlockMatch = xmlText.match(/<xmpMM:History>([\s\S]*?)<\/xmpMM:History>/i);
        if (historyBlockMatch) {
          const liMatches = [...historyBlockMatch[1].matchAll(/<rdf:li\b([^>]*)>([\s\S]*?)<\/rdf:li>|<rdf:li\b([^>]*)\/>/gi)];
          liMatches.forEach((m, idx) => {
            const chunk = (m[1] || '') + ' ' + (m[2] || '') + ' ' + (m[3] || '');
            const readField = name => {
              const attrM = chunk.match(new RegExp(`stEvt:${name}=["']([^"']+)["']`, 'i'));
              if (attrM) return attrM[1];
              const tagM = chunk.match(new RegExp(`<stEvt:${name}[^>]*>([^<]+)<\\/stEvt:${name}>`, 'i'));
              return tagM ? tagM[1].trim() : '';
            };
            const action = readField('action');
            const softwareAgent = readField('softwareAgent');
            const when = readField('when');
            const parameters = readField('parameters');
            const changed = readField('changed');
            const stepSummary = [
              action ? `Action: ${action}` : '',
              softwareAgent ? `App: ${softwareAgent}` : '',
              when ? `When: ${when}` : '',
              parameters ? `Params: ${parameters}` : '',
              changed ? `Changed: ${changed}` : ''
            ].filter(Boolean).join(' | ');
            if (stepSummary) {
              xmpData.editHistory.push({ step: idx + 1, action, softwareAgent, when, parameters, changed, summary: stepSummary });
              props.push({
                section: 'Software & Edit History Log (xmpMM:History)',
                key: `Edit Step #${idx + 1} (${action || 'event'})`,
                value: stepSummary
              });
            }
          });
        }

        const tagRegex = /<([a-zA-Z0-9_]+:[a-zA-Z0-9_.-]+)[^>]*>([^<]{1,600})<\/\1>/g;
        let match;
        const seen = new Set();
        while ((match = tagRegex.exec(xmlText)) !== null) {
          const key = match[1];
          const val = match[2].trim();
          if (!val || /^rdf:(li|Alt|Seq|Bag)$/i.test(key) || key.startsWith('stEvt:')) continue;
          const uniq = `${key}=${val}`;
          if (!seen.has(uniq)) {
            seen.add(uniq);
            xmpData.fields[key] = val;
            const section = key.startsWith('crs:')
              ? 'Camera Raw / Lightroom Parametric Edits (crs)'
              : key.startsWith('xmpRights:') || key.startsWith('dc:') || key.startsWith('photoshop:') || key.startsWith('plus:')
              ? 'Creator, Copyright & Licensing (XMP)'
              : key.startsWith('c2pa:') || key.startsWith('Iptc4xmpExt:')
              ? 'AI Provenance & Content Credentials (XMP/C2PA)'
              : 'XMP / RDF Packet Metadata';
            props.push({ section, key, value: val });
          }
        }

        const nestedDcTags = ['dc:creator', 'dc:rights', 'dc:title', 'dc:description', 'xmpRights:UsageTerms', 'exif:GPSLatitude', 'exif:GPSLongitude', 'exif:GPSAltitude', 'tiff:Make', 'tiff:Model', 'aux:Lens', 'aux:Firmware'];
        for (const dt of nestedDcTags) {
          const blockM = xmlText.match(new RegExp(`<${dt}[^>]*>([\\s\\S]*?)<\\/${dt}>`, 'i'));
          if (blockM) {
            const innerVal = blockM[1].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
            if (innerVal && !xmpData.fields[dt]) {
              xmpData.fields[dt] = innerVal;
              props.push({
                section: 'Creator, Copyright & Licensing (XMP)',
                key: dt,
                value: innerVal,
                isPII: dt === 'dc:creator' || dt === 'dc:rights' || dt.startsWith('exif:GPS')
              });
            }
          }
        }

        const attrRegex = /\b(xmp|dc|pdf|photoshop|tiff|exif|exifEX|aux|xmpMM|xmpRights|crs|c2pa|Iptc4xmpExt|plus|GCamera|Container|Item|hdrgm|MiCamera):([a-zA-Z0-9_]+)=["']([^"']{1,400})["']/g;
        while ((match = attrRegex.exec(xmlText)) !== null) {
          const ns = match[1];
          const prop = match[2];
          const key = `${ns}:${prop}`;
          const val = match[3].trim();
          const uniq = `${key}=${val}`;
          if (val && !seen.has(uniq)) {
            seen.add(uniq);
            xmpData.fields[key] = val;
            if (ns === 'crs') xmpData.cameraRaw.push(`${prop}: ${val}`);
            const section = ns === 'crs'
              ? 'Camera Raw / Lightroom Parametric Edits (crs)'
              : ['xmpRights', 'dc', 'photoshop', 'plus'].includes(ns)
              ? 'Creator, Copyright & Licensing (XMP)'
              : ['c2pa', 'Iptc4xmpExt'].includes(ns)
              ? 'AI Provenance & Content Credentials (XMP/C2PA)'
              : 'XMP / RDF Packet Metadata';
            props.push({ section, key, value: val });
          }
        }
      } catch (e) {}
      return { props, xmpData };
    }

    // Parse AI-Generation Markers (Stable Diffusion A1111/Forge, ComfyUI, Midjourney, Firefly, DALL-E/C2PA)
    function parseAiGenerationMetadata(rawTextMap, rawBinaryU8) {
      const aiProps = [];
      const aiSummary = {
        detected: false,
        generator: null,
        modelName: null,
        modelVersion: null,
        positivePrompt: null,
        negativePrompt: null,
        seed: null,
        sampler: null,
        steps: null,
        cfgScale: null,
        c2paManifest: null
      };

      const paramText = rawTextMap.parameters || rawTextMap.UserComment || rawTextMap.Comment || '';
      if (paramText && (/Steps:\s*\d+/i.test(paramText) || /Negative prompt:/i.test(paramText) || /Sampler:/i.test(paramText))) {
        aiSummary.detected = true;
        aiSummary.generator = 'Stable Diffusion (Automatic1111 / Forge / WebUI)';
        const negSplit = paramText.split(/\nNegative prompt:\s*/i);
        const posPrompt = negSplit[0].trim();
        let negPrompt = '';
        let kvLine = '';
        if (negSplit.length > 1) {
          const lines = negSplit[1].split('\n');
          kvLine = lines.pop() || '';
          negPrompt = lines.join('\n').trim();
        } else {
          const lines = posPrompt.split('\n');
          kvLine = lines.pop() || '';
        }

        aiSummary.positivePrompt = posPrompt.split(/\nSteps:/i)[0].trim();
        if (negPrompt) aiSummary.negativePrompt = negPrompt;

        const kvPairs = kvLine.split(/,\s*(?=[A-Za-z0-9 _-]+:\s*)/);
        for (const pair of kvPairs) {
          const idx = pair.indexOf(':');
          if (idx > 0) {
            const k = pair.slice(0, idx).trim();
            const v = pair.slice(idx + 1).trim();
            if (/^Model$/i.test(k)) aiSummary.modelName = v;
            if (/^Model hash$/i.test(k)) aiSummary.modelVersion = aiSummary.modelVersion ? `${aiSummary.modelVersion} (Hash: ${v})` : `Hash: ${v}`;
            if (/^Version$/i.test(k)) { aiSummary.modelVersion = v; aiSummary.generator = `Stable Diffusion WebUI (${v})`; }
            if (/^Seed$/i.test(k)) aiSummary.seed = v;
            if (/^Sampler$/i.test(k)) aiSummary.sampler = v;
            if (/^Steps$/i.test(k)) aiSummary.steps = v;
            if (/^CFG scale$/i.test(k)) aiSummary.cfgScale = v;
            aiProps.push({ section: 'AI-Generation Markers & Parameters', key: `AI Parameter — ${k}`, value: v });
          }
        }
        if (aiSummary.positivePrompt) {
          aiProps.unshift({ section: 'AI-Generation Markers & Parameters', key: 'AI Positive Prompt', value: aiSummary.positivePrompt });
        }
        if (aiSummary.negativePrompt) {
          aiProps.push({ section: 'AI-Generation Markers & Parameters', key: 'AI Negative Prompt', value: aiSummary.negativePrompt });
        }
      }

      if (rawTextMap.prompt && rawTextMap.prompt.trim().startsWith('{')) {
        try {
          const graph = JSON.parse(rawTextMap.prompt);
          aiSummary.detected = true;
          aiSummary.generator = 'ComfyUI Node Graph Workflow';
          const prompts = [];
          for (const node of Object.values(graph)) {
            if (!node || !node.inputs) continue;
            const ct = String(node.class_type || '');
            if (node.inputs.ckpt_name || node.inputs.unet_name) {
              aiSummary.modelName = node.inputs.ckpt_name || node.inputs.unet_name;
              aiProps.push({ section: 'AI-Generation Markers & Parameters', key: 'ComfyUI Checkpoint / UNet Model', value: aiSummary.modelName });
            }
            if (ct.includes('CLIPTextEncode') && typeof node.inputs.text === 'string' && node.inputs.text.trim()) {
              prompts.push(node.inputs.text.trim());
            }
            if (ct.includes('KSampler')) {
              if (node.inputs.seed !== undefined) aiSummary.seed = String(node.inputs.seed);
              if (node.inputs.steps !== undefined) aiSummary.steps = String(node.inputs.steps);
              if (node.inputs.cfg !== undefined) aiSummary.cfgScale = String(node.inputs.cfg);
              if (node.inputs.sampler_name) aiSummary.sampler = `${node.inputs.sampler_name} (${node.inputs.scheduler || 'normal'})`;
            }
          }
          if (prompts[0] && !aiSummary.positivePrompt) {
            aiSummary.positivePrompt = prompts[0];
            aiProps.push({ section: 'AI-Generation Markers & Parameters', key: 'ComfyUI Positive Prompt', value: prompts[0] });
          }
          if (prompts[1] && !aiSummary.negativePrompt) {
            aiSummary.negativePrompt = prompts[1];
            aiProps.push({ section: 'AI-Generation Markers & Parameters', key: 'ComfyUI Negative Prompt', value: prompts[1] });
          }
        } catch (e) {}
      }

      const descText = rawTextMap.Description || rawTextMap.ImageDescription || rawTextMap['dc:description'] || '';
      if (descText && (/--v\s+\d/i.test(descText) || /Job ID:\s*[0-9a-f-]{20,}/i.test(descText))) {
        aiSummary.detected = true;
        aiSummary.generator = 'Midjourney';
        const vMatch = descText.match(/--v\s+([0-9.a-z]+)/i);
        aiSummary.modelName = vMatch ? `Midjourney v${vMatch[1]}` : 'Midjourney';
        aiSummary.modelVersion = vMatch ? vMatch[1] : 'N/A';
        aiSummary.positivePrompt = descText;
        aiProps.push(
          { section: 'AI-Generation Markers & Parameters', key: 'AI Generator', value: aiSummary.modelName },
          { section: 'AI-Generation Markers & Parameters', key: 'Midjourney Prompt & Flags', value: descText }
        );
      }

      const sampleStr = new TextDecoder('latin1').decode(rawBinaryU8.subarray(0, Math.min(rawBinaryU8.length, 256 * 1024)));
      const hasC2paBox = /c2pa|urn:uuid:|c2pa\.actions|trainedAlgorithmicMedia|SynthID|Adobe Firefly|DALL·E|OpenAI/i.test(sampleStr);
      if (hasC2paBox || rawTextMap['c2pa:generator'] || rawTextMap['c2pa:model'] || rawTextMap['c2pa:prompt'] || rawTextMap['Iptc4xmpExt:DigitalSourceType']) {
        aiSummary.detected = true;
        const c2paGen = rawTextMap['c2pa:generator'] || (sampleStr.includes('Adobe Firefly') ? 'Adobe Firefly (C2PA)' : sampleStr.includes('DALL·E') ? 'OpenAI DALL·E 3 (C2PA)' : 'C2PA Content Credentials Manifest');
        if (!aiSummary.generator) aiSummary.generator = c2paGen;
        if (rawTextMap['c2pa:model'] && !aiSummary.modelName) aiSummary.modelName = rawTextMap['c2pa:model'];
        if (rawTextMap['c2pa:version'] && !aiSummary.modelVersion) aiSummary.modelVersion = rawTextMap['c2pa:version'];
        if (rawTextMap['c2pa:prompt'] && !aiSummary.positivePrompt) aiSummary.positivePrompt = rawTextMap['c2pa:prompt'];
        if (rawTextMap['c2pa:negativePrompt'] && !aiSummary.negativePrompt) aiSummary.negativePrompt = rawTextMap['c2pa:negativePrompt'];
        if (rawTextMap['c2pa:seed'] && !aiSummary.seed) aiSummary.seed = rawTextMap['c2pa:seed'];
        aiSummary.c2paManifest = 'Present (C2PA / JUMBF Provenance Assertions Detected)';
        aiProps.push({
          section: 'AI-Generation Markers & Parameters',
          key: 'C2PA / Content Credentials Status',
          value: aiSummary.c2paManifest
        });
      }

      return { aiProps, aiSummary };
    }

    // Deep full-binary fallback scanner for secondary Exif\0\0 blocks, XMP packets, or vendor trailers anywhere in an image
    function scanAllEmbeddedExifAndXmp(u8, alreadyParsedTiffOffsets, exifMap, gpsRaw, xmpMerged, textMetaPool, formatProps) {
      const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
      const scanLimit = Math.min(u8.length, 4 * 1024 * 1024);

      // 1. Scan for any additional 'Exif\0' + ('II' or 'MM') blocks not yet parsed
      for (let i = 0; i + 14 < scanLimit; i++) {
        if (u8[i] === 0x45 && u8[i + 1] === 0x78 && u8[i + 2] === 0x69 && u8[i + 3] === 0x66 && u8[i + 4] === 0x00) {
          const tiffStart = i + 6;
          if (!alreadyParsedTiffOffsets.has(tiffStart)) {
            const bo = dv.getUint16(tiffStart, false);
            if (bo === 0x4949 || bo === 0x4D4D) {
              alreadyParsedTiffOffsets.add(tiffStart);
              const parsed = parseTiffBlock(dv, tiffStart);
              formatProps.push(...parsed.results);
              for (const [k, v] of Object.entries(parsed.exifMap)) {
                if (!exifMap[k]) exifMap[k] = v;
              }
              Object.assign(gpsRaw, parsed.gpsRaw);
            }
          }
        }
      }

      // 2. Scan for any <x:xmpmeta or <rdf:RDF blocks across the binary (including ExtendedXMP & trailers)
      const latinSample = new TextDecoder('latin1').decode(u8.subarray(0, scanLimit));
      let searchPos = 0;
      while (searchPos < latinSample.length) {
        const startIdx = latinSample.indexOf('<x:xmpmeta', searchPos);
        if (startIdx === -1) break;
        const endIdx = latinSample.indexOf('</x:xmpmeta>', startIdx);
        if (endIdx === -1) break;
        const xmpBytes = u8.subarray(startIdx, endIdx + 12);
        const xmpStr = new TextDecoder('utf-8', { fatal: false }).decode(xmpBytes);
        const { props, xmpData } = extractXmpAndEditHistory(xmpStr);
        if (xmpMerged.editHistory.length === 0 && xmpData.editHistory.length > 0) {
          xmpMerged.editHistory.push(...xmpData.editHistory);
        }
        for (const cr of xmpData.cameraRaw) {
          if (!xmpMerged.cameraRaw.includes(cr)) xmpMerged.cameraRaw.push(cr);
        }
        for (const [k, v] of Object.entries(xmpData.fields)) {
          if (!xmpMerged.fields[k]) {
            xmpMerged.fields[k] = v;
            textMetaPool[k] = v;
            formatProps.push(...props.filter(p => p.key === k));
          }
        }
        searchPos = endIdx + 12;
      }
    }

    function parseJpegSegments(u8) {
      const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
      const formatProps = [];
      const structureProps = [];
      let exifMap = {};
      let gpsRaw = {};
      let iptcMap = {};
      let xmpMerged = { editHistory: [], cameraRaw: [], fields: {} };
      const textMetaPool = {};
      const alreadyParsedTiffOffsets = new Set();
      let offset = 2;

      while (offset + 4 <= u8.length) {
        // Tolerate alignment/padding bytes by advancing to the next 0xFF marker
        if (u8[offset] !== 0xFF) {
          offset++;
          continue;
        }
        const marker = u8[offset + 1];
        if (marker === 0xFF) { offset++; continue; }
        if (marker === 0x00) { offset += 2; continue; }
        if (marker === 0xD9 || marker === 0xDA) {
          structureProps.push({ section: 'JPEG Stream Structure', key: marker === 0xDA ? 'SOS (Start of Compressed Scan)' : 'EOI Marker', value: `Offset 0x${offset.toString(16).toUpperCase()}` });
          break;
        }
        if (marker >= 0xD0 && marker <= 0xD8) { offset += 2; continue; }
        const segLen = dv.getUint16(offset + 2, false);
        if (segLen < 2 || offset + 2 + segLen > u8.length) break;

        const segStart = offset + 4;
        const segDataLen = segLen - 2;

        if (marker === 0xE0 && segDataLen >= 14) {
          const id = new TextDecoder('ascii').decode(u8.subarray(segStart, segStart + 5));
          if (id.startsWith('JFIF')) {
            const vMaj = u8[segStart + 5];
            const vMin = u8[segStart + 6];
            const units = u8[segStart + 7];
            const xDens = dv.getUint16(segStart + 8, false);
            const yDens = dv.getUint16(segStart + 10, false);
            formatProps.push({ section: 'JPEG JFIF Header (APP0)', key: 'JFIF Version', value: `${vMaj}.${String(vMin).padStart(2, '0')}` });
            formatProps.push({ section: 'JPEG JFIF Header (APP0)', key: 'Pixel Density', value: `${xDens} × ${yDens} (${units === 1 ? 'DPI' : units === 2 ? 'DPCM' : 'Aspect Ratio'})` });
          }
        }

        if (marker === 0xE1 && segDataLen >= 6) {
          const headerStr = new TextDecoder('latin1').decode(u8.subarray(segStart, Math.min(segStart + 128, segStart + segDataLen)));
          if (headerStr.startsWith('Exif\0')) {
            const tiffStart = segStart + 6;
            alreadyParsedTiffOffsets.add(tiffStart);
            const parsed = parseTiffBlock(dv, tiffStart);
            formatProps.push(...parsed.results);
            for (const [k, v] of Object.entries(parsed.exifMap)) {
              if (!exifMap[k]) exifMap[k] = v;
            }
            Object.assign(gpsRaw, parsed.gpsRaw);
            if (parsed.exifMap.UserComment) textMetaPool.UserComment = parsed.exifMap.UserComment;
            if (parsed.exifMap.ImageDescription) textMetaPool.ImageDescription = parsed.exifMap.ImageDescription;
          } else if (headerStr.includes('http://ns.adobe.com/xap/1.0/') || headerStr.includes('http://ns.adobe.com/xmp/extension/') || headerStr.includes('<x:xmpmeta') || headerStr.includes('<rdf:RDF')) {
            const xmpStr = new TextDecoder('utf-8', { fatal: false }).decode(u8.subarray(segStart, segStart + segDataLen));
            const { props, xmpData } = extractXmpAndEditHistory(xmpStr);
            formatProps.push(...props);
            xmpMerged.editHistory.push(...xmpData.editHistory);
            xmpMerged.cameraRaw.push(...xmpData.cameraRaw);
            Object.assign(xmpMerged.fields, xmpData.fields);
            Object.assign(textMetaPool, xmpData.fields);
          }
        }

        if (marker === 0xE2 && segDataLen >= 14) {
          const iccId = new TextDecoder('ascii').decode(u8.subarray(segStart, segStart + 11));
          if (iccId.startsWith('ICC_PROFILE')) {
            formatProps.push({ section: 'Color Profile (APP2)', key: 'Embedded ICC Profile', value: `Present (${segDataLen} bytes)` });
          }
        }

        if (marker === 0xEB && segDataLen >= 8) {
          formatProps.push({ section: 'AI Provenance & Content Credentials (APP11 JUMBF)', key: 'JUMBF / C2PA Box Segment', value: `Present (${segDataLen} bytes @ 0x${offset.toString(16).toUpperCase()})` });
        }

        if (marker === 0xED && segDataLen >= 14) {
          formatProps.push({ section: 'IPTC / Photoshop APP13', key: 'Photoshop IRB / IPTC Block', value: `${segDataLen} bytes at 0x${offset.toString(16).toUpperCase()}` });
          const { props, iptcMap: im } = parseIptcBlock(u8, segStart, segDataLen);
          formatProps.push(...props);
          Object.assign(iptcMap, im);
        }

        if ([0xC0, 0xC1, 0xC2].includes(marker) && segDataLen >= 6) {
          const precision = u8[segStart];
          const height = dv.getUint16(segStart + 1, false);
          const width = dv.getUint16(segStart + 3, false);
          const components = u8[segStart + 5];
          const encodingMap = { 0xC0: 'Baseline DCT (SOF0)', 0xC1: 'Extended Sequential DCT (SOF1)', 0xC2: 'Progressive DCT (SOF2)' };
          formatProps.unshift(
            { section: 'JPEG Frame & Compression', key: 'Encoding Process', value: encodingMap[marker] },
            { section: 'JPEG Frame & Compression', key: 'SOF Frame Dimensions', value: `${width} × ${height} px (${((width * height) / 1e6).toFixed(2)} MP)` },
            { section: 'JPEG Frame & Compression', key: 'Bit Depth & Channels', value: `${precision}-bit per channel × ${components} color components` }
          );
        }

        if (marker === 0xFE && segDataLen > 0) {
          const comment = new TextDecoder('utf-8', { fatal: false }).decode(u8.subarray(segStart, segStart + segDataLen)).trim();
          if (comment) {
            textMetaPool.Comment = comment;
            formatProps.push({ section: 'JPEG Embedded Comment (COM)', key: 'Comment', value: comment });
          }
        }

        structureProps.push({
          section: 'JPEG Marker Segments',
          key: `Marker 0xFF${marker.toString(16).toUpperCase()}`,
          value: `Length: ${segLen} B @ Offset 0x${offset.toString(16).toUpperCase()}`
        });

        offset += 2 + segLen;
      }

      // Deep binary fallback scan across entire file (including trailers after SOS/EOI)
      scanAllEmbeddedExifAndXmp(u8, alreadyParsedTiffOffsets, exifMap, gpsRaw, xmpMerged, textMetaPool, formatProps);

      const { aiProps, aiSummary } = parseAiGenerationMetadata(textMetaPool, u8);
      formatProps.push(...aiProps);

      return { formatProps, structureProps, photoContext: { exifMap, gpsRaw, iptcMap, xmpMerged, aiSummary } };
    }

    function parsePngChunks(u8) {
      const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
      const formatProps = [];
      const structureProps = [];
      let exifMap = {};
      let gpsRaw = {};
      let iptcMap = {};
      let xmpMerged = { editHistory: [], cameraRaw: [], fields: {} };
      const textMetaPool = {};
      const alreadyParsedTiffOffsets = new Set();
      let offset = 8;
      const colorTypes = {
        0: '0 — Grayscale',
        2: '2 — Truecolor (RGB)',
        3: '3 — Indexed-color (Palette)',
        4: '4 — Grayscale with Alpha',
        6: '6 — Truecolor with Alpha (RGBA)'
      };

      while (offset + 12 <= u8.length) {
        const length = dv.getUint32(offset, false);
        const type = new TextDecoder('ascii').decode(u8.subarray(offset + 4, offset + 8));
        const dataStart = offset + 8;
        if (dataStart + length + 4 > u8.length) break;
        const crc = dv.getUint32(dataStart + length, false).toString(16).toUpperCase().padStart(8, '0');

        structureProps.push({
          section: 'PNG Chunk Stream',
          key: `Chunk [${type}]`,
          value: `${length.toLocaleString()} B | CRC32: 0x${crc} @ 0x${offset.toString(16).toUpperCase()}`
        });

        if (type === 'IHDR' && length >= 13) {
          const w = dv.getUint32(dataStart, false);
          const h = dv.getUint32(dataStart + 4, false);
          const bitDepth = u8[dataStart + 8];
          const colorType = u8[dataStart + 9];
          const interlace = u8[dataStart + 12];
          formatProps.push(
            { section: 'PNG Image Header (IHDR)', key: 'Dimensions', value: `${w} × ${h} px (${((w * h) / 1e6).toFixed(2)} MP)` },
            { section: 'PNG Image Header (IHDR)', key: 'Bit Depth', value: `${bitDepth}-bit` },
            { section: 'PNG Image Header (IHDR)', key: 'Color Type', value: colorTypes[colorType] || String(colorType) },
            { section: 'PNG Image Header (IHDR)', key: 'Interlace Method', value: interlace === 1 ? 'Adam7 Interlaced' : 'Non-interlaced' }
          );
        } else if (type === 'pHYs' && length === 9) {
          const pxX = dv.getUint32(dataStart, false);
          const pxY = dv.getUint32(dataStart + 4, false);
          const unit = u8[dataStart + 8];
          const dpiX = unit === 1 ? Math.round(pxX * 0.0254) : pxX;
          const dpiY = unit === 1 ? Math.round(pxY * 0.0254) : pxY;
          formatProps.push({ section: 'PNG Physical Dimensions (pHYs)', key: 'Resolution', value: unit === 1 ? `${dpiX} × ${dpiY} DPI (${pxX}×${pxY} px/m)` : `${pxX} × ${pxY} (unspecified unit)` });
        } else if (type === 'tIME' && length === 7) {
          const yr = dv.getUint16(dataStart, false);
          const mo = String(u8[dataStart + 2]).padStart(2, '0');
          const da = String(u8[dataStart + 3]).padStart(2, '0');
          const hr = String(u8[dataStart + 4]).padStart(2, '0');
          const mi = String(u8[dataStart + 5]).padStart(2, '0');
          const se = String(u8[dataStart + 6]).padStart(2, '0');
          const tStr = `${yr}-${mo}-${da} ${hr}:${mi}:${se} UTC`;
          exifMap.ModifyDate = exifMap.ModifyDate || tStr;
          formatProps.push({ section: 'PNG Timestamp (tIME)', key: 'Last Modification Time', value: tStr });
        } else if (type === 'tEXt' || type === 'iTXt') {
          const rawText = new TextDecoder('utf-8', { fatal: false }).decode(u8.subarray(dataStart, dataStart + length));
          const nulIdx = rawText.indexOf('\0');
          const keyword = nulIdx > 0 ? rawText.slice(0, nulIdx) : type;
          const val = (nulIdx > 0 ? rawText.slice(nulIdx + 1) : rawText).replace(/\0+/g, ' ').trim();
          textMetaPool[keyword] = val;
          if (val.includes('<x:xmpmeta') || val.includes('<rdf:RDF')) {
            const { props, xmpData } = extractXmpAndEditHistory(val);
            formatProps.push(...props);
            xmpMerged.editHistory.push(...xmpData.editHistory);
            xmpMerged.cameraRaw.push(...xmpData.cameraRaw);
            Object.assign(xmpMerged.fields, xmpData.fields);
            Object.assign(textMetaPool, xmpData.fields);
          } else {
            formatProps.push({ section: `PNG Text Metadata (${type})`, key: keyword, value: val.slice(0, 800) });
          }
        } else if (type === 'eXIf') {
          alreadyParsedTiffOffsets.add(dataStart);
          const parsed = parseTiffBlock(dv, dataStart);
          formatProps.push(...parsed.results);
          Object.assign(exifMap, parsed.exifMap);
          Object.assign(gpsRaw, parsed.gpsRaw);
        } else if (type === 'caBX') {
          formatProps.push({ section: 'AI Provenance & Content Credentials (caBX)', key: 'C2PA JUMBF Chunk', value: `Present (${length} bytes)` });
        }

        offset += 12 + length;
        if (type === 'IEND') break;
      }

      scanAllEmbeddedExifAndXmp(u8, alreadyParsedTiffOffsets, exifMap, gpsRaw, xmpMerged, textMetaPool, formatProps);
      const { aiProps, aiSummary } = parseAiGenerationMetadata(textMetaPool, u8);
      formatProps.push(...aiProps);

      return { formatProps, structureProps, photoContext: { exifMap, gpsRaw, iptcMap, xmpMerged, aiSummary } };
    }

    // Build the 6-Pillar Photograph Explicit Summary from extracted photoContext
    function buildPhotoPillars(photoContext, fileLastModified, fileName = '') {
      if (!photoContext) return null;
      const { exifMap = {}, gpsRaw = {}, iptcMap = {}, xmpMerged = { editHistory: [], cameraRaw: [], fields: {} }, aiSummary = {} } = photoContext;
      const xf = xmpMerged.fields || {};

      // Check if filename matches Android / iOS / DSLR naming pattern (e.g. IMG_20261106_220303.jpg or PXL_20261106_...)
      let filenameDeviceHint = '';
      if (/^IMG_\d{8}_\d{6}/i.test(fileName)) {
        filenameDeviceHint = 'Android Camera Naming Pattern (IMG_YYYYMMDD_HHMMSS)';
      } else if (/^PXL_\d{8}_\d{6}/i.test(fileName)) {
        filenameDeviceHint = 'Google Pixel Camera Naming Pattern (PXL_YYYYMMDD_HHMMSS)';
      } else if (/^DSC[_F]?\d{4}/i.test(fileName)) {
        filenameDeviceHint = 'Sony / Nikon / Fujifilm Digital Camera Naming Pattern';
      } else if (/^_\?[A-Z]{3}\d{4}/i.test(fileName) || /^IMG_\d{4}\.(JPG|HEIC)/i.test(fileName)) {
        filenameDeviceHint = 'Apple iOS / Canon Naming Pattern (IMG_XXXX)';
      }

      const hasBasicTimestamps = Boolean(exifMap.DateTimeOriginal || exifMap.ModifyDate || exifMap.DateTimeDigitized);
      const hasCameraMakeOrModel = Boolean(exifMap.CameraMake || exifMap.CameraModel || xf['tiff:Make'] || xf['tiff:Model'] || exifMap.UniqueCameraModel);
      const hasGpsCoords = Boolean(gpsRaw.formattedCoordinates || xf['exif:GPSLatitude']);
      const isLikelyScrubbedByTransfer = hasBasicTimestamps && !hasCameraMakeOrModel && !hasGpsCoords && !aiSummary.detected;

      // 1. Camera / Device Information
      const cameraRows = [
        ['Camera Make', exifMap.CameraMake || xf['tiff:Make'] || (filenameDeviceHint ? `Not in EXIF (${filenameDeviceHint})` : 'Not embedded in file')],
        ['Camera Model', exifMap.CameraModel || xf['tiff:Model'] || exifMap.UniqueCameraModel || exifMap.HostComputer || 'Not embedded in file'],
        ['Lens Make & Model', [exifMap.LensMake, exifMap.LensModel || xf['aux:Lens']].filter(Boolean).join(' — ') || 'Not embedded in file'],
        ['Lens Specification & Focal Length', [exifMap.LensSpecification, exifMap.FocalLength ? `Shot at ${exifMap.FocalLength}` : '', exifMap.FocalLengthIn35mmFormat ? `(35mm eq: ${exifMap.FocalLengthIn35mmFormat})` : ''].filter(Boolean).join(' ') || 'Not embedded in file'],
        ['Exposure Triad', [exifMap.ExposureTime, exifMap.FNumber, exifMap.ISO ? `ISO ${exifMap.ISO}` : ''].filter(Boolean).join(' · ') || 'Not embedded in file'],
        ['Firmware / Device Software', xf['aux:Firmware'] || exifMap.Software || xf['xmp:CreatorTool'] || exifMap.ExifVersion ? [xf['aux:Firmware'] || exifMap.Software || xf['xmp:CreatorTool'], exifMap.ExifVersion ? `(EXIF v${exifMap.ExifVersion})` : ''].filter(Boolean).join(' ') : 'Not embedded in file'],
        ['Body & Lens Serial Numbers', [exifMap.BodySerialNumber || xf['aux:SerialNumber'] ? `Body: ${exifMap.BodySerialNumber || xf['aux:SerialNumber']}` : '', exifMap.LensSerialNumber ? `Lens: ${exifMap.LensSerialNumber}` : ''].filter(Boolean).join(' | ') || 'Not embedded in file']
      ];

      // 2. Timestamps (Taken, Digitized, Modified)
      const origTime = [exifMap.DateTimeOriginal || xf['exif:DateTimeOriginal'] || xf['photoshop:DateCreated'], exifMap.SubSecTimeOriginal ? `.${exifMap.SubSecTimeOriginal}` : '', exifMap.OffsetTimeOriginal || ''].filter(Boolean).join('');
      const digiTime = [exifMap.DateTimeDigitized || xf['xmp:CreateDate'], exifMap.SubSecTimeDigitized ? `.${exifMap.SubSecTimeDigitized}` : '', exifMap.OffsetTimeDigitized || ''].filter(Boolean).join('');
      const modTime = [exifMap.ModifyDate || xf['xmp:ModifyDate'], exifMap.SubSecTime ? `.${exifMap.SubSecTime}` : '', exifMap.OffsetTime || ''].filter(Boolean).join('');
      const timestampRows = [
        ['Date/Time Taken (Original)', origTime || 'Not embedded in file'],
        ['Date/Time Digitized (CreateDate)', digiTime || 'Not embedded in file'],
        ['Date/Time Last Modified (EXIF/XMP)', modTime || 'Not embedded in file'],
        ['Sub-Second & Timezone Offset', [exifMap.SubSecTimeOriginal ? `${exifMap.SubSecTimeOriginal}ms` : '', exifMap.OffsetTimeOriginal || exifMap.OffsetTime || ''].filter(Boolean).join(' ') || 'Not embedded in file'],
        ['File System Last Modified', fileLastModified ? new Date(fileLastModified).toISOString() : 'N/A']
      ];

      // 3. GPS Coordinates (Latitude, Longitude, Altitude, Timestamp)
      const gpsRows = [
        ['Latitude & Longitude', gpsRaw.formattedCoordinates || (xf['exif:GPSLatitude'] ? `${xf['exif:GPSLatitude']}, ${xf['exif:GPSLongitude']}` : 'No GPS coordinates embedded in file')],
        ['Altitude (Elevation)', gpsRaw.formattedAltitude || xf['exif:GPSAltitude'] || 'Not embedded in file'],
        ['GPS Satellite Timestamp (UTC)', gpsRaw.formattedTimestamp || xf['exif:GPSTimeStamp'] || 'Not embedded in file'],
        ['Heading / Bearing & Speed', [gpsRaw.GPSImgDirection !== undefined ? `${gpsRaw.GPSImgDirection}° (${gpsRaw.GPSImgDirectionRef || 'T'})` : '', gpsRaw.GPSSpeed !== undefined ? `${gpsRaw.GPSSpeed} ${gpsRaw.GPSSpeedRef || 'km/h'}` : ''].filter(Boolean).join(' | ') || 'Not embedded in file'],
        ['Geodetic Map Datum & Method', [gpsRaw.GPSMapDatum, gpsRaw.GPSProcessingMethod ? `Method: ${gpsRaw.GPSProcessingMethod}` : '', gpsRaw.GPSSatellites ? `Satellites: ${gpsRaw.GPSSatellites}` : ''].filter(Boolean).join(' | ') || 'Not embedded in file']
      ];

      // 4. Creator & Copyright Fields
      const creatorRows = [
        ['Photographer / Creator Name', exifMap.Artist || xf['dc:creator'] || iptcMap['By-line (Photographer / Creator)'] || exifMap.CameraOwnerName || 'Not embedded in file'],
        ['Copyright Notice', exifMap.Copyright || xf['dc:rights'] || iptcMap.CopyrightNotice || 'Not embedded in file'],
        ['Licensing Terms & Rights Status', [xf['xmpRights:UsageTerms'], xf['xmpRights:Marked'] ? `(Copyrighted: ${xf['xmpRights:Marked']})` : ''].filter(Boolean).join(' ') || 'Not embedded in file'],
        ['License / Rights Web Statement URL', xf['xmpRights:WebStatement'] || xf['cc:license'] || 'Not embedded in file'],
        ['Credit & Source Line', [xf['photoshop:Credit'] || iptcMap.Credit, xf['photoshop:Source'] || iptcMap.Source].filter(Boolean).join(' — ') || 'Not embedded in file']
      ];

      // 5. Software & Editing History
      const historyLogSummary = xmpMerged.editHistory.length > 0
        ? xmpMerged.editHistory.map(h => `[#${h.step}] ${h.action || 'edit'} via ${h.softwareAgent || 'app'} (${h.when || 'timestamp'}) ${h.parameters ? '— ' + h.parameters : ''}`).join(' → ')
        : 'No structured XMP step-by-step edit log present';
      const softwareRows = [
        ['Primary Editing Application', exifMap.Software || xf['xmp:CreatorTool'] || 'Not embedded in file'],
        ['Document & Instance IDs', [xf['xmpMM:DocumentID'] ? `Doc: ${xf['xmpMM:DocumentID']}` : '', xf['xmpMM:InstanceID'] ? `Inst: ${xf['xmpMM:InstanceID']}` : ''].filter(Boolean).join(' | ') || 'Not embedded in file'],
        ['Edit History Log Steps Count', `${xmpMerged.editHistory.length} recorded XMP history event(s)`],
        ['Full Edit Log Trail', historyLogSummary],
        ['Camera Raw / Parametric Edits', xmpMerged.cameraRaw.length > 0 ? xmpMerged.cameraRaw.slice(0, 8).join(', ') : 'None detected']
      ];

      // 6. AI-Generation Markers
      const aiRows = [
        ['AI Generation Status', aiSummary.detected ? 'AI-Generated / Algorithmic Media Markers Detected' : 'No AI generation markers detected (Standard Camera/Graphic)'],
        ['AI Generator / Pipeline', aiSummary.generator || xf['c2pa:generator'] || 'None'],
        ['AI Model Name & Version', [aiSummary.modelName || xf['c2pa:model'], aiSummary.modelVersion || xf['c2pa:version'] ? `(${aiSummary.modelVersion || xf['c2pa:version']})` : ''].filter(Boolean).join(' ') || 'None'],
        ['AI Positive Prompt', aiSummary.positivePrompt || xf['c2pa:prompt'] || 'None'],
        ['AI Negative Prompt', aiSummary.negativePrompt || xf['c2pa:negativePrompt'] || 'None'],
        ['Seed, Sampler, Steps & C2PA', [
          aiSummary.seed ? `Seed: ${aiSummary.seed}` : '',
          aiSummary.sampler ? `Sampler: ${aiSummary.sampler}` : '',
          aiSummary.steps ? `Steps: ${aiSummary.steps}` : '',
          aiSummary.cfgScale ? `CFG: ${aiSummary.cfgScale}` : '',
          aiSummary.c2paManifest ? `C2PA: ${aiSummary.c2paManifest}` : ''
        ].filter(Boolean).join(' | ') || 'None']
      ];

      return {
        isLikelyScrubbedByTransfer,
        filenameDeviceHint,
        pillars: [
          { title: '1. Camera & Device Information', icon: '📷', accent: 'sky', rows: cameraRows },
          { title: '2. Capture & Digitized Timestamps', icon: '🕒', accent: 'indigo', rows: timestampRows },
          { title: '3. GPS Coordinates, Altitude & UTC Time', icon: '🌍', accent: 'emerald', rows: gpsRows },
          { title: '4. Creator, Copyright & Licensing', icon: '©️', accent: 'amber', rows: creatorRows },
          { title: '5. Software & Editing History Log', icon: '🛠️', accent: 'rose', rows: softwareRows },
          { title: '6. AI-Generation Markers & Prompts', icon: '✨', accent: 'purple', rows: aiRows }
        ]
      };
    }

    // =========================================================================
    // DEEP PDF DOCUMENT PARSER
    // =========================================================================
    function formatPdfDate(raw) {
      const m = String(raw).match(/D:(\d{4})(\d{2})?(\d{2})?(\d{2})?(\d{2})?(\d{2})?([+-Z].*)?/);
      if (!m) return raw;
      const [, yr, mo = '01', da = '01', hr = '00', mi = '00', se = '00', tz = ''] = m;
      return `${yr}-${mo}-${da} ${hr}:${mi}:${se} ${tz.replace(/'/g, ':')}`.trim();
    }

    function decodePdfString(str) {
      const cleaned = str.replace(/\\([nrtbf()\\])/g, (_, c) => {
        const map = { n: '\n', r: '\r', t: '\t', b: '\b', f: '\f', '(': '(', ')': ')', '\\': '\\' };
        return map[c] || c;
      }).replace(/\\([0-7]{1,3})/g, (_, oct) => String.fromCharCode(parseInt(oct, 8)));

      if (cleaned.charCodeAt(0) === 0xFE && cleaned.charCodeAt(1) === 0xFF) {
        let out = '';
        for (let i = 2; i + 1 < cleaned.length; i += 2) {
          out += String.fromCharCode((cleaned.charCodeAt(i) << 8) | cleaned.charCodeAt(i + 1));
        }
        return out;
      }
      return cleaned;
    }

    function parsePdfDocument(u8) {
      const sampleBytes = u8.length > 4 * 1024 * 1024 ? u8.subarray(0, 4 * 1024 * 1024) : u8;
      const text = new TextDecoder('latin1').decode(sampleBytes);
      const formatProps = [];
      const structureProps = [];

      const verMatch = text.slice(0, 64).match(/%PDF-(\d+\.\d+)/);
      if (verMatch) {
        formatProps.push({ section: 'PDF Specification', key: 'PDF Version', value: `PDF ${verMatch[1]}` });
      }

      if (/\/Linearized\s+\d/.test(text.slice(0, 2048))) {
        formatProps.push({ section: 'PDF Specification', key: 'Fast Web View (Linearized)', value: 'Yes (Linearized PDF)' });
      } else {
        formatProps.push({ section: 'PDF Specification', key: 'Fast Web View (Linearized)', value: 'No' });
      }

      const infoKeys = ['Title', 'Author', 'Subject', 'Keywords', 'Creator', 'Producer', 'CreationDate', 'ModDate', 'Trapped'];
      for (const k of infoKeys) {
        const litRegex = new RegExp(`\\/${k}\\s*\\(([^\\r\\n)]{1,500})\\)`, 'g');
        let lastMatch = null;
        let m;
        while ((m = litRegex.exec(text)) !== null) lastMatch = m[1];
        if (lastMatch !== null) {
          let decoded = decodePdfString(lastMatch).trim();
          if (k.endsWith('Date')) decoded = formatPdfDate(decoded);
          if (decoded) {
            formatProps.push({
              section: 'PDF Document Info Dictionary',
              key: k,
              value: decoded,
              isPII: ['Author', 'Creator'].includes(k)
            });
          }
          continue;
        }
        const hexRegex = new RegExp(`\\/${k}\\s*<([0-9A-Fa-f\\s]{2,500})>`, 'g');
        while ((m = hexRegex.exec(text)) !== null) lastMatch = m[1];
        if (lastMatch !== null) {
          const hexClean = lastMatch.replace(/\s+/g, '');
          const bytes = [];
          for (let i = 0; i < hexClean.length; i += 2) bytes.push(parseInt(hexClean.slice(i, i + 2), 16));
          let decoded = decodePdfString(String.fromCharCode(...bytes)).trim();
          if (k.endsWith('Date')) decoded = formatPdfDate(decoded);
          if (decoded) {
            formatProps.push({
              section: 'PDF Document Info Dictionary',
              key: k,
              value: decoded,
              isPII: ['Author', 'Creator'].includes(k)
            });
          }
        }
      }

      let maxCount = 0;
      const countRegex = /\/Type\s*\/Pages\b[^>>]{0,250}?\/Count\s+(\d+)|\/Count\s+(\d+)[^>>]{0,250}?\/Type\s*\/Pages\b/gs;
      let cm;
      while ((cm = countRegex.exec(text)) !== null) {
        const n = parseInt(cm[1] || cm[2], 10);
        if (n > maxCount && n < 100000) maxCount = n;
      }
      const pageLeafMatches = text.match(/\/Type\s*\/Page\b(?!s)/g);
      const pageCount = maxCount || (pageLeafMatches ? pageLeafMatches.length : 1);
      formatProps.push({ section: 'PDF Specification', key: 'Page Count', value: String(pageCount) });

      const mediaBoxMatch = text.match(/\/MediaBox\s*\[\s*([-\d.]+)\s+([-\d.]+)\s+([-\d.]+)\s+([-\d.]+)\s*\]/);
      if (mediaBoxMatch) {
        const wPt = parseFloat(mediaBoxMatch[3]) - parseFloat(mediaBoxMatch[1]);
        const hPt = parseFloat(mediaBoxMatch[4]) - parseFloat(mediaBoxMatch[2]);
        const wIn = (wPt / 72).toFixed(2);
        const hIn = (hPt / 72).toFixed(2);
        const wMm = Math.round((wPt / 72) * 25.4);
        const hMm = Math.round((hPt / 72) * 25.4);
        formatProps.push({
          section: 'PDF Specification',
          key: 'Page Size (MediaBox)',
          value: `${wPt} × ${hPt} pt (${wIn}" × ${hIn}" / ${wMm} × ${hMm} mm)`
        });
      }

      const fontMatches = [...text.matchAll(/\/BaseFont\s*\/([A-Za-z0-9+_-]+)/g)].map(m => m[1]);
      const uniqueFonts = [...new Set(fontMatches)];
      if (uniqueFonts.length > 0) {
        formatProps.push({
          section: 'PDF Typography & Assets',
          key: `Referenced Fonts (${uniqueFonts.length})`,
          value: uniqueFonts.slice(0, 15).join(', ')
        });
      }

      const objCount = (text.match(/\b\d+\s+\d+\s+obj\b/g) || []).length;
      const streamCount = (text.match(/\bstream\b/g) || []).length;
      const imageXObjects = (text.match(/\/Subtype\s*\/Image\b/g) || []).length;
      const hasEncrypt = /\/Encrypt\b/.test(text);
      const hasJS = /\/JS\b|\/JavaScript\b/.test(text);
      const hasAcroForm = /\/AcroForm\b/.test(text);
      const hasSig = /\/Sig\b|\/ByteRange\b/.test(text);
      const hasOutlines = /\/Outlines\b/.test(text);

      structureProps.push(
        { section: 'PDF Internal Object Graph', key: 'Indirect Objects (obj)', value: String(objCount) },
        { section: 'PDF Internal Object Graph', key: 'Binary / Compressed Streams', value: String(streamCount) },
        { section: 'PDF Internal Object Graph', key: 'Embedded Image XObjects', value: String(imageXObjects) },
        { section: 'PDF Security & Interactive Features', key: 'Encryption (/Encrypt)', value: hasEncrypt ? 'Encrypted / Password-Protected' : 'Unencrypted' },
        { section: 'PDF Security & Interactive Features', key: 'Embedded JavaScript (/JS)', value: hasJS ? 'Present (Inspect Carefully!)' : 'None detected' },
        { section: 'PDF Security & Interactive Features', key: 'Interactive Form Fields (/AcroForm)', value: hasAcroForm ? 'Present' : 'None' },
        { section: 'PDF Security & Interactive Features', key: 'Digital Signatures (/Sig)', value: hasSig ? 'Present' : 'None' },
        { section: 'PDF Security & Interactive Features', key: 'Bookmarks / Document Outline', value: hasOutlines ? 'Present' : 'None' }
      );

      const xmpStart = text.indexOf('<x:xmpmeta');
      if (xmpStart !== -1) {
        const xmpEnd = text.indexOf('</x:xmpmeta>', xmpStart);
        if (xmpEnd !== -1) {
          const xmpXml = text.slice(xmpStart, xmpEnd + 12);
          const { props } = extractXmpAndEditHistory(xmpXml);
          formatProps.push(...props);
        }
      }

      return { formatProps, structureProps };
    }

    // =========================================================================
    // ZIP / OPENXML (DOCX, PPTX, XLSX) / EPUB / ODF CONTAINER PARSER
    // =========================================================================
    async function inflateRawBytes(compressedU8) {
      if (typeof DecompressionStream !== 'undefined') {
        try {
          const ds = new DecompressionStream('deflate-raw');
          const writer = ds.writable.getWriter();
          writer.write(compressedU8).catch(() => {});
          writer.close().catch(() => {});
          const reader = ds.readable.getReader();
          const chunks = [];
          let total = 0;
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            chunks.push(value);
            total += value.length;
          }
          const out = new Uint8Array(total);
          let pos = 0;
          for (const c of chunks) { out.set(c, pos); pos += c.length; }
          return out;
        } catch (e) {}
      }
      return null;
    }

    async function parseZipBasedDocument(u8) {
      const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
      const formatProps = [];
      const structureProps = [];
      const entries = [];

      let eocdPos = -1;
      const minPos = Math.max(0, u8.length - 65557);
      for (let i = u8.length - 22; i >= minPos; i--) {
        if (dv.getUint32(i, true) === 0x06054b50) {
          eocdPos = i;
          break;
        }
      }

      if (eocdPos !== -1) {
        const totalEntries = dv.getUint16(eocdPos + 10, true);
        const cdOffset = dv.getUint32(eocdPos + 16, true);
        const commentLen = dv.getUint16(eocdPos + 20, true);
        if (commentLen > 0 && eocdPos + 22 + commentLen <= u8.length) {
          const zipComment = new TextDecoder('utf-8', { fatal: false }).decode(u8.subarray(eocdPos + 22, eocdPos + 22 + commentLen));
          formatProps.push({ section: 'Archive Container', key: 'ZIP Archive Comment', value: zipComment });
        }

        let ptr = cdOffset;
        for (let i = 0; i < totalEntries && ptr + 46 <= u8.length; i++) {
          if (dv.getUint32(ptr, true) !== 0x02014b50) break;
          const compMethod = dv.getUint16(ptr + 10, true);
          const dosTime = dv.getUint16(ptr + 12, true);
          const dosDate = dv.getUint16(ptr + 14, true);
          const crc = dv.getUint32(ptr + 16, true).toString(16).toUpperCase().padStart(8, '0');
          const compSize = dv.getUint32(ptr + 20, true);
          const uncompSize = dv.getUint32(ptr + 24, true);
          const nameLen = dv.getUint16(ptr + 28, true);
          const extraLen = dv.getUint16(ptr + 30, true);
          const commLen = dv.getUint16(ptr + 32, true);
          const localHdrOffset = dv.getUint32(ptr + 42, true);
          const name = new TextDecoder('utf-8', { fatal: false }).decode(u8.subarray(ptr + 46, Math.min(u8.length, ptr + 46 + nameLen)));

          const yr = ((dosDate >> 9) & 0x7F) + 1980;
          const mo = String((dosDate >> 5) & 0x0F).padStart(2, '0');
          const da = String(dosDate & 0x1F).padStart(2, '0');
          const hr = String((dosTime >> 11) & 0x1F).padStart(2, '0');
          const mi = String((dosTime >> 5) & 0x3F).padStart(2, '0');
          const se = String((dosTime & 0x1F) * 2).padStart(2, '0');

          entries.push({
            name, compMethod, compSize, uncompSize, crc, localHdrOffset,
            modTime: `${yr}-${mo}-${da} ${hr}:${mi}:${se}`
          });
          ptr += 46 + nameLen + extraLen + commLen;
        }
      } else {
        let ptr = 0;
        while (ptr + 30 <= u8.length) {
          if (dv.getUint32(ptr, true) !== 0x04034b50) break;
          const compMethod = dv.getUint16(ptr + 8, true);
          const crc = dv.getUint32(ptr + 14, true).toString(16).toUpperCase().padStart(8, '0');
          const compSize = dv.getUint32(ptr + 18, true);
          const uncompSize = dv.getUint32(ptr + 22, true);
          const nameLen = dv.getUint16(ptr + 26, true);
          const extraLen = dv.getUint16(ptr + 28, true);
          const name = new TextDecoder('utf-8', { fatal: false }).decode(u8.subarray(ptr + 30, Math.min(u8.length, ptr + 30 + nameLen)));
          entries.push({ name, compMethod, compSize, uncompSize, crc, localHdrOffset: ptr, modTime: 'N/A' });
          if (compSize === 0 && uncompSize > 0) break;
          ptr += 30 + nameLen + extraLen + compSize;
        }
      }

      async function readZipEntryText(entry) {
        if (!entry) return null;
        const p = entry.localHdrOffset;
        if (p + 30 > u8.length || dv.getUint32(p, true) !== 0x04034b50) return null;
        const nameLen = dv.getUint16(p + 26, true);
        const extraLen = dv.getUint16(p + 28, true);
        const dataStart = p + 30 + nameLen + extraLen;
        if (dataStart + entry.compSize > u8.length) return null;
        const slice = u8.subarray(dataStart, dataStart + entry.compSize);
        if (entry.compMethod === 0) {
          return new TextDecoder('utf-8', { fatal: false }).decode(slice);
        }
        if (entry.compMethod === 8) {
          const inflated = await inflateRawBytes(slice);
          if (inflated) return new TextDecoder('utf-8', { fatal: false }).decode(inflated);
        }
        return null;
      }

      let totalUncomp = 0;
      let totalComp = 0;
      let mediaFiles = 0;
      let slideEntries = 0;
      let sheetEntries = 0;

      for (const e of entries) {
        totalUncomp += e.uncompSize;
        totalComp += e.compSize;
        if (/^(word|ppt|xl)\/media\//i.test(e.name) || /\.(png|jpg|jpeg|gif|svg|webp|mp4|mp3)$/i.test(e.name)) mediaFiles++;
        if (/^ppt\/slides\/slide\d+\.xml$/i.test(e.name)) slideEntries++;
        if (/^xl\/worksheets\/sheet\d+\.xml$/i.test(e.name)) sheetEntries++;
        structureProps.push({
          section: 'Package Internal Files (ZIP Central Directory)',
          key: e.name,
          value: `${e.uncompSize.toLocaleString()} B (Compressed: ${e.compSize.toLocaleString()} B | Method: ${e.compMethod === 0 ? 'Stored' : e.compMethod === 8 ? 'Deflate' : e.compMethod} | CRC: ${e.crc})`
        });
      }

      formatProps.push(
        { section: 'Package Summary', key: 'Packaged Streams / Files', value: String(entries.length) },
        { section: 'Package Summary', key: 'Uncompressed Payload Size', value: formatBytes(totalUncomp) },
        { section: 'Package Summary', key: 'Compression Ratio', value: totalUncomp > 0 ? `${((1 - totalComp / totalUncomp) * 100).toFixed(1)}% saved` : '0%' },
        { section: 'Package Summary', key: 'Embedded Media Assets', value: String(mediaFiles) }
      );
      if (slideEntries > 0) formatProps.push({ section: 'Presentation Structure', key: 'Detected Slide XML Parts', value: String(slideEntries) });
      if (sheetEntries > 0) formatProps.push({ section: 'Workbook Structure', key: 'Detected Worksheet XML Parts', value: String(sheetEntries) });

      const coreEntry = entries.find(e => e.name.toLowerCase() === 'docprops/core.xml');
      if (coreEntry) {
        const xml = await readZipEntryText(coreEntry);
        if (xml) {
          const coreTags = [
            ['dc:title', 'Title', false],
            ['dc:subject', 'Subject', false],
            ['dc:creator', 'Author / Creator', true],
            ['cp:keywords', 'Keywords', false],
            ['dc:description', 'Description / Comments', false],
            ['cp:lastModifiedBy', 'Last Modified By', true],
            ['cp:revision', 'Revision Number', false],
            ['cp:LastPrinted', 'Last Printed Date', false],
            ['dcterms:created', 'Created Timestamp', false],
            ['dcterms:modified', 'Modified Timestamp', false],
            ['cp:category', 'Category', false],
            ['cp:contentStatus', 'Content Status', false],
            ['dc:language', 'Language', false]
          ];
          for (const [tag, label, isPII] of coreTags) {
            const m = xml.match(new RegExp(`<${tag}[^>]*>([^<]+)<\\/${tag}>`, 'i'));
            if (m && m[1].trim()) {
              formatProps.push({ section: 'OpenXML Core Properties (docProps/core.xml)', key: label, value: m[1].trim(), isPII });
            }
          }
        }
      }

      const appEntry = entries.find(e => e.name.toLowerCase() === 'docprops/app.xml');
      if (appEntry) {
        const xml = await readZipEntryText(appEntry);
        if (xml) {
          const appTags = [
            ['Application', 'Creating Application'],
            ['AppVersion', 'Application Version'],
            ['Template', 'Document Template'],
            ['Manager', 'Manager'],
            ['Company', 'Company / Organization'],
            ['TotalTime', 'Total Editing Time (Minutes)'],
            ['Pages', 'Page Count'],
            ['Words', 'Word Count'],
            ['Characters', 'Character Count'],
            ['CharactersWithSpaces', 'Characters (with spaces)'],
            ['Lines', 'Line Count'],
            ['Paragraphs', 'Paragraph Count'],
            ['Slides', 'Slide Count'],
            ['Notes', 'Speaker Notes Count'],
            ['HiddenSlides', 'Hidden Slides'],
            ['MMClips', 'Multimedia Clips'],
            ['PresentationFormat', 'Presentation Aspect / Target'],
            ['DocSecurity', 'Document Security Flag'],
            ['HyperlinksChanged', 'Hyperlinks Changed']
          ];
          for (const [tag, label] of appTags) {
            const m = xml.match(new RegExp(`<${tag}[^>]*>([^<]+)<\\/${tag}>`, 'i'));
            if (m && m[1].trim()) {
              formatProps.push({
                section: 'OpenXML Application Properties (docProps/app.xml)',
                key: label,
                value: m[1].trim(),
                isPII: ['Company', 'Manager'].includes(tag)
              });
            }
          }
        }
      }

      const customEntry = entries.find(e => e.name.toLowerCase() === 'docprops/custom.xml');
      if (customEntry) {
        const xml = await readZipEntryText(customEntry);
        if (xml) {
          const propRegex = /<property[^>]*name="([^"]+)"[^>]*>([\s\S]*?)<\/property>/gi;
          let pm;
          while ((pm = propRegex.exec(xml)) !== null) {
            const name = pm[1];
            const inner = pm[2].replace(/<[^>]+>/g, '').trim();
            if (inner) formatProps.push({ section: 'OpenXML Custom Properties (docProps/custom.xml)', key: name, value: inner });
          }
        }
      }

      const containerEntry = entries.find(e => e.name.toLowerCase() === 'meta-inf/container.xml');
      let opfPath = null;
      if (containerEntry) {
        const cXml = await readZipEntryText(containerEntry);
        if (cXml) {
          const m = cXml.match(/full-path="([^"]+)"/i);
          if (m) opfPath = m[1];
        }
      }
      const opfEntry = entries.find(e => (opfPath && e.name === opfPath) || e.name.toLowerCase().endsWith('.opf'));
      if (opfEntry) {
        const opfXml = await readZipEntryText(opfEntry);
        if (opfXml) {
          formatProps.push({ section: 'EPUB Package (OPF)', key: 'OPF Rootfile Path', value: opfEntry.name });
          const verM = opfXml.match(/<package[^>]*version="([^"]+)"/i);
          if (verM) formatProps.push({ section: 'EPUB Package (OPF)', key: 'EPUB Specification Version', value: verM[1] });

          const dcFields = [
            ['dc:title', 'Book Title'],
            ['dc:creator', 'Author / Creator'],
            ['dc:contributor', 'Contributor'],
            ['dc:publisher', 'Publisher'],
            ['dc:identifier', 'Identifier (ISBN / UUID)'],
            ['dc:language', 'Language'],
            ['dc:date', 'Publication Date'],
            ['dc:subject', 'Subject / Genre'],
            ['dc:description', 'Synopsis / Description'],
            ['dc:rights', 'Copyright & Rights'],
            ['dc:source', 'Source'],
            ['dc:type', 'Publication Type']
          ];
          for (const [tag, label] of dcFields) {
            const matches = [...opfXml.matchAll(new RegExp(`<${tag}[^>]*>([\\s\\S]*?)<\\/${tag}>`, 'gi'))];
            for (const m of matches) {
              const val = m[1].replace(/<[^>]+>/g, '').trim();
              if (val) formatProps.push({ section: 'EPUB Dublin Core Metadata', key: label, value: val });
            }
          }
          const metaPropRegex = /<meta[^>]*property="([^"]+)"[^>]*>([^<]+)<\/meta>/gi;
          let mm;
          while ((mm = metaPropRegex.exec(opfXml)) !== null) {
            formatProps.push({ section: 'EPUB Extended Meta', key: mm[1], value: mm[2].trim() });
          }
          const metaNameRegex = /<meta[^>]*name="([^"]+)"[^>]*content="([^"]+)"/gi;
          while ((mm = metaNameRegex.exec(opfXml)) !== null) {
            formatProps.push({ section: 'EPUB Extended Meta', key: mm[1], value: mm[2].trim() });
          }
          const itemCount = (opfXml.match(/<item\b/gi) || []).length;
          const spineCount = (opfXml.match(/<itemref\b/gi) || []).length;
          formatProps.push(
            { section: 'EPUB Spine & Manifest', key: 'Manifest Resource Items', value: String(itemCount) },
            { section: 'EPUB Spine & Manifest', key: 'Reading Order Chapters (Spine)', value: String(spineCount) }
          );
        }
      }

      const odfMetaEntry = entries.find(e => e.name.toLowerCase() === 'meta.xml');
      if (odfMetaEntry) {
        const odfXml = await readZipEntryText(odfMetaEntry);
        if (odfXml) {
          const { props } = extractXmpAndEditHistory(odfXml);
          formatProps.push(...props);
        }
      }

      return { formatProps, structureProps };
    }

    // =========================================================================
    // LEGACY MICROSOFT OFFICE OLE2 COMPOUND DOCUMENT PARSER (.DOC, .XLS, .PPT)
    // =========================================================================
    function parseOle2CompoundFile(u8) {
      const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
      const formatProps = [];
      const structureProps = [];

      if (u8.length >= 512) {
        const minorVer = dv.getUint16(24, true);
        const majorVer = dv.getUint16(26, true);
        const sectorShift = dv.getUint16(30, true);
        const sectorSize = 1 << sectorShift;
        const miniSectorShift = dv.getUint16(32, true);
        const numFatSectors = dv.getUint32(44, true);
        const firstDirSector = dv.getUint32(48, true);

        formatProps.push(
          { section: 'OLE2 Compound File Header', key: 'CFB Format Version', value: `${majorVer}.${minorVer} (${majorVer === 4 ? '4096-byte sectors' : '512-byte sectors'})` },
          { section: 'OLE2 Compound File Header', key: 'Sector Size', value: `${sectorSize} bytes (Mini-sector: ${1 << miniSectorShift} B)` },
          { section: 'OLE2 Compound File Header', key: 'FAT Sectors Count', value: String(numFatSectors) },
          { section: 'OLE2 Compound File Header', key: 'First Directory Sector Index', value: String(firstDirSector) }
        );

        const dirOffset = (firstDirSector + 1) * sectorSize;
        if (dirOffset + sectorSize <= u8.length) {
          for (let pos = dirOffset; pos + 128 <= Math.min(u8.length, dirOffset + sectorSize * 4); pos += 128) {
            const nameByteLen = dv.getUint16(pos + 64, true);
            if (nameByteLen <= 2 || nameByteLen > 64) continue;
            let name = '';
            for (let i = 0; i < nameByteLen - 2; i += 2) {
              const ch = dv.getUint16(pos + i, true);
              if (ch >= 32 && ch <= 126) name += String.fromCharCode(ch);
            }
            const objType = u8[pos + 66];
            const streamSize = dv.getUint32(pos + 120, true);
            const typeMap = { 1: 'Storage (Folder)', 2: 'Stream', 5: 'Root Storage' };
            if (name) {
              structureProps.push({
                section: 'OLE2 Directory Streams',
                key: name,
                value: `${typeMap[objType] || 'Entry'} | Size: ${streamSize.toLocaleString()} B`
              });
            }
          }
        }

        const summaryGuid = [0xE0, 0x85, 0x9F, 0xF2, 0xF9, 0x4F, 0x68, 0x10, 0xAB, 0x91, 0x08, 0x00, 0x2B, 0x27, 0xB3, 0xD9];
        for (let i = 512; i + 68 < u8.length; i++) {
          let match = true;
          for (let k = 0; k < 16; k++) {
            if (u8[i + k] !== summaryGuid[k]) { match = false; break; }
          }
          if (match) {
            const sectionOffset = dv.getUint32(i + 16, true);
            const propSetStart = i - 28 + sectionOffset;
            if (propSetStart > 0 && propSetStart + 8 <= u8.length) {
              const numProps = dv.getUint32(propSetStart + 4, true);
              const pidMap = {
                2: 'Title', 3: 'Subject', 4: 'Author', 5: 'Keywords',
                6: 'Comments', 7: 'Template', 8: 'Last Saved By',
                9: 'Revision Number', 18: 'Creating Application'
              };
              for (let p = 0; p < Math.min(numProps, 32); p++) {
                const pairPos = propSetStart + 8 + p * 8;
                if (pairPos + 8 > u8.length) break;
                const pid = dv.getUint32(pairPos, true);
                const valRelOffset = dv.getUint32(pairPos + 4, true);
                const valPos = propSetStart + valRelOffset;
                if (valPos + 8 <= u8.length && pidMap[pid]) {
                  const vtType = dv.getUint32(valPos, true);
                  if (vtType === 30) {
                    const strLen = dv.getUint32(valPos + 4, true);
                    if (strLen > 0 && strLen < 512 && valPos + 8 + strLen <= u8.length) {
                      const s = new TextDecoder('latin1').decode(u8.subarray(valPos + 8, valPos + 8 + strLen)).replace(/\0+/g, '').trim();
                      if (s) {
                        formatProps.push({
                          section: 'OLE2 SummaryInformation Stream',
                          key: pidMap[pid],
                          value: s,
                          isPII: [4, 8].includes(pid)
                        });
                      }
                    }
                  }
                }
              }
            }
            break;
          }
        }
      }

      return { formatProps, structureProps };
    }

    // =========================================================================
    // VIDEO & AUDIO CONTAINER PARSERS (MP4/MOV/HEIC ISO BMFF, MKV/WEBM, WAV, MP3)
    // =========================================================================
    function parseIsoBmffMedia(u8, isImageFamily = false) {
      const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
      const formatProps = [];
      const structureProps = [];
      const containerBoxes = new Set(['moov', 'trak', 'mdia', 'minf', 'stbl', 'edts', 'udta', 'meta', 'ilst']);

      function walkBoxes(start, end, depth = 0) {
        let pos = start;
        while (pos + 8 <= end) {
          let size = dv.getUint32(pos, false);
          const type = new TextDecoder('ascii').decode(u8.subarray(pos + 4, pos + 8));
          let hdrSize = 8;
          if (size === 1 && pos + 16 <= end) {
            size = Number(dv.getBigUint64(pos + 8, false));
            hdrSize = 16;
          } else if (size === 0) {
            size = end - pos;
          }
          if (size < hdrSize || pos + size > end || !/^[\x20-\x7E©]{4}$/.test(type)) break;

          structureProps.push({
            section: 'ISO BMFF / MP4 Box Hierarchy',
            key: `${'  '.repeat(depth)}[${type}] Atom`,
            value: `${size.toLocaleString()} B @ 0x${pos.toString(16).toUpperCase()}`
          });

          const bodyStart = pos + hdrSize;

          if (type === 'ftyp' && size >= 16) {
            const majorBrand = new TextDecoder('ascii').decode(u8.subarray(bodyStart, bodyStart + 4));
            const minorVer = dv.getUint32(bodyStart + 4, false);
            const compat = [];
            for (let c = bodyStart + 8; c + 4 <= pos + size; c += 4) {
              compat.push(new TextDecoder('ascii').decode(u8.subarray(c, c + 4)));
            }
            formatProps.push(
              { section: 'Container Specification (ftyp)', key: 'Major Brand', value: majorBrand },
              { section: 'Container Specification (ftyp)', key: 'Minor Version', value: String(minorVer) },
              { section: 'Container Specification (ftyp)', key: 'Compatible Brands', value: compat.join(', ') }
            );
          } else if (type === 'mvhd' && size >= 32) {
            const version = u8[bodyStart];
            const macEpochOffset = 2082844800;
            let createSec, modSec, timescale, duration;
            if (version === 0) {
              createSec = dv.getUint32(bodyStart + 4, false);
              modSec = dv.getUint32(bodyStart + 8, false);
              timescale = dv.getUint32(bodyStart + 12, false);
              duration = dv.getUint32(bodyStart + 16, false);
            } else {
              createSec = Number(dv.getBigUint64(bodyStart + 4, false));
              modSec = Number(dv.getBigUint64(bodyStart + 12, false));
              timescale = dv.getUint32(bodyStart + 20, false);
              duration = Number(dv.getBigUint64(bodyStart + 24, false));
            }
            const durSec = timescale > 0 ? (duration / timescale) : 0;
            formatProps.push(
              { section: 'Movie Header (mvhd)', key: 'Duration', value: `${durSec.toFixed(2)} sec (${Math.floor(durSec / 60)}m ${(durSec % 60).toFixed(1)}s)` },
              { section: 'Movie Header (mvhd)', key: 'Time Scale', value: `${timescale} Hz` }
            );
            if (createSec > macEpochOffset) {
              formatProps.push({ section: 'Movie Header (mvhd)', key: 'Encoded Creation Date', value: new Date((createSec - macEpochOffset) * 1000).toISOString() });
            }
            if (modSec > macEpochOffset) {
              formatProps.push({ section: 'Movie Header (mvhd)', key: 'Encoded Modification Date', value: new Date((modSec - macEpochOffset) * 1000).toISOString() });
            }
          } else if (type === 'tkhd' && size >= 92) {
            const version = u8[bodyStart];
            const trackIdOffset = version === 1 ? bodyStart + 20 : bodyStart + 12;
            const dimOffset = version === 1 ? bodyStart + 88 : bodyStart + 76;
            if (dimOffset + 8 <= pos + size) {
              const trackId = dv.getUint32(trackIdOffset, false);
              const width = (dv.getUint32(dimOffset, false) / 65536).toFixed(0);
              const height = (dv.getUint32(dimOffset + 4, false) / 65536).toFixed(0);
              if (Number(width) > 0 && Number(height) > 0) {
                formatProps.push({ section: `Track #${trackId} Header (tkhd)`, key: 'Track Visual Dimensions', value: `${width} × ${height} px` });
              }
            }
          } else if (type === 'hdlr' && size >= 24) {
            const handlerType = new TextDecoder('ascii').decode(u8.subarray(bodyStart + 8, bodyStart + 12));
            const handlerName = new TextDecoder('utf-8', { fatal: false }).decode(u8.subarray(bodyStart + 24, pos + size)).replace(/\0+/g, '').trim();
            formatProps.push({ section: 'Media Track Handler (hdlr)', key: `Handler [${handlerType}]`, value: handlerName || handlerType });
          } else if (type === 'uuid' && size >= 24) {
            const uuidBytes = Array.from(u8.subarray(bodyStart, bodyStart + 16)).map(b => b.toString(16).padStart(2, '0')).join('');
            const isC2paUuid = uuidBytes.toLowerCase() === 'd8fec3d61b0e483c92975828877ec481';
            const uuidPayload = new TextDecoder('utf-8', { fatal: false }).decode(u8.subarray(bodyStart + 16, Math.min(pos + size, bodyStart + 4096))).replace(/\0+/g, ' ').trim();
            formatProps.push({
              section: isC2paUuid ? 'AI Provenance & Content Credentials (C2PA UUID Box)' : 'ISO BMFF UUID Box',
              key: isC2paUuid ? 'C2PA JUMBF Manifest Box' : `UUID [${uuidBytes}]`,
              value: uuidPayload ? `${uuidPayload.slice(0, 500)}` : `${size} bytes`
            });
          } else if (['©too', '©cmt', '©nam', '©ART', '©day', '©wrt', 'desc', 'cprt'].includes(type) && size > 8) {
            const rawAtomText = new TextDecoder('utf-8', { fatal: false }).decode(u8.subarray(bodyStart, pos + size)).replace(/[\x00-\x1F]+/g, ' ').replace(/^data\s+/i, '').trim();
            const atomLabels = {
              '©too': 'Encoding Tool / Software (©too)',
              '©cmt': 'Comment / Generation Parameters (©cmt)',
              '©nam': 'Title (©nam)',
              '©ART': 'Artist / Creator (©ART)',
              '©day': 'Creation Date (©day)',
              '©wrt': 'Writer / Composer (©wrt)',
              'desc': 'Description / Prompt (desc)',
              'cprt': 'Copyright (cprt)'
            };
            if (rawAtomText) {
              formatProps.push({ section: 'Video / Audio User Data Atoms (udta/ilst)', key: atomLabels[type] || type, value: rawAtomText.slice(0, 600) });
            }
          }

          if (containerBoxes.has(type)) {
            const childOffset = type === 'meta' ? bodyStart + 4 : bodyStart;
            walkBoxes(childOffset, pos + size, depth + 1);
          }
          pos += size;
        }
      }

      walkBoxes(0, u8.length, 0);

      const exifMap = {}, gpsRaw = {}, xmpMerged = { editHistory: [], cameraRaw: [], fields: {} }, textMetaPool = {};
      scanAllEmbeddedExifAndXmp(u8, new Set(), exifMap, gpsRaw, xmpMerged, textMetaPool, formatProps);
      for (const fp of formatProps) {
        if (fp.key.includes('©cmt') || fp.key.includes('Comment')) textMetaPool.Comment = fp.value;
        if (fp.key.includes('desc') || fp.key.includes('Description')) textMetaPool.Description = fp.value;
        if (fp.key.includes('©too')) textMetaPool.Software = fp.value;
      }
      const { aiProps, aiSummary } = parseAiGenerationMetadata(textMetaPool, u8);
      formatProps.push(...aiProps);

      let photoContext = null;
      if (isImageFamily) {
        photoContext = { exifMap, gpsRaw, iptcMap: {}, xmpMerged, aiSummary };
      }

      return { formatProps, structureProps, photoContext };
    }

    function parseMp3Id3(u8) {
      const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
      const formatProps = [];
      const structureProps = [];

      if (u8.length >= 10 && u8[0] === 0x49 && u8[1] === 0x44 && u8[2] === 0x33) {
        const verMajor = u8[3];
        const verRev = u8[4];
        const tagSize = ((u8[6] & 0x7f) << 21) | ((u8[7] & 0x7f) << 14) | ((u8[8] & 0x7f) << 7) | (u8[9] & 0x7f);
        formatProps.push({ section: 'MP3 ID3v2 Header', key: 'ID3v2 Version', value: `ID3v2.${verMajor}.${verRev} (${tagSize} bytes)` });

        const frameNames = {
          TIT2: 'Title', TPE1: 'Artist', TPE2: 'Album Artist', TALB: 'Album',
          TYER: 'Year', TDRC: 'Recording Time', TRCK: 'Track Number', TCON: 'Genre',
          TCOM: 'Composer', TCOP: 'Copyright', TENC: 'Encoded By', TSSE: 'Encoder Settings',
          COMM: 'Comment', TBPM: 'BPM'
        };
        let pos = 10;
        const limit = Math.min(u8.length, 10 + tagSize);
        while (pos + 10 <= limit) {
          const frameId = new TextDecoder('ascii').decode(u8.subarray(pos, pos + 4));
          if (!/^[A-Z0-9]{4}$/.test(frameId)) break;
          const fSize = verMajor === 4
            ? (((u8[pos + 4] & 0x7f) << 21) | ((u8[pos + 5] & 0x7f) << 14) | ((u8[pos + 6] & 0x7f) << 7) | (u8[pos + 7] & 0x7f))
            : dv.getUint32(pos + 4, false);
          if (fSize <= 0 || pos + 10 + fSize > limit) break;
          const encoding = u8[pos + 10];
          const rawBytes = u8.subarray(pos + 11, pos + 10 + fSize);
          const val = new TextDecoder(encoding === 1 || encoding === 2 ? 'utf-16' : 'utf-8', { fatal: false })
            .decode(rawBytes).replace(/\0+/g, ' ').trim();
          if (val) {
            formatProps.push({ section: 'MP3 ID3v2 Frames', key: `${frameNames[frameId] || frameId} (${frameId})`, value: val.slice(0, 300) });
          }
          pos += 10 + fSize;
        }
      }

      if (u8.length >= 128) {
        const tail = u8.subarray(u8.length - 128);
        if (tail[0] === 0x54 && tail[1] === 0x41 && tail[2] === 0x47) {
          const dec = (s, e) => new TextDecoder('latin1').decode(tail.subarray(s, e)).replace(/\0+/g, '').trim();
          formatProps.push(
            { section: 'MP3 ID3v1 Footer', key: 'Title', value: dec(3, 33) },
            { section: 'MP3 ID3v1 Footer', key: 'Artist', value: dec(33, 63) },
            { section: 'MP3 ID3v1 Footer', key: 'Album', value: dec(63, 93) },
            { section: 'MP3 ID3v1 Footer', key: 'Year', value: dec(93, 97) },
            { section: 'MP3 ID3v1 Footer', key: 'Comment', value: dec(97, 125) }
          );
        }
      }

      return { formatProps, structureProps };
    }

    function parseWavRiff(u8) {
      const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
      const formatProps = [];
      const structureProps = [];
      const infoLabels = {
        ISFT: 'Software / DAW (ISFT)',
        INAM: 'Track Title (INAM)',
        IART: 'Artist / Creator (IART)',
        ICRD: 'Creation Date (ICRD)',
        ICMT: 'Comment / Processing Note (ICMT)',
        IGNR: 'Genre (IGNR)',
        ICOP: 'Copyright (ICOP)',
        IENG: 'Audio Engineer (IENG)',
        ISRC: 'Source / Recorder (ISRC)'
      };
      let pos = 12;
      while (pos + 8 <= u8.length) {
        const chunkId = new TextDecoder('ascii').decode(u8.subarray(pos, pos + 4));
        const chunkSize = dv.getUint32(pos + 4, true);
        if (pos + 8 + chunkSize > u8.length) break;
        structureProps.push({ section: 'RIFF / WAV Chunks', key: `Chunk [${chunkId}]`, value: `${chunkSize.toLocaleString()} B @ 0x${pos.toString(16).toUpperCase()}` });
        if (chunkId === 'fmt ' && chunkSize >= 16 && pos + 24 <= u8.length) {
          const audioFmt = dv.getUint16(pos + 8, true);
          const channels = dv.getUint16(pos + 10, true);
          const sampleRate = dv.getUint32(pos + 12, true);
          const byteRate = dv.getUint32(pos + 16, true);
          const bitsPerSample = dv.getUint16(pos + 22, true);
          formatProps.push(
            { section: 'WAV Audio Format (fmt)', key: 'Encoding', value: audioFmt === 1 ? 'PCM Uncompressed' : audioFmt === 3 ? 'IEEE Float' : `Format 0x${audioFmt.toString(16)}` },
            { section: 'WAV Audio Format (fmt)', key: 'Channels', value: `${channels} (${channels === 1 ? 'Mono' : channels === 2 ? 'Stereo' : 'Multi-channel'})` },
            { section: 'WAV Audio Format (fmt)', key: 'Sample Rate', value: `${sampleRate.toLocaleString()} Hz` },
            { section: 'WAV Audio Format (fmt)', key: 'Bit Depth', value: `${bitsPerSample}-bit` },
            { section: 'WAV Audio Format (fmt)', key: 'Bitrate', value: `${((byteRate * 8) / 1000).toFixed(1)} kbps` }
          );
        } else if (chunkId === 'LIST' && chunkSize >= 4) {
          const listType = new TextDecoder('ascii').decode(u8.subarray(pos + 8, pos + 12));
          if (listType === 'INFO') {
            let subPos = pos + 12;
            const listEnd = pos + 8 + chunkSize;
            while (subPos + 8 <= listEnd) {
              const subId = new TextDecoder('ascii').decode(u8.subarray(subPos, subPos + 4));
              const subSize = dv.getUint32(subPos + 4, true);
              if (subPos + 8 + subSize > listEnd) break;
              const val = new TextDecoder('utf-8', { fatal: false }).decode(u8.subarray(subPos + 8, subPos + 8 + subSize)).replace(/\0+/g, '').trim();
              if (val) {
                formatProps.push({ section: 'WAV RIFF INFO Metadata', key: infoLabels[subId] || `INFO [${subId}]`, value: val });
              }
              subPos += 8 + subSize + (subSize % 2);
            }
          }
        } else if (chunkId === 'bext' && chunkSize >= 348) {
          const dec = (s, l) => new TextDecoder('utf-8', { fatal: false }).decode(u8.subarray(pos + 8 + s, pos + 8 + s + l)).replace(/\0+/g, '').trim();
          const desc = dec(0, 256);
          const originator = dec(256, 32);
          const origRef = dec(288, 32);
          const origDate = dec(320, 10);
          const origTime = dec(330, 8);
          if (desc) formatProps.push({ section: 'Broadcast Wave Extension (bext)', key: 'Description', value: desc });
          if (originator) formatProps.push({ section: 'Broadcast Wave Extension (bext)', key: 'Originator / DAW / Recorder', value: originator });
          if (origRef) formatProps.push({ section: 'Broadcast Wave Extension (bext)', key: 'Originator Reference', value: origRef });
          if (origDate || origTime) formatProps.push({ section: 'Broadcast Wave Extension (bext)', key: 'Origination Date/Time', value: `${origDate} ${origTime}`.trim() });
        } else if (chunkId === '_PMX' || chunkId === 'iXML') {
          const xmlStr = new TextDecoder('utf-8', { fatal: false }).decode(u8.subarray(pos + 8, pos + 8 + chunkSize));
          const { props } = extractXmpAndEditHistory(xmlStr);
          formatProps.push(...props);
        }
        pos += 8 + chunkSize + (chunkSize % 2);
      }
      return { formatProps, structureProps };
    }

    // =========================================================================
    // CSV / TSV / TABULAR DATASET & TEXT SCHEMA PROFILER
    // =========================================================================
    function parseCsvAndTextMetadata(u8, ext) {
      const formatProps = [];
      const structureProps = [];

      let bom = 'None (UTF-8 / ASCII)';
      if (u8[0] === 0xEF && u8[1] === 0xBB && u8[2] === 0xBF) bom = 'UTF-8 BOM (EF BB BF)';
      else if (u8[0] === 0xFE && u8[1] === 0xFF) bom = 'UTF-16 BE BOM (FE FF)';
      else if (u8[0] === 0xFF && u8[1] === 0xFE) bom = 'UTF-16 LE BOM (FF FE)';

      const textSample = u8.length > 2 * 1024 * 1024 ? u8.subarray(0, 2 * 1024 * 1024) : u8;
      const text = new TextDecoder('utf-8', { fatal: false }).decode(textSample);
      const crlfCount = (text.match(/\r\n/g) || []).length;
      const lfOnlyCount = (text.match(/(?<!\r)\n/g) || []).length;
      const lineEnding = crlfCount > lfOnlyCount ? 'CRLF (Windows \\r\\n)' : lfOnlyCount > 0 ? 'LF (Unix/macOS \\n)' : 'Single Line';

      const lines = text.split(/\r?\n/);
      const nonEmptyLines = lines.filter(l => l.trim().length > 0);
      const words = text.trim() ? text.trim().split(/\s+/).length : 0;

      formatProps.push(
        { section: 'Text & Encoding Profile', key: 'Character Encoding / BOM', value: bom },
        { section: 'Text & Encoding Profile', key: 'Line Ending Convention', value: lineEnding },
        { section: 'Text & Encoding Profile', key: 'Total Lines / Non-Empty Rows', value: `${lines.length.toLocaleString()} total (${nonEmptyLines.length.toLocaleString()} non-empty)` },
        { section: 'Text & Encoding Profile', key: 'Total Words / Characters', value: `${words.toLocaleString()} words | ${text.length.toLocaleString()} chars` }
      );

      if (ext === 'csv' || ext === 'tsv' || (nonEmptyLines.length >= 2 && nonEmptyLines[0].includes(','))) {
        const firstLine = nonEmptyLines[0] || '';
        const candidates = [',', '\t', ';', '|'];
        let bestDelim = ',';
        let bestCount = 0;
        for (const d of candidates) {
          const c = firstLine.split(d).length - 1;
          if (c > bestCount) { bestCount = c; bestDelim = d; }
        }
        const delimLabel = bestDelim === '\t' ? 'Tab (\\t)' : bestDelim === ',' ? 'Comma (,)' : bestDelim === ';' ? 'Semicolon (;)' : 'Pipe (|)';

        function splitCsvRow(row, delim) {
          const out = [];
          let cur = '';
          let inQ = false;
          for (let i = 0; i < row.length; i++) {
            const ch = row[i];
            if (ch === '"') {
              if (inQ && row[i + 1] === '"') { cur += '"'; i++; }
              else inQ = !inQ;
            } else if (ch === delim && !inQ) {
              out.push(cur.trim());
              cur = '';
            } else {
              cur += ch;
            }
          }
          out.push(cur.trim());
          return out;
        }

        const headers = splitCsvRow(nonEmptyLines[0], bestDelim);
        const dataRows = nonEmptyLines.slice(1, Math.min(nonEmptyLines.length, 1001)).map(r => splitCsvRow(r, bestDelim));

        formatProps.push(
          { section: 'CSV / Tabular Dataset Summary', key: 'Detected Delimiter', value: delimLabel },
          { section: 'CSV / Tabular Dataset Summary', key: 'Column Count', value: String(headers.length) },
          { section: 'CSV / Tabular Dataset Summary', key: 'Data Row Count (excl. header)', value: String(Math.max(0, nonEmptyLines.length - 1)) },
          { section: 'CSV / Tabular Dataset Summary', key: 'Column Headers', value: headers.join(', ') }
        );

        headers.forEach((colName, idx) => {
          let nulls = 0;
          let numCount = 0;
          let numSum = 0;
          let minVal = Infinity;
          let maxVal = -Infinity;
          const distinct = new Set();

          for (const row of dataRows) {
            const v = row[idx] ?? '';
            if (v === '' || v.toLowerCase() === 'null' || v.toLowerCase() === 'na') {
              nulls++;
            } else {
              distinct.add(v);
              const n = Number(v);
              if (!Number.isNaN(n) && v !== '') {
                numCount++;
                numSum += n;
                if (n < minVal) minVal = n;
                if (n > maxVal) maxVal = n;
              }
            }
          }
          const populated = dataRows.length - nulls;
          const isNumeric = populated > 0 && numCount / populated >= 0.85;
          let detail = `Type: ${isNumeric ? 'Numeric' : 'String/Categorical'} | Distinct: ${distinct.size} | Nulls: ${nulls}/${dataRows.length}`;
          if (isNumeric && numCount > 0) {
            detail += ` | Min: ${minVal}, Max: ${maxVal}, Mean: ${(numSum / numCount).toFixed(2)}`;
          } else if (distinct.size > 0) {
            detail += ` | Sample: ${[...distinct].slice(0, 3).join(', ')}`;
          }
          structureProps.push({
            section: 'CSV Column Schema & Statistical Profile',
            key: `Col #${idx + 1}: ${colName || '(Unnamed)'}`,
            value: detail
          });
        });
      }

      return { formatProps, structureProps };
    }

    // =========================================================================
    // HTML5 BROWSER MEDIA / IMAGE ELEMENT PROBING
    // =========================================================================
    function probeDomMediaDimensions(file, family) {
      return new Promise(resolve => {
        const props = [];
        const url = URL.createObjectURL(file);
        const timeout = setTimeout(() => { resolve({ props, thumbUrl: null }); }, 1600);

        if (family === 'image' || family === 'svg') {
          const img = new Image();
          img.onload = () => {
            clearTimeout(timeout);
            const w = img.naturalWidth || img.width || 0;
            const h = img.naturalHeight || img.height || 0;
            if (w > 0 && h > 0) {
              const gcd = (a, b) => (b === 0 ? a : gcd(b, a % b));
              const g = gcd(w, h) || 1;
              props.push(
                { section: 'Decoded Visual Frame', key: 'Decoded Resolution', value: `${w} × ${h} px` },
                { section: 'Decoded Visual Frame', key: 'Aspect Ratio', value: `${w / g}:${h / g} (${(w / h).toFixed(3)})` },
                { section: 'Decoded Visual Frame', key: 'Megapixels', value: `${((w * h) / 1e6).toFixed(3)} MP` }
              );
            }
            resolve({ props, thumbUrl: url });
          };
          img.onerror = () => {
            clearTimeout(timeout);
            URL.revokeObjectURL(url);
            resolve({ props, thumbUrl: null });
          };
          img.src = url;
        } else if (family === 'video' || family === 'isobmff' || family === 'ebml' || family === 'audio' || family === 'mp3' || family === 'flac' || family === 'ogg') {
          const el = document.createElement(family === 'audio' || family === 'mp3' || family === 'flac' ? 'audio' : 'video');
          el.preload = 'metadata';
          el.onloadedmetadata = () => {
            clearTimeout(timeout);
            if (Number.isFinite(el.duration)) {
              props.push({ section: 'Decoded Media Stream', key: 'Browser Decoded Duration', value: `${el.duration.toFixed(3)} seconds` });
              if (el.duration > 0) {
                props.push({ section: 'Decoded Media Stream', key: 'Overall Container Bitrate', value: `${((file.size * 8) / el.duration / 1000).toFixed(1)} kbps` });
              }
            }
            if (el.videoWidth && el.videoHeight) {
              props.push({ section: 'Decoded Media Stream', key: 'Decoded Video Resolution', value: `${el.videoWidth} × ${el.videoHeight} px` });
            }
            URL.revokeObjectURL(url);
            resolve({ props, thumbUrl: null });
          };
          el.onerror = () => {
            clearTimeout(timeout);
            URL.revokeObjectURL(url);
            resolve({ props, thumbUrl: null });
          };
          el.src = url;
        } else {
          clearTimeout(timeout);
          URL.revokeObjectURL(url);
          resolve({ props, thumbUrl: null });
        }
      });
    }

    // =========================================================================
    // HEX DUMP & EMBEDDED STRINGS / URL / EMAIL FORENSIC EXTRACTOR
    // =========================================================================
    function generateHexDump(u8, maxBytes = 512) {
      const len = Math.min(u8.length, maxBytes);
      const lines = [];
      for (let i = 0; i < len; i += 16) {
        const slice = u8.subarray(i, Math.min(i + 16, len));
        const hexPart = Array.from(slice).map(b => b.toString(16).padStart(2, '0').toUpperCase()).join(' ');
        const asciiPart = Array.from(slice).map(b => (b >= 32 && b <= 126) ? String.fromCharCode(b) : '.').join('');
        lines.push(`${i.toString(16).padStart(8, '0').toUpperCase()}  ${hexPart.padEnd(47, ' ')}  |${asciiPart}|`);
      }
      return lines.join('\n');
    }

    function extractForensicStrings(u8) {
      const sample = new TextDecoder('latin1').decode(u8.subarray(0, Math.min(u8.length, 300 * 1024)));
      const urls = [...new Set(sample.match(/https?:\/\/[a-zA-Z0-9._~:/?#[\]@!$&'()*+,;=-]{6,140}/g) || [])].slice(0, 25);
      const emails = [...new Set(sample.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,12}/g) || [])].slice(0, 20);
      const printableRuns = [];
      const runRegex = /[\x20-\x7E]{8,120}/g;
      let m;
      while ((m = runRegex.exec(sample)) !== null && printableRuns.length < 60) {
        const s = m[0].trim();
        if (s.length >= 8) printableRuns.push(s);
      }
      return { urls, emails, printableRuns };
    }

    // =========================================================================
    // MASTER FILE ANALYZER PIPELINE
    // =========================================================================
    // =========================================================================
    // UNIVERSAL AI-GENERATION & PROVENANCE EVALUATOR (ALL DOCUMENT & MEDIA TYPES)
    // =========================================================================
    // =========================================================================
    // RAW / UNEDITED VS. SOFTWARE-EDITED AUTHENTICITY ENGINE (PHOTOS, VIDEOS, AUDIO)
    // =========================================================================
    function parseFlexibleExifDateToMs(str) {
      if (!str) return null;
      const clean = String(str).trim();
      // Match YYYY:MM:DD HH:MM:SS or YYYY-MM-DDTHH:MM:SS
      const m = clean.match(/^(\d{4})[:\-](\d{2})[:\-](\d{2})[T\s](\d{2}):(\d{2}):(\d{2})/);
      if (!m) return null;
      const iso = `${m[1]}-${m[2]}-${m[3]}T${m[4]}:${m[5]}:${m[6]}Z`;
      const t = Date.parse(iso);
      return Number.isNaN(t) ? null : t;
    }

    function evaluateMediaRawVsEdited(u8, magic, ext, formatProps, structureProps, photoContext, universalAi) {
      const isPhoto = magic.family === 'image' || magic.family === 'isobmff-image' || magic.family === 'svg';
      const isVideo = magic.family === 'video' || magic.family === 'isobmff' || magic.family === 'ebml';
      const isAudio = magic.family === 'audio' || magic.family === 'mp3' || magic.family === 'flac' || magic.family === 'ogg';

      if (!isPhoto && !isVideo && !isAudio) {
        return null;
      }

      const mediaCategoryLabel = isPhoto ? 'Photograph / Image' : isVideo ? 'Video Container' : 'Audio Stream';
      const allKvText = formatProps.map(p => `${p.key}: ${p.value}`).join(' \n ');
      const sampleBinText = new TextDecoder('latin1').decode(u8.subarray(0, Math.min(u8.length, 256 * 1024)));

      const editingApps = new Set();
      const editOperations = [];
      const evidence = [];
      let captureDevice = 'Not specified in metadata';
      let timestampComparison = 'Single or no embedded capture timestamp';
      let isTrueCameraRaw = ['dng', 'cr2', 'cr3', 'nef', 'arw', 'orf', 'rw2', 'pef', 'raf'].includes(ext);

      // 1. Check Software / App / NLE / DAW / Transcoder Signatures by Media Type
      const photoEditorPatterns = [
        { rx: /Adobe\s+Photoshop\s+Lightroom[^,\n|<"'/]*/i, name: 'Adobe Photoshop Lightroom' },
        { rx: /Adobe\s+Photoshop(?!\s+Lightroom)[^,\n|<"'/]*/i, name: 'Adobe Photoshop' },
        { rx: /Adobe\s+Camera\s+Raw[^,\n|<"'/]*/i, name: 'Adobe Camera Raw' },
        { rx: /\b(GIMP\s*[0-9.]*|GNU\s+Image\s+Manipulation\s+Program)\b/i, name: 'GIMP' },
        { rx: /\b(Affinity\s+Photo[^,\n|<"'/]*|Serif\s+Affinity)\b/i, name: 'Affinity Photo' },
        { rx: /\b(Capture\s+One[^,\n|<"'/]*)\b/i, name: 'Capture One' },
        { rx: /\b(Darktable[^,\n|<"'/]*|RawTherapee[^,\n|<"'/]*|Luminar\s+Neo|DxO\s+PhotoLab|ON1\s+Photo\s+RAW|Pixelmator\s+Pro|Photopea)\b/i, name: 'Desktop Photo Editor' },
        { rx: /\b(Snapseed|VSCO|PicsArt|Canva|InShot|Facetune|Remini|Meitu|Hypic|Afterlight|Polarr|Lightleap)\b/i, name: 'Mobile Photo Editing App' },
        { rx: /\b(ImageMagick|GraphicsMagick|Pillow|PIL|libvips|Sharp)\b/i, name: 'Image Processing Library' }
      ];

      const videoEditorPatterns = [
        { rx: /Adobe\s+Premiere\s+Pro[^,\n|<"'/]*/i, name: 'Adobe Premiere Pro (NLE)' },
        { rx: /Adobe\s+After\s+Effects[^,\n|<"'/]*/i, name: 'Adobe After Effects' },
        { rx: /Adobe\s+Media\s+Encoder[^,\n|<"'/]*/i, name: 'Adobe Media Encoder' },
        { rx: /\b(DaVinci\s+Resolve[^,\n|<"'/]*|Blackmagic\s+Design)\b/i, name: 'DaVinci Resolve (NLE)' },
        { rx: /\b(Final\s+Cut\s+Pro[^,\n|<"'/]*|iMovie[^,\n|<"'/]*)\b/i, name: 'Apple Final Cut Pro / iMovie' },
        { rx: /\b(CapCut[^,\n|<"'/]*|LvMeta|ByteDance\s+Video\s+Editor)\b/i, name: 'CapCut Video Editor' },
        { rx: /\b(VN\s+Video\s+Editor|InShot\s+Video|KineMaster|Wondershare\s+Filmora|Filmora|Vegas\s+Pro|Camtasia|ScreenFlow|Clipchamp|LumaFusion|Splice)\b/i, name: 'Video Editing App / NLE' },
        { rx: /\b(Lavf[0-9.]+|FFmpeg[^,\n|<"'/]*|HandBrake[^,\n|<"'/]*|x264\s+core|x265\s+\(build|MKVToolNix|GPAC\/MP4Box|Shutter\s+Encoder|Avidemux|VirtualDub)\b/i, name: 'FFmpeg / Transcoder / Re-Muxer' }
      ];

      const audioEditorPatterns = [
        { rx: /\b(Audacity[^,\n|<"'/]*)\b/i, name: 'Audacity Audio Editor' },
        { rx: /\b(Adobe\s+Audition[^,\n|<"'/]*)\b/i, name: 'Adobe Audition (DAW)' },
        { rx: /\b(Logic\s+Pro[^,\n|<"'/]*|GarageBand[^,\n|<"'/]*)\b/i, name: 'Apple Logic Pro / GarageBand (DAW)' },
        { rx: /\b(Pro\s+Tools[^,\n|<"'/]*|Avid\s+Pro\s+Tools)\b/i, name: 'Avid Pro Tools (DAW)' },
        { rx: /\b(FL\s+Studio[^,\n|<"'/]*|Image-Line)\b/i, name: 'FL Studio (DAW)' },
        { rx: /\b(Ableton\s+Live[^,\n|<"'/]*|REAPER[^,\n|<"'/]*|Cubase[^,\n|<"'/]*|Nuendo[^,\n|<"'/]*|Studio\s+One[^,\n|<"'/]*|iZotope\s+RX[^,\n|<"'/]*|WaveLab[^,\n|<"'/]*|Sound\s+Forge|Ocenaudio|Descript)\b/i, name: 'Digital Audio Workstation (DAW)' },
        { rx: /\b(LAME[0-9.a-z]*|Lavf[0-9.]+|FFmpeg|libopus|libvorbis|fdkaac)\b/i, name: 'Audio Encoder / Transcoder' }
      ];

      const activePatterns = isPhoto ? photoEditorPatterns : isVideo ? videoEditorPatterns : audioEditorPatterns;
      for (const pat of activePatterns) {
        const m = (allKvText + ' \n ' + sampleBinText).match(pat.rx);
        if (m) {
          editingApps.add(m[0].trim());
          evidence.push(`Detected editing/processing software signature: "${m[0].trim()}"`);
        }
      }

      // 2. Photo-specific forensic checks (EXIF Camera Make/Model, XMP Edit History, Camera Raw sliders, Timestamp delta, APP13 IRB)
      if (isPhoto && photoContext) {
        const { exifMap = {}, xmpMerged = { editHistory: [], cameraRaw: [], fields: {} } } = photoContext;
        const xf = xmpMerged.fields || {};

        if (exifMap.DNGVersion || xf['tiff:PhotometricInterpretation'] === '32803') {
          isTrueCameraRaw = true;
        }

        const make = exifMap.CameraMake || xf['tiff:Make'] || '';
        const model = exifMap.CameraModel || xf['tiff:Model'] || '';
        if (make || model) {
          captureDevice = [make, model].filter(Boolean).join(' ');
        }

        // Check XMP stEvt edit history
        if (xmpMerged.editHistory && xmpMerged.editHistory.length > 0) {
          const nonCreationSteps = xmpMerged.editHistory.filter(h => h.action && h.action.toLowerCase() !== 'created');
          for (const h of xmpMerged.editHistory) {
            if (h.softwareAgent && /Photoshop|Lightroom|Camera Raw|GIMP|Affinity|Capture One|Snapseed|Canva/i.test(h.softwareAgent)) {
              editingApps.add(h.softwareAgent);
            }
            editOperations.push(`[#${h.step}] ${h.action || 'event'}${h.softwareAgent ? ' (' + h.softwareAgent + ')' : ''}${h.parameters ? ': ' + h.parameters : ''}`);
          }
          if (nonCreationSteps.length > 0) {
            evidence.push(`Contains ${nonCreationSteps.length} post-capture XMP edit/conversion history event(s) (xmpMM:History)`);
          }
        }

        // Check Camera Raw / Lightroom parametric adjustments (crs:*)
        if (xmpMerged.cameraRaw && xmpMerged.cameraRaw.length > 0) {
          editOperations.push(`Parametric Sliders: ${xmpMerged.cameraRaw.slice(0, 6).join(', ')}`);
          evidence.push(`Contains ${xmpMerged.cameraRaw.length} Camera Raw / Lightroom parametric color/exposure adjustment tag(s) (crs:*)`);
        }

        // Check Photoshop APP13 IRB block
        const hasApp13 = formatProps.some(p => p.section.includes('APP13')) || structureProps.some(p => p.key.includes('0xFFED'));
        if (hasApp13) {
          editOperations.push('Photoshop APP13 Image Resource Block (8BIM) embedded');
          evidence.push('Contains Adobe Photoshop APP13 (0xFFED / 8BIM) resource block');
        }

        // Compare DateTimeOriginal vs ModifyDate
        const tOrig = parseFlexibleExifDateToMs(exifMap.DateTimeOriginal || xf['exif:DateTimeOriginal']);
        const tMod = parseFlexibleExifDateToMs(exifMap.ModifyDate || xf['xmp:ModifyDate']);
        if (tOrig && tMod) {
          const diffSec = Math.round((tMod - tOrig) / 1000);
          if (Math.abs(diffSec) <= 3) {
            timestampComparison = `Identical (${exifMap.DateTimeOriginal}) — 0s delta between capture and last save`;
          } else if (diffSec > 3) {
            const hrs = Math.floor(diffSec / 3600);
            const mins = Math.floor((diffSec % 3600) / 60);
            const secs = diffSec % 60;
            const durStr = [hrs ? `${hrs}h` : '', mins ? `${mins}m` : '', `${secs}s`].filter(Boolean).join(' ');
            timestampComparison = `Modified ${durStr} AFTER original capture (${exifMap.DateTimeOriginal} → ${exifMap.ModifyDate})`;
            evidence.push(`ModifyDate is ${durStr} later than DateTimeOriginal (re-saved after capture)`);
          } else {
            timestampComparison = `Original: ${exifMap.DateTimeOriginal} | Modified: ${exifMap.ModifyDate}`;
          }
        } else if (exifMap.DateTimeOriginal) {
          timestampComparison = `Original Capture: ${exifMap.DateTimeOriginal}`;
        }
      }

      // 3. Video-specific forensic checks (mvhd Creation vs Modification time, XMP Ingredients/History, Handler names)
      if (isVideo) {
        const createProp = formatProps.find(p => p.key === 'Encoded Creation Date');
        const modProp = formatProps.find(p => p.key === 'Encoded Modification Date');
        const tooProp = formatProps.find(p => p.key.includes('©too'));
        const hdlrProps = formatProps.filter(p => p.section.includes('hdlr'));

        if (tooProp) {
          editOperations.push(`Muxing/Encoding Tool (©too): ${tooProp.value}`);
        }
        for (const hp of hdlrProps) {
          if (/GPAC|Lavf|FFmpeg|Premiere|Core Media|Apple|MainConcept|Bento4|L-SMASH/i.test(hp.value)) {
            if (/Apple|Core Media/i.test(hp.value) && captureDevice === 'Not specified in metadata') {
              captureDevice = `Apple QuickTime / Core Media (${hp.value})`;
            }
          }
        }

        // Check XMP History or Ingredients in video
        const xmpHistProps = formatProps.filter(p => p.section.includes('xmpMM:History'));
        if (xmpHistProps.length > 0) {
          for (const xp of xmpHistProps) editOperations.push(xp.value);
          evidence.push(`Video contains ${xmpHistProps.length} XMP editing history step(s)`);
        }

        if (createProp && modProp) {
          const tC = Date.parse(createProp.value);
          const tM = Date.parse(modProp.value);
          if (!Number.isNaN(tC) && !Number.isNaN(tM)) {
            const diffSec = Math.round((tM - tC) / 1000);
            if (Math.abs(diffSec) <= 5) {
              timestampComparison = `Identical (${createProp.value}) — 0s delta in mvhd header`;
            } else if (diffSec > 5) {
              timestampComparison = `mvhd Modification Date is ${diffSec}s later than Creation Date (${createProp.value} → ${modProp.value})`;
              evidence.push(`Container mvhd Modification Date is ${diffSec}s after Creation Date`);
            }
          }
        }
      }

      // 4. Audio-specific forensic checks (RIFF INFO ISFT, bext Originator, ID3 TENC/TSSE, XMP history)
      if (isAudio) {
        const isftProp = formatProps.find(p => p.key.includes('ISFT') || p.key.includes('Originator / DAW') || p.key.includes('TENC') || p.key.includes('TSSE'));
        if (isftProp) {
          editOperations.push(`Audio Software / Encoder Tag: ${isftProp.value}`);
        }
        const xmpHistProps = formatProps.filter(p => p.section.includes('xmpMM:History'));
        if (xmpHistProps.length > 0) {
          for (const xp of xmpHistProps) editOperations.push(xp.value);
          evidence.push(`Audio file contains ${xmpHistProps.length} XMP DAW edit history event(s)`);
        }
      }

      // 5. Final Classification Decision
      let stateCode = 'raw_unedited';
      let verdictBadgeText = `🟢 Raw / Unedited Original ${isPhoto ? 'Photo' : isVideo ? 'Video' : 'Audio'}`;
      let badgeClass = 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/35';
      let dotClass = 'bg-emerald-400';

      if (universalAi && universalAi.status === 'confirmed_ai') {
        stateCode = 'ai_synthesized';
        verdictBadgeText = `✨ AI-Synthesized ${isPhoto ? 'Image' : isVideo ? 'Video' : 'Audio'} (Not a Raw Camera Capture)`;
        badgeClass = 'bg-purple-500/20 text-purple-300 border border-purple-500/45';
        dotClass = 'bg-purple-400 animate-pulse';
        evidence.unshift(`Generated synthetically by AI (${universalAi.generator})`);
      } else if (editingApps.size > 0 || evidence.length > 0) {
        stateCode = 'edited_software';
        verdictBadgeText = `🟠 Edited / Post-Processed ${isPhoto ? 'Photo' : isVideo ? 'Video' : 'Audio'} (Software / App Modified)`;
        badgeClass = 'bg-amber-500/20 text-amber-300 border border-amber-500/45';
        dotClass = 'bg-amber-400 animate-pulse';
      } else if (isTrueCameraRaw) {
        stateCode = 'raw_unedited';
        verdictBadgeText = '🟢 Unedited Camera RAW Sensor File';
        evidence.push('Verified native camera RAW sensor format with zero post-processing history');
      } else if (isPhoto && captureDevice === 'Not specified in metadata') {
        stateCode = 'reencoded_or_stripped';
        verdictBadgeText = '🟡 Re-Encoded / Metadata-Stripped Image (Not Raw Camera Original)';
        badgeClass = 'bg-sky-500/15 text-sky-300 border border-sky-500/35';
        dotClass = 'bg-sky-400';
        evidence.push('Camera Make/Model & sensor exposure tags are absent (re-saved or stripped by transfer/app), though no explicit desktop editor signature remains');
      } else {
        evidence.push(
          isPhoto
            ? `Direct camera capture from ${captureDevice} with matching original/modified timestamps and zero editing software or Camera Raw adjustments`
            : isVideo
            ? 'Direct container stream with no NLE (Premiere/Resolve/CapCut/Final Cut) or FFmpeg re-encoding markers'
            : 'Direct audio stream with no DAW (Audacity/Audition/Pro Tools/Logic) or mastering history tags'
        );
      }

      const appsSummary = editingApps.size > 0 ? Array.from(editingApps).join(', ') : 'None detected (Unmodified)';
      const opsSummary = editOperations.length > 0 ? editOperations.join(' | ') : 'No post-processing operations or parametric edits recorded';
      const evidenceSummary = evidence.join('; ');

      // Also inject into formatProps so it is searchable and included in JSON/CSV exports
      formatProps.unshift(
        { section: 'Raw vs. Edited Media Authenticity', key: 'Media Authenticity Verdict', value: verdictBadgeText },
        { section: 'Raw vs. Edited Media Authenticity', key: 'Media Category', value: mediaCategoryLabel },
        { section: 'Raw vs. Edited Media Authenticity', key: 'Detected Editing Software / App(s)', value: appsSummary },
        { section: 'Raw vs. Edited Media Authenticity', key: 'Original Capture Device / Source', value: captureDevice },
        { section: 'Raw vs. Edited Media Authenticity', key: 'Capture vs. Modified Timestamp Check', value: timestampComparison },
        { section: 'Raw vs. Edited Media Authenticity', key: 'Recorded Edit Operations & Sliders', value: opsSummary },
        { section: 'Raw vs. Edited Media Authenticity', key: 'Forensic Authenticity Evidence', value: evidenceSummary }
      );

      return {
        stateCode,
        mediaCategoryLabel,
        verdictBadgeText,
        badgeClass,
        dotClass,
        appsSummary,
        captureDevice,
        timestampComparison,
        opsSummary,
        evidenceSummary
      };
    }

    function evaluateUniversalAiProvenance(u8, magic, ext, formatProps, structureProps, photoContext) {
      const sampleText = new TextDecoder('latin1').decode(u8.subarray(0, Math.min(u8.length, 384 * 1024)));
      const allKvText = formatProps.map(p => `${p.key}: ${p.value}`).join(' \n ');

      // Start from photoContext.aiSummary if available
      const ps = (photoContext && photoContext.aiSummary) ? photoContext.aiSummary : {};
      let status = ps.detected ? 'confirmed_ai' : 'human_or_standard'; // 'confirmed_ai' | 'automated_script' | 'human_or_standard'
      let generator = ps.generator || null;
      let modelName = ps.modelName || null;
      let modelVersion = ps.modelVersion || null;
      let positivePrompt = ps.positivePrompt || null;
      let negativePrompt = ps.negativePrompt || null;
      let parameters = [
        ps.seed ? `Seed: ${ps.seed}` : '',
        ps.sampler ? `Sampler: ${ps.sampler}` : '',
        ps.steps ? `Steps: ${ps.steps}` : '',
        ps.cfgScale ? `CFG: ${ps.cfgScale}` : ''
      ].filter(Boolean).join(' | ');
      let c2paStatus = ps.c2paManifest || null;
      const evidenceList = [];

      if (ps.detected) {
        evidenceList.push(`Explicit image AI markers (${generator || 'Generative pipeline'})`);
      }

      // 1. Check C2PA / Content Credentials / JUMBF / SynthID across ANY file (Video, Audio, PDF, Image, Office)
      const hasC2paUuid = /d8fec3d61b0e483c92975828877ec481/i.test(allKvText) || /c2pa\.actions|c2pa\.ai_generated|c2pa:generator|trainedAlgorithmicMedia|compositeWithTrainedAlgorithmicMedia/i.test(sampleText + ' ' + allKvText);
      if (hasC2paUuid) {
        status = 'confirmed_ai';
        if (!c2paStatus) c2paStatus = 'Verified C2PA / JUMBF Content Credentials Manifest Detected';
        evidenceList.push('C2PA / JUMBF Content Credentials or IPTC trainedAlgorithmicMedia assertion');
      }

      // 2. Check Video & Audio AI Signatures (Sora, Runway, Veo, Pika, Luma, Kling, Hailuo, ComfyUI Video, Suno, Udio, ElevenLabs)
      const mediaAiPatterns = [
        { rx: /\b(OpenAI\s+Sora|Sora\s+1\.0|Sora-Turbo)\b/i, gen: 'OpenAI Sora (AI Video Generator)', model: 'Sora 1.0' },
        { rx: /\b(Runway\s*Gen-[23]|Gen-3\s*Alpha|RunwayML)\b/i, gen: 'RunwayML (AI Video Generator)', model: 'Runway Gen-3 Alpha' },
        { rx: /\b(Google\s*Veo|Veo\s*2|DeepMind\s*Veo|SynthID)\b/i, gen: 'Google DeepMind Veo / SynthID', model: 'Google Veo' },
        { rx: /\b(Luma\s*Dream\s*Machine|Luma\s*Photon|Luma\s*Ray)\b/i, gen: 'Luma AI Dream Machine', model: 'Luma Ray / Dream Machine' },
        { rx: /\b(Pika\s*Labs|Pika\s*1\.[05]|Pika\s*2\.0)\b/i, gen: 'Pika Labs AI Video', model: 'Pika Video Model' },
        { rx: /\b(Kling\s*AI|Kuaishou\s*Kling)\b/i, gen: 'Kling AI Video Generator', model: 'Kling v1.5 / v1.6' },
        { rx: /\b(Hailuo\s*AI|MiniMax\s*Video)\b/i, gen: 'MiniMax Hailuo AI Video', model: 'Hailuo I2V/T2V' },
        { rx: /\b(Wan2\.1|HunyuanVideo|CogVideoX|Mochi-1|LTX-Video|AnimateDiff|Stable\s*Video\s*Diffusion)\b/i, gen: 'Open-Weights AI Video Pipeline (ComfyUI / Diffusers)', model: 'Diffusion Video Transformer' },
        { rx: /\b(HeyGen|Synthesia|D-ID\s*Studio)\b/i, gen: 'AI Avatar / Lip-Sync Video Generator', model: 'Neural Avatar Synthesis' },
        { rx: /\b(Suno\s*AI|Suno\s*v[34]|Bark\s*Audio)\b/i, gen: 'Suno AI Music Generator', model: 'Suno Chirp v3.5 / v4' },
        { rx: /\b(Udio\s*AI|Udio\s*Music)\b/i, gen: 'Udio AI Music Generator', model: 'Udio Audio Model' },
        { rx: /\b(ElevenLabs|Eleven\s*Multilingual)\b/i, gen: 'ElevenLabs AI Voice Synthesis', model: 'ElevenLabs Neural TTS' },
        { rx: /\b(Stable\s*Audio|AudioCraft|MusicGen)\b/i, gen: 'Generative Audio Model', model: 'Diffusion / Autoregressive Audio' }
      ];
      for (const pat of mediaAiPatterns) {
        const m = (allKvText + ' ' + sampleText).match(pat.rx);
        if (m) {
          status = 'confirmed_ai';
          if (!generator) generator = pat.gen;
          if (!modelName) modelName = m[0];
          evidenceList.push(`Matched media generator signature "${m[0]}" in container metadata`);
        }
      }

      // Extract prompt / model / seed from Video/Audio/Container tags or embedded JSON if not already extracted
      if (!positivePrompt) {
        const promptMatch = (allKvText + '\n' + sampleText).match(/(?:Prompt|c2pa:prompt|ai_prompt)["'\s:=]+([^"\r\n}{]{10,500})/i);
        if (promptMatch) {
          positivePrompt = promptMatch[1].trim();
          status = 'confirmed_ai';
          evidenceList.push('Extracted explicit generation prompt from container metadata');
        }
      }
      if (!modelName) {
        const modelMatch = (allKvText + '\n' + sampleText).match(/(?:c2pa:model|ai_model|model_name)["'\s:=]+([A-Za-z0-9._-]{3,80})/i);
        if (modelMatch) {
          modelName = modelMatch[1].trim();
        }
      }

      // 3. Check PDF, Word (.docx), PowerPoint (.pptx), Excel (.xlsx), EPUB, and Text/JSON for AI Document/Slide/LLM Tools
      const docAiPatterns = [
        { rx: /\b(ChatGPT|OpenAI|GPT-4o|GPT-4|o1-preview|o3-mini)\b/i, gen: 'OpenAI ChatGPT / GPT Document Pipeline', model: 'OpenAI GPT Series' },
        { rx: /\b(Claude\s*3|Anthropic\s*Claude|Claude\s*Sonnet|Claude\s*Opus)\b/i, gen: 'Anthropic Claude Artifact / Document Generator', model: 'Claude 3.5 / 3.7' },
        { rx: /\b(Google\s*Gemini|NotebookLM|Gemini\s*Pro|Gemini\s*Flash)\b/i, gen: 'Google Gemini / NotebookLM Export', model: 'Gemini Multimodal' },
        { rx: /\b(Microsoft\s*Copilot|Copilot\s*in\s*Word|Copilot\s*in\s*PowerPoint)\b/i, gen: 'Microsoft 365 Copilot', model: 'Copilot Enterprise' },
        { rx: /\b(Gamma\.app|Made\s*with\s*Gamma)\b/i, gen: 'Gamma.app AI Presentation & Document Builder', model: 'Gamma AI Engine' },
        { rx: /\b(Beautiful\.ai|SlidesAI|Tome\.app|Plus\s*AI)\b/i, gen: 'AI Slide Deck Generator', model: 'Generative Presentation Engine' },
        { rx: /\b(Jasper\s*AI|Copy\.ai|Writesonic|QuillBot|Notion\s*AI|Perplexity\s*AI|Sudowrite|NovelCrafter)\b/i, gen: 'AI Writing & Publishing Assistant', model: 'LLM Writing Pipeline' },
        { rx: /\b(Adobe\s*Firefly|Midjourney|DALL·E|Stable\s*Diffusion|ComfyUI|Flux\.1)\b/i, gen: 'Generative Visual AI Engine', model: 'Diffusion / Flow Model' }
      ];
      for (const pat of docAiPatterns) {
        const m = allKvText.match(pat.rx);
        if (m) {
          status = 'confirmed_ai';
          if (!generator) generator = pat.gen;
          if (!modelName) modelName = m[0];
          evidenceList.push(`Document metadata field references AI tool "${m[0]}"`);
        }
      }

      // 4. Check for Automated / Programmatic Script Signatures in PDFs and Office files (often produced by LLM Code Execution / Sandboxes)
      if (status === 'human_or_standard') {
        const scriptPatterns = [
          { rx: /\b(python-docx|python-pptx|openpyxl|xlsxwriter|ReportLab|WeasyPrint|wkhtmltopdf|PyPDF|fpdf|LuaHBTeX|Pandoc)\b/i, label: 'Programmatic Document Library' }
        ];
        for (const sp of scriptPatterns) {
          const m = allKvText.match(sp.rx);
          if (m) {
            status = 'automated_script';
            generator = `Programmatic / Script Engine (${m[0]})`;
            evidenceList.push(`Created via headless library "${m[0]}" (commonly used by AI code sandboxes or automated pipelines) rather than interactive desktop software`);
          }
        }
      }

      let verdictLabel = 'No AI Metadata Markers Detected';
      let verdictBadgeClass = 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30';
      let dotClass = 'bg-emerald-400';
      let verdictDescription = 'No AI generator signatures, C2PA algorithmic assertions, or LLM/diffusion prompts were found in this file\'s metadata.';

      if (status === 'confirmed_ai') {
        verdictLabel = '✨ AI-Generated Confirmed (Metadata Provenance)';
        verdictBadgeClass = 'bg-purple-500/20 text-purple-300 border border-purple-500/45';
        dotClass = 'bg-purple-400 animate-pulse';
        verdictDescription = evidenceList.join('; ');
      } else if (status === 'automated_script') {
        verdictLabel = '🤖 Programmatic / Script-Generated File';
        verdictBadgeClass = 'bg-amber-500/20 text-amber-300 border border-amber-500/45';
        dotClass = 'bg-amber-400';
        verdictDescription = evidenceList.join('; ');
      }

      // Append summary rows to formatProps so they also appear in the searchable table & JSON/CSV export
      formatProps.unshift(
        { section: 'Universal AI-Generation & Provenance Analysis', key: 'AI Provenance Verdict', value: verdictLabel },
        { section: 'Universal AI-Generation & Provenance Analysis', key: 'Detection Basis & Evidence', value: verdictDescription },
        { section: 'Universal AI-Generation & Provenance Analysis', key: 'AI Generator / Pipeline', value: generator || 'None detected' },
        { section: 'Universal AI-Generation & Provenance Analysis', key: 'AI Model Name & Version', value: [modelName, modelVersion ? `(${modelVersion})` : ''].filter(Boolean).join(' ') || 'None detected' },
        { section: 'Universal AI-Generation & Provenance Analysis', key: 'Extracted AI Prompt / Instructions', value: positivePrompt || 'None embedded' },
        { section: 'Universal AI-Generation & Provenance Analysis', key: 'C2PA / Content Credentials Status', value: c2paStatus || 'No C2PA manifest present' }
      );

      return {
        status,
        verdictLabel,
        verdictBadgeClass,
        dotClass,
        verdictDescription,
        generator: generator || 'None detected',
        modelName: [modelName, modelVersion ? `(${modelVersion})` : ''].filter(Boolean).join(' ') || 'None detected',
        positivePrompt: positivePrompt || 'None embedded',
        negativePromptOrParams: [negativePrompt ? `Negative: ${negativePrompt}` : '', parameters].filter(Boolean).join(' | ') || 'None embedded',
        c2paStatus: c2paStatus || 'No C2PA manifest present'
      };
    }

    async function analyzeFile(file) {
      const t0 = performance.now();
      const buffer = await file.arrayBuffer();
      const u8 = new Uint8Array(buffer);
      const ext = (file.name.includes('.') ? file.name.split('.').pop() : '').toLowerCase();

      const magic = detectMagicSignature(u8, file.name);
      const extensionMatchesMagic = !ext || magic.validExt.includes(ext) || magic.family === 'generic';

      const lastModDate = file.lastModified ? new Date(file.lastModified) : null;
      const generalProps = [
        { section: 'File System & Identity', key: 'File Name', value: file.name },
        { section: 'File System & Identity', key: 'File Extension', value: ext ? `.${ext}` : '(None)' },
        { section: 'File System & Identity', key: 'Browser Reported MIME Type', value: file.type || 'application/octet-stream (inferred)' },
        { section: 'File System & Identity', key: 'Detected Binary Format', value: `${magic.format} (${magic.mime})` },
        { section: 'File System & Identity', key: 'Extension vs Magic Signature Check', value: extensionMatchesMagic ? 'Verified Match' : `Mismatch Warning (.${ext} vs ${magic.format})` },
        { section: 'File System & Identity', key: 'Exact File Size', value: formatBytes(file.size) },
        { section: 'File System & Identity', key: 'Last Modified Timestamp (Local)', value: lastModDate ? lastModDate.toString() : 'N/A' },
        { section: 'File System & Identity', key: 'Last Modified Timestamp (ISO-8601 UTC)', value: lastModDate ? lastModDate.toISOString() : 'N/A' }
      ];

      const [sha256, sha1] = await Promise.all([
        computeWebCryptoHash('SHA-256', buffer),
        computeWebCryptoHash('SHA-1', buffer)
      ]);
      const md5 = computeMD5(u8);
      const crc32 = computeCRC32(u8);
      const entropyInfo = computeShannonEntropy(u8);
      const first16Hex = Array.from(u8.subarray(0, 16)).map(b => b.toString(16).padStart(2, '0').toUpperCase()).join(' ');

      const forensicsProps = [
        { section: 'Cryptographic Checksums & Hashes', key: 'SHA-256 Digest', value: sha256 },
        { section: 'Cryptographic Checksums & Hashes', key: 'SHA-1 Digest', value: sha1 },
        { section: 'Cryptographic Checksums & Hashes', key: 'MD5 Digest', value: md5 },
        { section: 'Cryptographic Checksums & Hashes', key: 'CRC32 Checksum', value: `0x${crc32}` },
        { section: 'Binary Forensics & Entropy', key: 'Magic Header Bytes (First 16B)', value: first16Hex || 'Empty' },
        { section: 'Binary Forensics & Entropy', key: 'Shannon Entropy (0.0 – 8.0 bits/byte)', value: `${entropyInfo.entropy} bits/byte — ${entropyInfo.assessment}` },
        { section: 'Binary Forensics & Entropy', key: 'Printable ASCII Density', value: `${entropyInfo.asciiRatio}%` },
        { section: 'Binary Forensics & Entropy', key: 'Null Byte (0x00) Count in Sample', value: entropyInfo.nullBytes.toLocaleString() }
      ];

      let formatProps = [];
      let structureProps = [];
      let photoContext = null;

      if (magic.format.startsWith('JPEG')) {
        const res = parseJpegSegments(u8);
        formatProps.push(...res.formatProps);
        structureProps.push(...res.structureProps);
        photoContext = res.photoContext;
      } else if (magic.format.startsWith('PNG')) {
        const res = parsePngChunks(u8);
        formatProps.push(...res.formatProps);
        structureProps.push(...res.structureProps);
        photoContext = res.photoContext;
      } else if (magic.format.startsWith('TIFF')) {
        const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
        const parsed = parseTiffBlock(dv, 0);
        formatProps.push(...parsed.results);
        const xmpMerged = { editHistory: [], cameraRaw: [], fields: {} }, textMetaPool = {};
        scanAllEmbeddedExifAndXmp(u8, new Set([0]), parsed.exifMap, parsed.gpsRaw, xmpMerged, textMetaPool, formatProps);
        const { aiProps, aiSummary } = parseAiGenerationMetadata(textMetaPool, u8);
        formatProps.push(...aiProps);
        photoContext = { exifMap: parsed.exifMap, gpsRaw: parsed.gpsRaw, iptcMap: {}, xmpMerged, aiSummary };
      } else if (magic.family === 'image') {
        const exifMap = {}, gpsRaw = {}, xmpMerged = { editHistory: [], cameraRaw: [], fields: {} }, textMetaPool = {};
        scanAllEmbeddedExifAndXmp(u8, new Set(), exifMap, gpsRaw, xmpMerged, textMetaPool, formatProps);
        const { aiProps, aiSummary } = parseAiGenerationMetadata(textMetaPool, u8);
        formatProps.push(...aiProps);
        photoContext = { exifMap, gpsRaw, iptcMap: {}, xmpMerged, aiSummary };
      } else if (magic.family === 'pdf') {
        const res = parsePdfDocument(u8);
        formatProps.push(...res.formatProps);
        structureProps.push(...res.structureProps);
      } else if (magic.family.startsWith('zip')) {
        const res = await parseZipBasedDocument(u8);
        formatProps.push(...res.formatProps);
        structureProps.push(...res.structureProps);
      } else if (magic.family === 'ole2') {
        const res = parseOle2CompoundFile(u8);
        formatProps.push(...res.formatProps);
        structureProps.push(...res.structureProps);
      } else if (magic.family === 'isobmff' || magic.family === 'isobmff-image') {
        const res = parseIsoBmffMedia(u8, magic.family === 'isobmff-image');
        formatProps.push(...res.formatProps);
        structureProps.push(...res.structureProps);
        photoContext = res.photoContext;
      } else if (magic.family === 'mp3') {
        const res = parseMp3Id3(u8);
        formatProps.push(...res.formatProps);
        structureProps.push(...res.structureProps);
      } else if (magic.format.startsWith('WAV')) {
        const res = parseWavRiff(u8);
        formatProps.push(...res.formatProps);
        structureProps.push(...res.structureProps);
      } else if (magic.family === 'csv' || magic.family === 'text' || magic.family === 'svg') {
        const res = parseCsvAndTextMetadata(u8, ext);
        formatProps.push(...res.formatProps);
        structureProps.push(...res.structureProps);
      }

      const domProbe = await probeDomMediaDimensions(file, magic.family);
      if (domProbe.props.length > 0) {
        formatProps.unshift(...domProbe.props);
      }

      const universalAi = evaluateUniversalAiProvenance(u8, magic, ext, formatProps, structureProps, photoContext);
      const rawVsEdited = evaluateMediaRawVsEdited(u8, magic, ext, formatProps, structureProps, photoContext, universalAi);
      const photoIntel = buildPhotoPillars(photoContext, file.lastModified, file.name);

      const stringsInfo = extractForensicStrings(u8);
      if (stringsInfo.urls.length > 0) {
        forensicsProps.push({ section: 'Embedded URI & Network Indicators', key: `Extracted URLs (${stringsInfo.urls.length})`, value: stringsInfo.urls.join(' | ') });
      }
      if (stringsInfo.emails.length > 0) {
        forensicsProps.push({ section: 'Embedded URI & Network Indicators', key: `Extracted Email Addresses (${stringsInfo.emails.length})`, value: stringsInfo.emails.join(', '), isPII: true });
      }

      const privacyFindings = [];
      const allExtracted = [...generalProps, ...formatProps, ...structureProps, ...forensicsProps];
      for (const item of allExtracted) {
        if (item.isPII || /GPS|Latitude|Longitude|Artist|Author|Creator|Last Modified By|CameraOwnerName|BodySerialNumber|LensSerialNumber|Company|Manager/i.test(item.key)) {
          privacyFindings.push({ key: item.key, value: item.value, section: item.section });
        }
      }
      if (!extensionMatchesMagic) {
        privacyFindings.push({ key: 'Extension Mismatch', value: `File named .${ext} has binary signature ${magic.format}`, section: 'Security Check' });
      }

      const elapsedMs = (performance.now() - t0).toFixed(1);
      generalProps.push({ section: 'File System & Identity', key: 'Local Extraction Time', value: `${elapsedMs} ms` });

      return {
        id: `${file.name}_${file.size}_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        fileName: file.name,
        fileSize: file.size,
        ext: (ext || 'BIN').toUpperCase(),
        magic,
        extensionMatchesMagic,
        thumbUrl: domProbe.thumbUrl,
        generalProps,
        formatProps,
        structureProps,
        forensicsProps,
        privacyFindings,
        rawVsEdited,
        universalAi,
        photoContext,
        photoPillars: photoIntel ? photoIntel.pillars : null,
        isLikelyScrubbedByTransfer: photoIntel ? photoIntel.isLikelyScrubbedByTransfer : false,
        hexHead: generateHexDump(u8, 512),
        hexTail: u8.length > 512 ? generateHexDump(u8.subarray(Math.max(0, u8.length - 256)), 256) : null,
        stringsInfo
      };
    }

    // =========================================================================
    // SYNTHETIC SAMPLE FILE GENERATORS (REAL RENDERABLE IMAGES & DOCUMENTS)
    // =========================================================================
    async function createCanvasJpegBytes(drawType = 'camera') {
      const canvas = document.createElement('canvas');
      canvas.width = 320;
      canvas.height = 200;
      const ctx = canvas.getContext('2d');
      if (drawType === 'camera') {
        const grad = ctx.createLinearGradient(0, 0, 320, 200);
        grad.addColorStop(0, '#0f172a');
        grad.addColorStop(0.5, '#1e3a8a');
        grad.addColorStop(1, '#f59e0b');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, 320, 200);
        ctx.fillStyle = '#fde047';
        ctx.beginPath(); ctx.arc(240, 65, 26, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#090d16';
        ctx.beginPath(); ctx.moveTo(0, 200); ctx.lineTo(95, 95); ctx.lineTo(190, 200); ctx.fill();
        ctx.beginPath(); ctx.moveTo(120, 200); ctx.lineTo(230, 80); ctx.lineTo(320, 200); ctx.fill();
      } else if (drawType === 'android') {
        const grad = ctx.createLinearGradient(0, 0, 320, 200);
        grad.addColorStop(0, '#064e3b');
        grad.addColorStop(0.6, '#047857');
        grad.addColorStop(1, '#10b981');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, 320, 200);
        ctx.fillStyle = 'rgba(255,255,255,0.9)';
        ctx.font = 'bold 14px sans-serif';
        ctx.fillText('Android Camera2 MM Big-Endian', 45, 95);
        ctx.font = '12px monospace';
        ctx.fillText('22.5075° N, 88.2464° E (GPS)', 60, 120);
      } else {
        const grad = ctx.createLinearGradient(0, 0, 320, 200);
        grad.addColorStop(0, '#2e1065');
        grad.addColorStop(0.5, '#7e22ce');
        grad.addColorStop(1, '#06b6d4');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, 320, 200);
        ctx.strokeStyle = 'rgba(255,255,255,0.28)';
        for (let r = 18; r < 110; r += 18) {
          ctx.beginPath(); ctx.arc(160, 100, r, 0, Math.PI * 2); ctx.stroke();
        }
      }
      const dataUrl = canvas.toDataURL('image/jpeg', 0.9);
      const binStr = atob(dataUrl.split(',')[1]);
      const u8 = new Uint8Array(binStr.length);
      for (let i = 0; i < binStr.length; i++) u8[i] = binStr.charCodeAt(i);
      return u8;
    }

    async function buildSampleJpegWithExifAndGps() {
      const baseJpeg = await createCanvasJpegBytes('camera');

      const tiffFull = new Uint8Array(2048);
      const dv = new DataView(tiffFull.buffer);
      tiffFull[0] = 0x49; tiffFull[1] = 0x49; // Little-endian 'II'
      dv.setUint16(2, 42, true);
      dv.setUint32(4, 8, true);

      let pool = 460;
      const tiff = tiffFull;
      function writeAscii(str) {
        const start = pool;
        const bytes = new TextEncoder().encode(str);
        tiff.set(bytes, pool);
        pool += bytes.length;
        tiff[pool++] = 0;
        return { offset: start, len: bytes.length + 1 };
      }
      function writeRational(num, den) {
        const start = pool;
        dv.setUint32(pool, num, true);
        dv.setUint32(pool + 4, den, true);
        pool += 8;
        return start;
      }

      const makeS = writeAscii('Canon Inc.');
      const modelS = writeAscii('Canon EOS R5 Mark II');
      const softS = writeAscii('Firmware Ver 1.0.3 / Adobe Photoshop Lightroom Classic 13.5 (Macintosh)');
      const modDateS = writeAscii('2026:10:24 18:15:09');
      const artistS = writeAscii('Aarav Sen (National Geographic Contributor)');
      const copyS = writeAscii('Copyright (c) 2026 Aarav Sen. All Rights Reserved. CC-BY-NC-4.0');

      const ifd0Entries = [
        [0x010F, 2, makeS.len, makeS.offset],
        [0x0110, 2, modelS.len, modelS.offset],
        [0x0112, 3, 1, 1],
        [0x0131, 2, softS.len, softS.offset],
        [0x0132, 2, modDateS.len, modDateS.offset],
        [0x013B, 2, artistS.len, artistS.offset],
        [0x8298, 2, copyS.len, copyS.offset],
        [0x8769, 4, 1, 128],
        [0x8825, 4, 1, 320]
      ];
      dv.setUint16(8, ifd0Entries.length, true);
      ifd0Entries.forEach((e, idx) => {
        const p = 10 + idx * 12;
        dv.setUint16(p, e[0], true);
        dv.setUint16(p + 2, e[1], true);
        dv.setUint32(p + 4, e[2], true);
        dv.setUint32(p + 8, e[3], true);
      });

      const dtOrigS = writeAscii('2026:10:24 16:42:19');
      const dtDigiS = writeAscii('2026:10:24 16:42:19');
      const offOrigS = writeAscii('+05:30');
      const subSecS = writeAscii('842105');
      const ownerS = writeAscii('Aarav Sen');
      const bodySnS = writeAscii('CN-R5M2-88492014');
      const lensMakeS = writeAscii('Canon');
      const lensModelS = writeAscii('RF 24-70mm F2.8 L IS USM');
      const lensSnS = writeAscii('LN-992011482');
      const expTimeOff = writeRational(1, 800);
      const fNumOff = writeRational(28, 10);
      const focalOff = writeRational(35, 1);
      const lensSpecOff = writeRational(24, 1); writeRational(70, 1); writeRational(28, 10); writeRational(28, 10);

      const subEntries = [
        [0x829A, 5, 1, expTimeOff],
        [0x829D, 5, 1, fNumOff],
        [0x8827, 3, 1, 100],
        [0x9003, 2, dtOrigS.len, dtOrigS.offset],
        [0x9004, 2, dtDigiS.len, dtDigiS.offset],
        [0x9011, 2, offOrigS.len, offOrigS.offset],
        [0x920A, 5, 1, focalOff],
        [0x9291, 2, subSecS.len, subSecS.offset],
        [0xA405, 3, 1, 35],
        [0xA430, 2, ownerS.len, ownerS.offset],
        [0xA431, 2, bodySnS.len, bodySnS.offset],
        [0xA432, 5, 4, lensSpecOff],
        [0xA433, 2, lensMakeS.len, lensMakeS.offset],
        [0xA434, 2, lensModelS.len, lensModelS.offset],
        [0xA435, 2, lensSnS.len, lensSnS.offset]
      ];
      dv.setUint16(128, subEntries.length, true);
      subEntries.forEach((e, idx) => {
        const p = 130 + idx * 12;
        dv.setUint16(p, e[0], true);
        dv.setUint16(p + 2, e[1], true);
        dv.setUint32(p + 4, e[2], true);
        dv.setUint32(p + 8, e[3], true);
      });

      const latOff = writeRational(27, 1); writeRational(2, 1); writeRational(1890, 100);
      const lonOff = writeRational(88, 1); writeRational(15, 1); writeRational(4560, 100);
      const altOff = writeRational(21345, 10);
      const gpsTimeOff = writeRational(11, 1); writeRational(12, 1); writeRational(19, 1);
      const gpsDateS = writeAscii('2026:10:24');
      const gpsDatumS = writeAscii('WGS-84');

      const gpsEntries = [
        [0x0001, 2, 2, 0x004E],
        [0x0002, 5, 3, latOff],
        [0x0003, 2, 2, 0x0045],
        [0x0004, 5, 3, lonOff],
        [0x0005, 1, 1, 0],
        [0x0006, 5, 1, altOff],
        [0x0007, 5, 3, gpsTimeOff],
        [0x0012, 2, gpsDatumS.len, gpsDatumS.offset],
        [0x001D, 2, gpsDateS.len, gpsDateS.offset]
      ];
      dv.setUint16(320, gpsEntries.length, true);
      gpsEntries.forEach((e, idx) => {
        const p = 322 + idx * 12;
        dv.setUint16(p, e[0], true);
        dv.setUint16(p + 2, e[1], true);
        dv.setUint32(p + 4, e[2], true);
        dv.setUint32(p + 8, e[3], true);
      });

      const tiffSlice = tiff.subarray(0, pool);
      const app1ExifPayload = new Uint8Array(6 + tiffSlice.length);
      app1ExifPayload.set([0x45, 0x78, 0x69, 0x66, 0x00, 0x00], 0);
      app1ExifPayload.set(tiffSlice, 6);
      const app1ExifSeg = new Uint8Array(4 + app1ExifPayload.length);
      app1ExifSeg[0] = 0xFF; app1ExifSeg[1] = 0xE1;
      const exifSegLen = app1ExifPayload.length + 2;
      app1ExifSeg[2] = (exifSegLen >> 8) & 0xFF; app1ExifSeg[3] = exifSegLen & 0xFF;
      app1ExifSeg.set(app1ExifPayload, 4);

      const xmpString = `http://ns.adobe.com/xap/1.0/\0<?xpacket begin="" id="W5M0MpArnold"?>
<x:xmpmeta xmlns:x="adobe:ns:meta/">
 <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">
  <rdf:Description rdf:about=""
    xmlns:xmp="http://ns.adobe.com/xap/1.0/"
    xmlns:xmpMM="http://ns.adobe.com/xap/1.0/mm/"
    xmlns:stEvt="http://ns.adobe.com/xap/1.0/sType/ResourceEvent#"
    xmlns:dc="http://purl.org/dc/elements/1.1/"
    xmlns:xmpRights="http://ns.adobe.com/xap/1.0/rights/"
    xmlns:photoshop="http://ns.adobe.com/photoshop/1.0/"
    xmlns:aux="http://ns.adobe.com/exif/1.0/aux/"
    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/"
    xmp:CreatorTool="Adobe Photoshop Lightroom Classic 13.5 (Macintosh)"
    xmp:CreateDate="2026-10-24T16:42:19.842+05:30"
    xmp:ModifyDate="2026-10-24T18:15:09+05:30"
    xmpMM:DocumentID="xmp.did:8842a9f0-112c-4c8b-9a21-77892014c001"
    xmpMM:InstanceID="xmp.iid:f419e002-772a-4910-b122-88392019b104"
    aux:Firmware="Firmware Version 1.0.3"
    aux:Lens="RF 24-70mm F2.8 L IS USM"
    aux:SerialNumber="CN-R5M2-88492014"
    photoshop:Credit="Aarav Sen / Himalayan Visual Archive"
    photoshop:Source="RAW CR3 Master Archive"
    xmpRights:Marked="True"
    xmpRights:WebStatement="https://creativecommons.org/licenses/by-nc/4.0/"
    crs:Version="16.5"
    crs:WhiteBalance="Daylight"
    crs:Exposure2012="+0.45"
    crs:Contrast2012="+18"
    crs:Highlights2012="-32"
    crs:Shadows2012="+28"
    crs:Clarity2012="+15">
   <xmpRights:UsageTerms><rdf:Alt><rdf:li xml:lang="x-default">Licensed for editorial and non-commercial archival use under CC BY-NC 4.0.</rdf:li></rdf:Alt></xmpRights:UsageTerms>
   <xmpMM:History>
    <rdf:Seq>
     <rdf:li stEvt:action="created" stEvt:instanceID="xmp.iid:1001" stEvt:when="2026-10-24T16:42:19+05:30" stEvt:softwareAgent="Canon EOS R5 Mark II Firmware 1.0.3"/>
     <rdf:li stEvt:action="converted" stEvt:parameters="from image/x-canon-cr3 to image/tiff" stEvt:when="2026-10-24T17:50:12+05:30" stEvt:softwareAgent="Adobe Camera Raw 16.5"/>
     <rdf:li stEvt:action="edited" stEvt:changed="/metadata,/crs" stEvt:parameters="Exposure +0.45, Highlights -32, Shadows +28, Clarity +15" stEvt:when="2026-10-24T18:04:33+05:30" stEvt:softwareAgent="Adobe Photoshop Lightroom Classic 13.5 (Macintosh)"/>
     <rdf:li stEvt:action="saved" stEvt:instanceID="xmp.iid:f419e002" stEvt:changed="/" stEvt:parameters="Exported sRGB JPEG Quality 92" stEvt:when="2026-10-24T18:15:09+05:30" stEvt:softwareAgent="Adobe Photoshop 25.11 (Macintosh)"/>
    </rdf:Seq>
   </xmpMM:History>
  </rdf:Description>
 </rdf:RDF>
</x:xmpmeta><?xpacket end="w"?>`;
      const xmpBytes = new TextEncoder().encode(xmpString);
      const app1XmpSeg = new Uint8Array(4 + xmpBytes.length);
      app1XmpSeg[0] = 0xFF; app1XmpSeg[1] = 0xE1;
      const xmpSegLen = xmpBytes.length + 2;
      app1XmpSeg[2] = (xmpSegLen >> 8) & 0xFF; app1XmpSeg[3] = xmpSegLen & 0xFF;
      app1XmpSeg.set(xmpBytes, 4);

      const finalJpeg = new Uint8Array(2 + app1ExifSeg.length + app1XmpSeg.length + (baseJpeg.length - 2));
      finalJpeg[0] = 0xFF; finalJpeg[1] = 0xD8;
      finalJpeg.set(app1ExifSeg, 2);
      finalJpeg.set(app1XmpSeg, 2 + app1ExifSeg.length);
      finalJpeg.set(baseJpeg.subarray(2), 2 + app1ExifSeg.length + app1XmpSeg.length);

      return new File([finalJpeg], 'Himalayan_GoldenHour_EOS_R5II.jpg', { type: 'image/jpeg', lastModified: Date.now() - 86400000 * 2 });
    }

    // Build an authentic Android Smartphone Big-Endian ('MM' / 0x4D4D) JPEG with GPS & Camera2 EXIF
    async function buildSampleAndroidBigEndianPhoto(customLat = 22.5075, customLon = 88.2464, customAlt = 9.4, customMake = 'Samsung', customModel = 'SM-S928B (Galaxy S24 Ultra)') {
      const baseJpeg = await createCanvasJpegBytes('android');
      const tiff = new Uint8Array(2048);
      const dv = new DataView(tiff.buffer);
      // Big-Endian 'MM' (0x4D4D)
      tiff[0] = 0x4D; tiff[1] = 0x4D;
      dv.setUint16(2, 42, false);
      dv.setUint32(4, 8, false);

      let pool = 480;
      function writeAsciiBE(str) {
        const start = pool;
        const bytes = new TextEncoder().encode(str);
        tiff.set(bytes, pool);
        pool += bytes.length;
        tiff[pool++] = 0;
        return { offset: start, len: bytes.length + 1 };
      }
      function writeRationalBE(num, den) {
        const start = pool;
        dv.setUint32(pool, Math.round(num), false);
        dv.setUint32(pool + 4, Math.round(den), false);
        pool += 8;
        return start;
      }

      const now = new Date();
      const pad2 = n => String(n).padStart(2, '0');
      const exifNow = `${now.getFullYear()}:${pad2(now.getMonth() + 1)}:${pad2(now.getDate())} ${pad2(now.getHours())}:${pad2(now.getMinutes())}:${pad2(now.getSeconds())}`;

      const makeS = writeAsciiBE(customMake);
      const modelS = writeAsciiBE(customModel);
      const softS = writeAsciiBE('S928BXXS3AXFE / Android 15 Camera2 API');
      const dtS = writeAsciiBE(exifNow);
      const subS = writeAsciiBE('482');
      const offS = writeAsciiBE('+05:30');
      const lensMakeS = writeAsciiBE(customMake);
      const lensModelS = writeAsciiBE('200MP Wide Quad-Tele 23mm f/1.7 OIS');

      // IFD0 at 8: 7 entries (8..96)
      const ifd0 = [
        [0x010F, 2, makeS.len, makeS.offset],
        [0x0110, 2, modelS.len, modelS.offset],
        [0x0112, 3, 1, 1], // right-aligned in 32-bit field in MM to test our MM SHORT fix!
        [0x0131, 2, softS.len, softS.offset],
        [0x0132, 2, dtS.len, dtS.offset],
        [0x8769, 4, 1, 120],
        [0x8825, 4, 1, 300]
      ];
      dv.setUint16(8, ifd0.length, false);
      ifd0.forEach((e, idx) => {
        const p = 10 + idx * 12;
        dv.setUint16(p, e[0], false);
        dv.setUint16(p + 2, e[1], false);
        dv.setUint32(p + 4, e[2], false);
        dv.setUint32(p + 8, e[3], false);
      });

      const expOff = writeRationalBE(1, 250);
      const fNumOff = writeRationalBE(17, 10);
      const focalOff = writeRationalBE(690, 100);
      const subIfd = [
        [0x829A, 5, 1, expOff],
        [0x829D, 5, 1, fNumOff],
        [0x8827, 3, 1, 64],
        [0x9003, 2, dtS.len, dtS.offset],
        [0x9004, 2, dtS.len, dtS.offset],
        [0x9011, 2, offS.len, offS.offset],
        [0x920A, 5, 1, focalOff],
        [0x9291, 2, subS.len, subS.offset],
        [0xA405, 3, 1, 23],
        [0xA433, 2, lensMakeS.len, lensMakeS.offset],
        [0xA434, 2, lensModelS.len, lensModelS.offset]
      ];
      dv.setUint16(120, subIfd.length, false);
      subIfd.forEach((e, idx) => {
        const p = 122 + idx * 12;
        dv.setUint16(p, e[0], false);
        dv.setUint16(p + 2, e[1], false);
        dv.setUint32(p + 4, e[2], false);
        dv.setUint32(p + 8, e[3], false);
      });

      // Convert decimal lat/lon to DMS Rationals
      function decToDmsRationals(dec) {
        const abs = Math.abs(dec);
        const d = Math.floor(abs);
        const mFloat = (abs - d) * 60;
        const m = Math.floor(mFloat);
        const s = Math.round((mFloat - m) * 60 * 1000);
        const off = writeRationalBE(d, 1);
        writeRationalBE(m, 1);
        writeRationalBE(s, 1000);
        return off;
      }
      const latOff = decToDmsRationals(customLat);
      const lonOff = decToDmsRationals(customLon);
      const altOff = writeRationalBE(Math.round(Math.abs(customAlt) * 100), 100);
      const gpsTimeOff = writeRationalBE(now.getUTCHours(), 1);
      writeRationalBE(now.getUTCMinutes(), 1);
      writeRationalBE(now.getUTCSeconds(), 1);
      const gpsDateS = writeAsciiBE(`${now.getUTCFullYear()}:${pad2(now.getUTCMonth() + 1)}:${pad2(now.getUTCDate())}`);
      const gpsDatumS = writeAsciiBE('WGS-84');

      const latRefCode = customLat >= 0 ? 0x4E000000 : 0x53000000;
      const lonRefCode = customLon >= 0 ? 0x45000000 : 0x57000000;

      const gpsIfd = [
        [0x0001, 2, 2, latRefCode],
        [0x0002, 5, 3, latOff],
        [0x0003, 2, 2, lonRefCode],
        [0x0004, 5, 3, lonOff],
        [0x0005, 1, 1, customAlt < 0 ? 1 : 0],
        [0x0006, 5, 1, altOff],
        [0x0007, 5, 3, gpsTimeOff],
        [0x0012, 2, gpsDatumS.len, gpsDatumS.offset],
        [0x001D, 2, gpsDateS.len, gpsDateS.offset]
      ];
      dv.setUint16(300, gpsIfd.length, false);
      gpsIfd.forEach((e, idx) => {
        const p = 302 + idx * 12;
        dv.setUint16(p, e[0], false);
        dv.setUint16(p + 2, e[1], false);
        dv.setUint32(p + 4, e[2], false);
        dv.setUint32(p + 8, e[3], false);
      });

      const tiffSlice = tiff.subarray(0, pool);
      const app1Payload = new Uint8Array(6 + tiffSlice.length);
      app1Payload.set([0x45, 0x78, 0x69, 0x66, 0x00, 0x00], 0);
      app1Payload.set(tiffSlice, 6);
      const app1Seg = new Uint8Array(4 + app1Payload.length);
      app1Seg[0] = 0xFF; app1Seg[1] = 0xE1;
      const segLen = app1Payload.length + 2;
      app1Seg[2] = (segLen >> 8) & 0xFF; app1Seg[3] = segLen & 0xFF;
      app1Seg.set(app1Payload, 4);

      const finalJpeg = new Uint8Array(2 + app1Seg.length + (baseJpeg.length - 2));
      finalJpeg[0] = 0xFF; finalJpeg[1] = 0xD8;
      finalJpeg.set(app1Seg, 2);
      finalJpeg.set(baseJpeg.subarray(2), 2 + app1Seg.length);

      return new File([finalJpeg], `IMG_${now.getFullYear()}${pad2(now.getMonth() + 1)}${pad2(now.getDate())}_${pad2(now.getHours())}${pad2(now.getMinutes())}${pad2(now.getSeconds())}.jpg`, {
        type: 'image/jpeg',
        lastModified: Date.now()
      });
    }

    async function buildSampleAiGeneratedPhoto() {
      const baseJpeg = await createCanvasJpegBytes('ai');
      const xmpAi = `http://ns.adobe.com/xap/1.0/\0<?xpacket begin="" id="W5M0MpC2PA"?>
<x:xmpmeta xmlns:x="adobe:ns:meta/">
 <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">
  <rdf:Description rdf:about=""
    xmlns:xmp="http://ns.adobe.com/xap/1.0/"
    xmlns:dc="http://purl.org/dc/elements/1.1/"
    xmlns:xmpRights="http://ns.adobe.com/xap/1.0/rights/"
    xmlns:Iptc4xmpExt="http://iptc.org/std/Iptc4xmpExt/2008-02-29/"
    xmlns:c2pa="http://c2pa.org/manifest/1.0/"
    xmp:CreatorTool="ComfyUI v0.2.4 / Stable Diffusion XL (SDXL 1.0) + C2PA Signer"
    xmp:CreateDate="2026-11-05T20:14:55Z"
    Iptc4xmpExt:DigitalSourceType="http://cv.iptc.org/newscodes/digitalsourcetype/trainedAlgorithmicMedia"
    c2pa:generator="ComfyUI + StabilityAI SDXL Pipeline (C2PA 2.0 Signed)"
    c2pa:model="SDXL_RealVisXL_v5.0_BakedVAE.safetensors"
    c2pa:version="v5.0-FP16 (Model Hash: 7f96a1b42c)"
    c2pa:prompt="Futuristic bioluminescent alpine observatory under aurora borealis, crystalline dome architecture, volumetric twilight mist, shot on 35mm anamorphic lens, ultra-detailed 8k photorealistic"
    c2pa:negativePrompt="blurry, lowres, watermark, text, oversaturated, deformed geometry, plastic texture"
    c2pa:seed="394810572941"
    xmpRights:Marked="False">
   <dc:creator><rdf:Seq><rdf:li>Mira Kapoor (Generative Concept Artist)</rdf:li></rdf:Seq></dc:creator>
   <dc:rights><rdf:Alt><rdf:li xml:lang="x-default">CC0 1.0 Universal Public Domain Dedication (AI-Generated Asset)</rdf:li></rdf:Alt></dc:rights>
   <xmpRights:UsageTerms><rdf:Alt><rdf:li xml:lang="x-default">AI-generated visual artwork with verified C2PA Content Credentials.</rdf:li></rdf:Alt></xmpRights:UsageTerms>
  </rdf:Description>
 </rdf:RDF>
</x:xmpmeta><?xpacket end="w"?>`;
      const xmpBytes = new TextEncoder().encode(xmpAi);
      const app1XmpSeg = new Uint8Array(4 + xmpBytes.length);
      app1XmpSeg[0] = 0xFF; app1XmpSeg[1] = 0xE1;
      const xmpLen = xmpBytes.length + 2;
      app1XmpSeg[2] = (xmpLen >> 8) & 0xFF; app1XmpSeg[3] = xmpLen & 0xFF;
      app1XmpSeg.set(xmpBytes, 4);

      const sdComment = `Futuristic bioluminescent alpine observatory under aurora borealis, crystalline dome architecture, volumetric twilight mist, shot on 35mm anamorphic lens, ultra-detailed 8k photorealistic\nNegative prompt: blurry, lowres, watermark, text, oversaturated, deformed geometry, plastic texture\nSteps: 36, Sampler: DPM++ 2M Karras, Schedule type: Karras, CFG scale: 6.5, Seed: 394810572941, Size: 1536x1024, Model hash: 7f96a1b42c, Model: SDXL_RealVisXL_v5.0_BakedVAE, Version: f2.0.1v1.10.1-RC`;
      const comBytes = new TextEncoder().encode(sdComment);
      const comSeg = new Uint8Array(4 + comBytes.length);
      comSeg[0] = 0xFF; comSeg[1] = 0xFE;
      const comLen = comBytes.length + 2;
      comSeg[2] = (comLen >> 8) & 0xFF; comSeg[3] = comLen & 0xFF;
      comSeg.set(comBytes, 4);

      const finalJpeg = new Uint8Array(2 + app1XmpSeg.length + comSeg.length + (baseJpeg.length - 2));
      finalJpeg[0] = 0xFF; finalJpeg[1] = 0xD8;
      finalJpeg.set(app1XmpSeg, 2);
      finalJpeg.set(comSeg, 2 + app1XmpSeg.length);
      finalJpeg.set(baseJpeg.subarray(2), 2 + app1XmpSeg.length + comSeg.length);

      return new File([finalJpeg], 'AI_Aurora_Observatory_SDXL_C2PA.jpg', { type: 'image/jpeg', lastModified: Date.now() - 3600000 * 6 });
    }

    function buildSamplePdfDocument() {
      const pdfContent = `%PDF-1.7
1 0 obj
<< /Type /Catalog /Pages 2 0 R /AcroForm << /Fields [] >> /Outlines 5 0 R >>
endobj
2 0 obj
<< /Type /Pages /Kids [3 0 R 4 0 R] /Count 14 >>
endobj
3 0 obj
<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 << /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >> /F2 << /Type /Font /Subtype /Type1 /BaseFont /Times-Roman >> >> >> >>
endobj
6 0 obj
<<
  /Title (Q4 Global Infrastructure Security & Architecture Audit)
  /Author (Dr. Elena Rostova, Principal Security Architect)
  /Subject (Confidential Enterprise Cloud & Cryptographic Posture Assessment)
  /Keywords (Security, Zero-Trust, Audit, Cryptography, Compliance, ISO27001)
  /Creator (LaTeX with hyperref package 7.01g)
  /Producer (LuaHBTeX-1.18.0 / MetaFinder Synthetic Engine)
  /CreationDate (D:20261015093045+05'30')
  /ModDate (D:20261105181210+05'30')
  /Trapped /False
>>
endobj
7 0 obj
<< /Type /Metadata /Subtype /XML /Length 420 >>
stream
<x:xmpmeta xmlns:x="adobe:ns:meta/">
 <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">
  <rdf:Description rdf:about="" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:xmp="http://ns.adobe.com/xap/1.0/" xmlns:pdf="http://ns.adobe.com/pdf/1.3/">
   <dc:format>application/pdf</dc:format>
   <xmp:CreatorTool>TeX Live 2026 Enterprise Publishing Pipeline</xmp:CreatorTool>
   <pdf:PDFVersion>1.7</pdf:PDFVersion>
   <pdf:Producer>LuaHBTeX-1.18.0</pdf:Producer>
  </rdf:Description>
 </rdf:RDF>
</x:xmpmeta>
endstream
endobj
trailer
<< /Root 1 0 R /Info 6 0 R >>
%%EOF`;
      return new File([new TextEncoder().encode(pdfContent)], 'Q4_Infrastructure_Security_Audit.pdf', { type: 'application/pdf', lastModified: Date.now() - 3600000 * 12 });
    }

    function createStoredZip(filesMap, fileName, mimeType) {
      const enc = new TextEncoder();
      const localParts = [];
      const centralParts = [];
      let offset = 0;

      for (const [name, content] of Object.entries(filesMap)) {
        const nameBytes = enc.encode(name);
        const dataBytes = typeof content === 'string' ? enc.encode(content) : content;
        const crc = parseInt(computeCRC32(dataBytes), 16);

        const localHdr = new Uint8Array(30 + nameBytes.length + dataBytes.length);
        const ldv = new DataView(localHdr.buffer);
        ldv.setUint32(0, 0x04034b50, true);
        ldv.setUint16(4, 20, true);
        ldv.setUint16(8, 0, true);
        ldv.setUint16(10, 0x8421, true);
        ldv.setUint16(12, 0x5D66, true);
        ldv.setUint32(14, crc, true);
        ldv.setUint32(18, dataBytes.length, true);
        ldv.setUint32(22, dataBytes.length, true);
        ldv.setUint16(26, nameBytes.length, true);
        localHdr.set(nameBytes, 30);
        localHdr.set(dataBytes, 30 + nameBytes.length);
        localParts.push(localHdr);

        const cdHdr = new Uint8Array(46 + nameBytes.length);
        const cdv = new DataView(cdHdr.buffer);
        cdv.setUint32(0, 0x02014b50, true);
        cdv.setUint16(4, 20, true);
        cdv.setUint16(6, 20, true);
        cdv.setUint16(10, 0, true);
        cdv.setUint16(12, 0x8421, true);
        cdv.setUint16(14, 0x5D66, true);
        cdv.setUint32(16, crc, true);
        cdv.setUint32(20, dataBytes.length, true);
        cdv.setUint32(24, dataBytes.length, true);
        cdv.setUint16(28, nameBytes.length, true);
        cdv.setUint32(42, offset, true);
        cdHdr.set(nameBytes, 46);
        centralParts.push(cdHdr);

        offset += localHdr.length;
      }

      const cdSize = centralParts.reduce((a, b) => a + b.length, 0);
      const eocd = new Uint8Array(22);
      const edv = new DataView(eocd.buffer);
      edv.setUint32(0, 0x06054b50, true);
      edv.setUint16(8, centralParts.length, true);
      edv.setUint16(10, centralParts.length, true);
      edv.setUint32(12, cdSize, true);
      edv.setUint32(16, offset, true);

      return new File([...localParts, ...centralParts, eocd], fileName, { type: mimeType, lastModified: Date.now() - 7200000 });
    }

    function buildSampleDocx() {
      return createStoredZip({
        '[Content_Types].xml': `<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"></Types>`,
        'docProps/core.xml': `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
          <cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/">
            <dc:title>Project Hyperion — 2027 Product Strategy Charter</dc:title>
            <dc:subject>Global Product Roadmap &amp; Engineering Allocation</dc:subject>
            <dc:creator>Maya Lin (VP of Product Strategy)</dc:creator>
            <cp:keywords>Strategy, Hyperion, Roadmap, Confidential, FY2027</cp:keywords>
            <dc:description>Executive briefing document covering milestone gates and budget allocation.</dc:description>
            <cp:lastModifiedBy>Siddharth Verma (Legal Review)</cp:lastModifiedBy>
            <cp:revision>18</cp:revision>
            <cp:category>Executive Briefing</cp:category>
            <cp:contentStatus>Final Approved</cp:contentStatus>
            <dc:language>en-US</dc:language>
            <dcterms:created>2026-09-12T10:15:00Z</dcterms:created>
            <dcterms:modified>2026-11-04T19:45:22Z</dcterms:modified>
          </cp:coreProperties>`,
        'docProps/app.xml': `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
          <Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties">
            <Template>Enterprise_Briefing_v4.dotm</Template>
            <TotalTime>342</TotalTime>
            <Pages>28</Pages>
            <Words>9420</Words>
            <Characters>53694</Characters>
            <CharactersWithSpaces>62980</CharactersWithSpaces>
            <Application>Microsoft Office Word</Application>
            <DocSecurity>0</DocSecurity>
            <Lines>447</Lines>
            <Paragraphs>126</Paragraphs>
            <Manager>Vikramaditya Rao</Manager>
            <Company>Apex Autonomous Systems Ltd.</Company>
            <AppVersion>16.0000</AppVersion>
          </Properties>`,
        'docProps/custom.xml': `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
          <Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/custom-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">
            <property fmtid="{D5CDD505-2E9C-101B-9397-08002B2CF9AE}" pid="2" name="Classification"><vt:lpwstr>Internal Restricted - Level 3</vt:lpwstr></property>
            <property fmtid="{D5CDD505-2E9C-101B-9397-08002B2CF9AE}" pid="3" name="CostCenter"><vt:lpwstr>CC-9042-R&amp;D</vt:lpwstr></property>
            <property fmtid="{D5CDD505-2E9C-101B-9397-08002B2CF9AE}" pid="4" name="DocumentOwnerEmail"><vt:lpwstr>maya.lin@apex-systems.example.com</vt:lpwstr></property>
          </Properties>`,
        'word/document.xml': `<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:p><w:r><w:t>Project Hyperion Charter</w:t></w:r></w:p></w:body></w:document>`,
        'word/media/architecture_diagram.png': new Uint8Array([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A])
      }, 'Project_Hyperion_Strategy_Charter.docx', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document');
    }

    function buildSamplePptx() {
      return createStoredZip({
        '[Content_Types].xml': `<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"></Types>`,
        'docProps/core.xml': `<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/">
          <dc:title>Series C Investor Keynote Deck</dc:title>
          <dc:creator>Rohan Chatterjee (CEO)</dc:creator>
          <cp:lastModifiedBy>Design Studio Ops</cp:lastModifiedBy>
          <cp:revision>42</cp:revision>
          <dcterms:created>2026-10-01T08:00:00Z</dcterms:created>
          <dcterms:modified>2026-11-06T11:20:00Z</dcterms:modified>
        </cp:coreProperties>`,
        'docProps/app.xml': `<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties">
          <Application>Microsoft Macintosh PowerPoint</Application>
          <PresentationFormat>Widescreen (16:9)</PresentationFormat>
          <Slides>24</Slides>
          <Notes>19</Notes>
          <HiddenSlides>3</HiddenSlides>
          <MMClips>2</MMClips>
          <Company>NovaGrid Energy Corp</Company>
          <TotalTime>615</TotalTime>
          <AppVersion>16.0000</AppVersion>
        </Properties>`,
        'ppt/slides/slide1.xml': `<p:sld/>`,
        'ppt/slides/slide2.xml': `<p:sld/>`,
        'ppt/slides/slide3.xml': `<p:sld/>`,
        'ppt/media/cover_graphic.jpg': new Uint8Array([0xFF, 0xD8, 0xFF, 0xD9])
      }, 'Series_C_Investor_Keynote.pptx', 'application/vnd.openxmlformats-officedocument.presentationml.presentation');
    }

    function buildSampleLegacyDoc() {
      const u8 = new Uint8Array(1536);
      const dv = new DataView(u8.buffer);
      u8.set([0xD0, 0xCF, 0x11, 0xE0, 0xA1, 0xB1, 0x1A, 0xE1], 0);
      dv.setUint16(24, 0x003E, true);
      dv.setUint16(26, 0x0003, true);
      dv.setUint16(28, 0xFFFE, true);
      dv.setUint16(30, 9, true);
      dv.setUint16(32, 6, true);
      dv.setUint32(44, 1, true);
      dv.setUint32(48, 0, true);

      function writeDirEntry(slot, name, type, size) {
        const base = 512 + slot * 128;
        for (let i = 0; i < name.length; i++) dv.setUint16(base + i * 2, name.charCodeAt(i), true);
        dv.setUint16(base + 64, (name.length + 1) * 2, true);
        u8[base + 66] = type;
        dv.setUint32(base + 120, size, true);
      }
      writeDirEntry(0, 'Root Entry', 5, 0);
      writeDirEntry(1, 'WordDocument', 2, 48128);
      writeDirEntry(2, 'SummaryInformation', 2, 4096);

      const sBase = 1024;
      u8.set([0xE0, 0x85, 0x9F, 0xF2, 0xF9, 0x4F, 0x68, 0x10, 0xAB, 0x91, 0x08, 0x00, 0x2B, 0x27, 0xB3, 0xD9], sBase + 28);
      dv.setUint32(sBase + 44, 48, true);
      const ps = sBase + 48;
      dv.setUint32(ps + 4, 4, true);
      const props = [
        [2, 'Legacy M&A Due Diligence Agreement (1997-2003 Format)'],
        [4, 'Arthur Pendelton, Senior Counsel'],
        [8, 'Compliance Archive Bot'],
        [18, 'Microsoft Word 11.0 (Office 2003)']
      ];
      let valCursor = 8 + props.length * 8;
      props.forEach(([pid, text], idx) => {
        dv.setUint32(ps + 8 + idx * 8, pid, true);
        dv.setUint32(ps + 12 + idx * 8, valCursor, true);
        dv.setUint32(ps + valCursor, 30, true);
        dv.setUint32(ps + valCursor + 4, text.length + 1, true);
        for (let c = 0; c < text.length; c++) u8[ps + valCursor + 8 + c] = text.charCodeAt(c);
        valCursor += 8 + text.length + 1;
      });

      return new File([u8], 'Legacy_Contract_Agreement.doc', { type: 'application/msword', lastModified: Date.now() - 86400000 * 90 });
    }

    function buildSampleEpub() {
      return createStoredZip({
        'mimetype': 'application/epub+zip',
        'META-INF/container.xml': `<?xml version="1.0" encoding="UTF-8"?>
          <container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container">
            <rootfiles><rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/></rootfiles>
          </container>`,
        'OEBPS/content.opf': `<?xml version="1.0" encoding="UTF-8"?>
          <package xmlns="http://www.idpf.org/2007/opf" version="3.0" unique-identifier="pub-id">
            <metadata xmlns:dc="http://purl.org/dc/elements/1.1/">
              <dc:title>Cryptographic Systems &amp; Binary Architecture</dc:title>
              <dc:creator>Prof. Nandini Sen</dc:creator>
              <dc:publisher>Calcutta University Technical Press</dc:publisher>
              <dc:identifier id="pub-id">urn:isbn:978-93-89412-44-7</dc:identifier>
              <dc:language>en-IN</dc:language>
              <dc:date>2026-08-15</dc:date>
              <dc:subject>Computer Science / Digital Forensics / File Formats</dc:subject>
              <dc:description>A comprehensive reference manual on binary file containers, metadata forensics, and zero-trust verification.</dc:description>
              <dc:rights>Copyright © 2026 Prof. Nandini Sen. All rights reserved.</dc:rights>
              <meta property="dcterms:modified">2026-10-20T14:00:00Z</meta>
              <meta name="cover" content="cover-image"/>
            </metadata>
            <manifest>
              <item id="ch1" href="ch1.xhtml" media-type="application/xhtml+xml"/>
              <item id="ch2" href="ch2.xhtml" media-type="application/xhtml+xml"/>
              <item id="ch3" href="ch3.xhtml" media-type="application/xhtml+xml"/>
              <item id="css" href="style.css" media-type="text/css"/>
            </manifest>
            <spine>
              <itemref idref="ch1"/>
              <itemref idref="ch2"/>
              <itemref idref="ch3"/>
            </spine>
          </package>`
      }, 'Cryptographic_Systems_Handbook.epub', 'application/epub+zip');
    }

    function buildSampleMp4() {
      const u8 = new Uint8Array(244);
      const dv = new DataView(u8.buffer);
      const enc = new TextEncoder();

      dv.setUint32(0, 24, false);
      u8.set(enc.encode('ftypisom'), 4);
      dv.setUint32(12, 512, false);
      u8.set(enc.encode('isomiso2mp41'), 16);

      dv.setUint32(24, 220, false);
      u8.set(enc.encode('moov'), 28);

      dv.setUint32(32, 108, false);
      u8.set(enc.encode('mvhd'), 36);
      dv.setUint32(44, 3876543210, false);
      dv.setUint32(48, 3876543210, false);
      dv.setUint32(52, 1000, false);
      dv.setUint32(56, 142500, false);

      dv.setUint32(140, 104, false);
      u8.set(enc.encode('trak'), 144);

      dv.setUint32(148, 96, false);
      u8.set(enc.encode('tkhd'), 152);
      dv.setUint32(168, 1, false);
      dv.setUint32(232, 3840 * 65536, false);
      dv.setUint32(236, 2160 * 65536, false);

      return new File([u8], 'Drone_Aerial_Footage_4K_UHD.mp4', { type: 'video/mp4', lastModified: Date.now() - 3600000 * 5 });
    }

    function buildSampleAiVideoMp4() {
      // Build an ISO BMFF MP4 video with C2PA JUMBF UUID box + udta ©too and ©cmt AI video prompt & model metadata
      const enc = new TextEncoder();
      const c2paPayload = enc.encode('c2pa.actions: c2pa.created | digitalSourceType: http://cv.iptc.org/newscodes/digitalsourcetype/trainedAlgorithmicMedia | Generator: OpenAI Sora 1.0 Turbo Video Pipeline | Model: Sora-1.0-Turbo-1080p');
      const uuidBoxLen = 8 + 16 + c2paPayload.length;

      const tooPayload = enc.encode('OpenAI Sora 1.0 / ComfyUI Video Workflow v2.1');
      const tooBoxLen = 8 + tooPayload.length;

      const cmtPayload = enc.encode('Prompt: Cinematic drone flythrough of a floating solarpunk metropolis above emerald clouds at sunrise, volumetric god rays, 60fps photorealistic | Negative prompt: flicker, warping, lowres, watermark | Seed: 884120954, Steps: 50, CFG scale: 7.0, Model: Sora-1.0-Turbo-1080p');
      const cmtBoxLen = 8 + cmtPayload.length;

      const udtaLen = 8 + tooBoxLen + cmtBoxLen;
      const mvhdLen = 108;
      const tkhdLen = 96;
      const trakLen = 8 + tkhdLen;
      const moovLen = 8 + mvhdLen + trakLen + udtaLen;
      const ftypLen = 24;

      const totalLen = ftypLen + uuidBoxLen + moovLen;
      const u8 = new Uint8Array(totalLen);
      const dv = new DataView(u8.buffer);

      // 1. ftyp (24B)
      dv.setUint32(0, ftypLen, false);
      u8.set(enc.encode('ftypisom'), 4);
      dv.setUint32(12, 512, false);
      u8.set(enc.encode('isomiso2mp41'), 16);

      // 2. uuid C2PA JUMBF box
      let p = ftypLen;
      dv.setUint32(p, uuidBoxLen, false);
      u8.set(enc.encode('uuid'), p + 4);
      const c2paUuidHex = [0xd8, 0xfe, 0xc3, 0xd6, 0x1b, 0x0e, 0x48, 0x3c, 0x92, 0x97, 0x58, 0x28, 0x87, 0x7e, 0xc4, 0x81];
      u8.set(c2paUuidHex, p + 8);
      u8.set(c2paPayload, p + 24);

      // 3. moov
      p += uuidBoxLen;
      dv.setUint32(p, moovLen, false);
      u8.set(enc.encode('moov'), p + 4);

      // 3a. mvhd
      let mp = p + 8;
      dv.setUint32(mp, mvhdLen, false);
      u8.set(enc.encode('mvhd'), mp + 4);
      dv.setUint32(mp + 12, 3876543210, false);
      dv.setUint32(mp + 16, 3876546810, false);
      dv.setUint32(mp + 20, 1000, false);
      dv.setUint32(mp + 24, 15000, false); // 15.0 sec AI video

      // 3b. trak -> tkhd
      mp += mvhdLen;
      dv.setUint32(mp, trakLen, false);
      u8.set(enc.encode('trak'), mp + 4);
      dv.setUint32(mp + 8, tkhdLen, false);
      u8.set(enc.encode('tkhd'), mp + 12);
      dv.setUint32(mp + 28, 1, false);
      dv.setUint32(mp + 92, 1920 * 65536, false);
      dv.setUint32(mp + 96, 1080 * 65536, false);

      // 3c. udta -> ©too + ©cmt
      mp += trakLen;
      dv.setUint32(mp, udtaLen, false);
      u8.set(enc.encode('udta'), mp + 4);

      let up = mp + 8;
      dv.setUint32(up, tooBoxLen, false);
      u8.set([0xA9, 0x74, 0x6F, 0x6F], up + 4); // ©too
      u8.set(tooPayload, up + 8);

      up += tooBoxLen;
      dv.setUint32(up, cmtBoxLen, false);
      u8.set([0xA9, 0x63, 0x6D, 0x74], up + 4); // ©cmt
      u8.set(cmtPayload, up + 8);

      return new File([u8], 'AI_Solarpunk_Metropolis_Sora_C2PA.mp4', { type: 'video/mp4', lastModified: Date.now() - 1800000 });
    }

    function buildSampleEditedVideoMp4() {
      const enc = new TextEncoder();
      const tooPayload = enc.encode('Adobe Premiere Pro 2026.1 (Macintosh) / CapCut Video Editor / Lavf60.16.100');
      const tooBoxLen = 8 + tooPayload.length;
      const cmtPayload = enc.encode('Edited timeline export: Color graded with LUT_Rec709_Cinema.cube, stabilized 24fps, audio normalized -14 LUFS');
      const cmtBoxLen = 8 + cmtPayload.length;
      const xmpPayload = enc.encode(`<x:xmpmeta xmlns:x="adobe:ns:meta/"><rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"><rdf:Description rdf:about="" xmlns:xmp="http://ns.adobe.com/xap/1.0/" xmlns:xmpMM="http://ns.adobe.com/xap/1.0/mm/" xmlns:stEvt="http://ns.adobe.com/xap/1.0/sType/ResourceEvent#" xmp:CreatorTool="Adobe Premiere Pro 2026.1 (Macintosh)" xmp:CreateDate="2026-11-05T10:00:00Z" xmp:ModifyDate="2026-11-05T14:35:20Z"><xmpMM:History><rdf:Seq><rdf:li stEvt:action="created" stEvt:when="2026-11-05T10:00:00Z" stEvt:softwareAgent="Sony FX3 Cinema Line Camera"/><rdf:li stEvt:action="edited" stEvt:changed="/video,/audio,/color" stEvt:parameters="Timeline cut + Lumetri Color grade + Audio ducking" stEvt:when="2026-11-05T14:20:00Z" stEvt:softwareAgent="Adobe Premiere Pro 2026.1"/><rdf:li stEvt:action="saved" stEvt:parameters="H.264 Match Source High Bitrate" stEvt:when="2026-11-05T14:35:20Z" stEvt:softwareAgent="Adobe Media Encoder 2026.1"/></rdf:Seq></xmpMM:History></rdf:Description></rdf:RDF></x:xmpmeta>`);
      const uuidBoxLen = 8 + 16 + xmpPayload.length;

      const udtaLen = 8 + tooBoxLen + cmtBoxLen;
      const mvhdLen = 108;
      const tkhdLen = 96;
      const trakLen = 8 + tkhdLen;
      const moovLen = 8 + mvhdLen + trakLen + udtaLen;
      const ftypLen = 24;

      const u8 = new Uint8Array(ftypLen + uuidBoxLen + moovLen);
      const dv = new DataView(u8.buffer);

      dv.setUint32(0, ftypLen, false);
      u8.set(enc.encode('ftypmp42'), 4);
      dv.setUint32(12, 0, false);
      u8.set(enc.encode('mp42isomavc1'), 16);

      let p = ftypLen;
      dv.setUint32(p, uuidBoxLen, false);
      u8.set(enc.encode('uuid'), p + 4);
      u8.set([0xBE, 0x7A, 0xCF, 0xCB, 0x97, 0xA9, 0x42, 0xE8, 0x9C, 0x71, 0x99, 0x94, 0x91, 0xE3, 0xAF, 0xAC], p + 8);
      u8.set(xmpPayload, p + 24);

      p += uuidBoxLen;
      dv.setUint32(p, moovLen, false);
      u8.set(enc.encode('moov'), p + 4);

      let mp = p + 8;
      dv.setUint32(mp, mvhdLen, false);
      u8.set(enc.encode('mvhd'), mp + 4);
      dv.setUint32(mp + 12, 3876540000, false); // creation_time
      dv.setUint32(mp + 16, 3876556520, false); // modification_time (+16,520 sec later!)
      dv.setUint32(mp + 20, 1000, false);
      dv.setUint32(mp + 24, 64200, false);

      mp += mvhdLen;
      dv.setUint32(mp, trakLen, false);
      u8.set(enc.encode('trak'), mp + 4);
      dv.setUint32(mp + 8, tkhdLen, false);
      u8.set(enc.encode('tkhd'), mp + 12);
      dv.setUint32(mp + 28, 1, false);
      dv.setUint32(mp + 92, 3840 * 65536, false);
      dv.setUint32(mp + 96, 2160 * 65536, false);

      mp += trakLen;
      dv.setUint32(mp, udtaLen, false);
      u8.set(enc.encode('udta'), mp + 4);

      let up = mp + 8;
      dv.setUint32(up, tooBoxLen, false);
      u8.set([0xA9, 0x74, 0x6F, 0x6F], up + 4);
      u8.set(tooPayload, up + 8);

      up += tooBoxLen;
      dv.setUint32(up, cmtBoxLen, false);
      u8.set([0xA9, 0x63, 0x6D, 0x74], up + 4);
      u8.set(cmtPayload, up + 8);

      return new File([u8], 'Edited_Commercial_Cut_PremierePro.mp4', { type: 'video/mp4', lastModified: Date.now() - 900000 });
    }

    function buildSampleEditedWavAudio() {
      const enc = new TextEncoder();
      const isftBytes = enc.encode('Adobe Audition 24.6 (Macintosh) / Audacity 3.6.1 Mastering Chain\0');
      const inamBytes = enc.encode('Podcast Episode 42 — Vocal Mastered & De-Noised\0');
      const iartBytes = enc.encode('Studio Sound Lab\0');
      const icmtBytes = enc.encode('Processed with iZotope RX 11 Spectral De-noise + Parametric EQ + Compressor\0');

      function padEven(len) { return len + (len % 2); }
      const infoPayloadLen = 4 + (8 + padEven(isftBytes.length)) + (8 + padEven(inamBytes.length)) + (8 + padEven(iartBytes.length)) + (8 + padEven(icmtBytes.length));
      const fmtLen = 16;
      const dataLen = 64;
      const totalRiffPayload = 4 + (8 + fmtLen) + (8 + infoPayloadLen) + (8 + dataLen);

      const u8 = new Uint8Array(8 + totalRiffPayload);
      const dv = new DataView(u8.buffer);
      u8.set(enc.encode('RIFF'), 0);
      dv.setUint32(4, totalRiffPayload, true);
      u8.set(enc.encode('WAVE'), 8);

      // fmt chunk at 12
      let p = 12;
      u8.set(enc.encode('fmt '), p);
      dv.setUint32(p + 4, fmtLen, true);
      dv.setUint16(p + 8, 1, true); // PCM
      dv.setUint16(p + 10, 2, true); // Stereo
      dv.setUint32(p + 12, 48000, true); // 48 kHz
      dv.setUint32(p + 16, 48000 * 2 * 3, true); // byteRate
      dv.setUint16(p + 20, 6, true);
      dv.setUint16(p + 22, 24, true); // 24-bit
      p += 8 + fmtLen;

      // LIST INFO chunk
      u8.set(enc.encode('LIST'), p);
      dv.setUint32(p + 4, infoPayloadLen, true);
      u8.set(enc.encode('INFO'), p + 8);
      let ip = p + 12;
      for (const [id, bytes] of [['ISFT', isftBytes], ['INAM', inamBytes], ['IART', iartBytes], ['ICMT', icmtBytes]]) {
        u8.set(enc.encode(id), ip);
        dv.setUint32(ip + 4, bytes.length, true);
        u8.set(bytes, ip + 8);
        ip += 8 + padEven(bytes.length);
      }
      p += 8 + infoPayloadLen;

      // data chunk
      u8.set(enc.encode('data'), p);
      dv.setUint32(p + 4, dataLen, true);

      return new File([u8], 'Mastered_Podcast_Vocal_Audition_RX11.wav', { type: 'audio/wav', lastModified: Date.now() - 600000 });
    }

    function buildSampleCsv() {
      const csv = `transaction_id,timestamp_utc,merchant_name,category,amount_usd,currency,risk_score,verified_contact
TXN-9001,2026-11-01T08:14:22Z,CloudScale Compute Inc,Infrastructure,1420.50,USD,0.04,billing@cloudscale.example.com
TXN-9002,2026-11-01T11:30:05Z,VectorDB Enterprise,Software,890.00,USD,0.12,accounts@vectordb.example.com
TXN-9003,2026-11-02T14:22:19Z,Global Air Logistics,Travel,3150.75,USD,0.28,ops@airlogistics.example.com
TXN-9004,2026-11-03T09:05:44Z,Quantum Shield Security,Security,4500.00,USD,0.02,audit@quantumshield.example.com
TXN-9005,2026-11-04T17:49:10Z,Nordic Data Center AB,Infrastructure,2180.25,USD,0.08,noc@nordicdc.example.com
TXN-9006,2026-11-05T19:11:00Z,Apex Research Labs,R&D,620.00,USD,,research@apexlabs.example.com`;
      return new File([new TextEncoder().encode(csv)], 'Enterprise_Q4_Transactions_Dataset.csv', { type: 'text/csv', lastModified: Date.now() - 1800000 });
    }

    // =========================================================================
    // UI RENDERING & INTERACTION HANDLERS
    // =========================================================================
    function renderFileQueue() {
      const list = document.getElementById('fileQueueList');
      const countEl = document.getElementById('queueCount');
      const clearBtn = document.getElementById('btnClearQueue');
      countEl.textContent = String(state.files.length);

      if (state.files.length === 0) {
        clearBtn.classList.add('hidden');
        list.innerHTML = `<div class="text-xs text-slate-500 py-4 text-center">No files loaded yet. Drop a file or click a test sample above.</div>`;
        return;
      }

      clearBtn.classList.remove('hidden');
      list.innerHTML = state.files.map((item, idx) => {
        const active = idx === state.activeIndex;
        const totalProps = item.generalProps.length + item.formatProps.length + item.structureProps.length + item.forensicsProps.length;
        return `
          <div data-queue-idx="${idx}" class="queue-item group flex items-center justify-between gap-2 p-2.5 rounded-xl border transition cursor-pointer ${
            active
              ? 'bg-sky-500/15 border-sky-500/50 text-white'
              : 'bg-slate-900/60 border-slate-800/80 text-slate-300 hover:bg-slate-800/70'
          }">
            <div class="flex items-center gap-2.5 min-w-0">
              <span class="px-1.5 py-0.5 rounded text-[10px] font-bold mono bg-slate-800 text-sky-400 border border-slate-700 shrink-0">${escapeHtml(item.ext.slice(0, 5))}</span>
              <div class="min-w-0">
                <div class="text-xs font-semibold truncate">${escapeHtml(item.fileName)}</div>
                <div class="text-[11px] text-slate-400">${formatBytes(item.fileSize).split(' (')[0]} • ${totalProps} fields</div>
              </div>
            </div>
            <button type="button" data-remove-idx="${idx}" title="Remove file" class="remove-queue-btn text-slate-500 hover:text-rose-400 px-1.5 py-0.5 rounded text-xs">✕</button>
          </div>
        `;
      }).join('');
    }

    function renderPrivacyAudit(report) {
      const card = document.getElementById('privacyCard');
      const badge = document.getElementById('privacyRiskBadge');
      const list = document.getElementById('privacyFindingsList');

      if (!report) {
        card.classList.add('hidden');
        return;
      }
      card.classList.remove('hidden');

      const findings = report.privacyFindings;
      if (findings.length === 0) {
        badge.className = 'badge-pill bg-emerald-500/15 text-emerald-300 border border-emerald-500/30';
        badge.textContent = 'Clean (No PII Tags)';
        list.innerHTML = `<p class="text-slate-400">No GPS coordinates, author names, serial numbers, or embedded email addresses were detected in this file's metadata.</p>`;
      } else {
        const hasGps = findings.some(f => /GPS/i.test(f.key));
        badge.className = hasGps
          ? 'badge-pill bg-rose-500/20 text-rose-300 border border-rose-500/40'
          : 'badge-pill bg-amber-500/20 text-amber-300 border border-amber-500/40';
        badge.textContent = hasGps ? `High (${findings.length} PII/Geo Tags)` : `${findings.length} Identity/Trace Tag(s)`;
        list.innerHTML = findings.slice(0, 8).map(f => `
          <div class="p-2 rounded-lg bg-slate-900/90 border border-slate-800 flex flex-col gap-0.5">
            <span class="text-[11px] font-semibold text-amber-300">${escapeHtml(f.key)}</span>
            <span class="text-xs text-slate-200 break-all mono">${escapeHtml(f.value)}</span>
          </div>
        `).join('');
      }
    }

    function renderRawVsEditedInspector(report) {
      const panel = document.getElementById('rawVsEditedPanel');
      const badge = document.getElementById('rawVsEditedVerdictBadge');
      const dot = document.getElementById('rawVsEditedDot');
      const grid = document.getElementById('rawVsEditedGrid');
      const hdrBadge = document.getElementById('rawVsEditedHeaderBadge');

      if (!report || !report.rawVsEdited) {
        panel.classList.add('hidden');
        hdrBadge.classList.add('hidden');
        return;
      }

      const re = report.rawVsEdited;
      panel.classList.remove('hidden');
      badge.className = `badge-pill ${re.badgeClass}`;
      badge.textContent = re.verdictBadgeText;
      dot.className = `w-2.5 h-2.5 rounded-full ${re.dotClass}`;

      hdrBadge.classList.remove('hidden');
      hdrBadge.className = `badge-pill ${re.badgeClass}`;
      hdrBadge.textContent = re.verdictBadgeText;

      const cards = [
        ['Authenticity Verdict (Raw vs. Edited)', re.verdictBadgeText],
        ['Editing Software / App / NLE / DAW', re.appsSummary],
        ['Original Capture Device / Recorder', re.captureDevice],
        ['Capture vs. Last Save Timestamp Delta', re.timestampComparison],
        ['Edit Operations, Sliders & Processing', re.opsSummary],
        ['Forensic Authenticity Basis', re.evidenceSummary]
      ];

      grid.innerHTML = cards.map(([k, v]) => `
        <div class="p-3 rounded-xl bg-slate-900/90 border border-slate-800 flex flex-col gap-1">
          <span class="text-[11px] font-semibold text-emerald-300">${escapeHtml(k)}</span>
          <span class="text-xs text-slate-100 mono break-words leading-relaxed">${escapeHtml(v)}</span>
        </div>
      `).join('');
    }

    function renderUniversalAiInspector(report) {
      const panel = document.getElementById('universalAiPanel');
      const badge = document.getElementById('universalAiVerdictBadge');
      const dot = document.getElementById('universalAiDot');
      const grid = document.getElementById('universalAiGrid');
      const topAiBadge = document.getElementById('aiDetectionBadge');

      if (!report || !report.universalAi) {
        panel.classList.add('hidden');
        topAiBadge.classList.add('hidden');
        return;
      }

      const ua = report.universalAi;
      panel.classList.remove('hidden');
      badge.className = `badge-pill ${ua.verdictBadgeClass}`;
      badge.textContent = ua.verdictLabel;
      dot.className = `w-2.5 h-2.5 rounded-full ${ua.dotClass}`;

      topAiBadge.classList.remove('hidden');
      topAiBadge.className = `badge-pill ${ua.verdictBadgeClass}`;
      topAiBadge.textContent = ua.verdictLabel;

      const cards = [
        ['AI Provenance Verdict', ua.verdictLabel],
        ['Detection Basis & Evidence', ua.verdictDescription],
        ['AI Generator / Tooling', ua.generator],
        ['AI Model & Version', ua.modelName],
        ['Extracted Prompt / Instructions', ua.positivePrompt],
        ['C2PA & Generation Params', `${ua.c2paStatus}${ua.negativePromptOrParams !== 'None embedded' ? ' | ' + ua.negativePromptOrParams : ''}`]
      ];

      grid.innerHTML = cards.map(([k, v]) => `
        <div class="p-3 rounded-xl bg-slate-900/90 border border-slate-800 flex flex-col gap-1">
          <span class="text-[11px] font-semibold text-purple-300">${escapeHtml(k)}</span>
          <span class="text-xs text-slate-100 mono break-words leading-relaxed">${escapeHtml(v)}</span>
        </div>
      `).join('');
    }

    function renderPhotoIntelligence(report) {
      const panel = document.getElementById('photoIntelligencePanel');
      const grid = document.getElementById('photoPillarsGrid');
      const aiBadge = document.getElementById('aiDetectionBadge');
      const scrubbedBanner = document.getElementById('photoScrubbedBanner');

      if (!report || !report.photoPillars) {
        panel.classList.add('hidden');
        return;
      }

      panel.classList.remove('hidden');
      const isAi = report.photoContext && report.photoContext.aiSummary && report.photoContext.aiSummary.detected;
      aiBadge.classList.remove('hidden');
      if (isAi) {
        aiBadge.className = 'badge-pill bg-purple-500/20 text-purple-300 border border-purple-500/40';
        aiBadge.textContent = '✨ AI-Generated Markers Detected';
      } else {
        aiBadge.className = 'badge-pill bg-sky-500/15 text-sky-300 border border-sky-500/30';
        aiBadge.textContent = '📷 Camera / Authentic Image';
      }

      if (report.isLikelyScrubbedByTransfer) {
        scrubbedBanner.classList.remove('hidden');
        scrubbedBanner.innerHTML = `
          <div class="font-bold text-amber-300 flex items-center gap-1.5">
            <span>⚠️ Forensic Notice — Partial EXIF Scrubbing Detected on This File Copy</span>
          </div>
          <p class="leading-relaxed text-amber-100/90">
            This JPEG contains basic capture timestamps (<span class="mono">${escapeHtml(report.photoContext.exifMap.DateTimeOriginal || report.photoContext.exifMap.ModifyDate || 'present')}</span>) and image dimensions, but the binary contains <strong>zero Camera Make/Model (0x010F/0x0110) and zero GPS IFD (0x8825) tags</strong>.
          </p>
          <p class="leading-relaxed text-amber-200/80">
            <strong>Why this happens:</strong><br>
            1. <strong>Camera App Location Setting:</strong> Even when phone OS Location is turned on, many Android/iOS Camera apps have a separate internal toggle (<em>Camera Settings → Save Location / Location Tags</em>) that must be enabled.<br>
            2. <strong>Transfer / Picker Privacy Stripping:</strong> Sending a photo via WhatsApp, Telegram, Discord, Email, Phone Link, or selecting via Android's Privacy Photo Picker strips Camera Make/Model and GPS tags while keeping the 17 basic timestamp/resolution tags. Transfer via <strong>USB cable</strong>, <strong>Send as Document / ZIP</strong>, or click <strong>"Snap Device Photo + GPS"</strong> in the top bar to test live hardware + GPS capture.
          </p>
        `;
      } else {
        scrubbedBanner.classList.add('hidden');
      }

      grid.innerHTML = report.photoPillars.map(pillar => `
        <div class="rounded-xl bg-slate-900/90 border border-slate-800 overflow-hidden flex flex-col">
          <div class="px-3.5 py-2 bg-slate-800/70 border-b border-slate-700/70 flex items-center gap-2">
            <span>${pillar.icon}</span>
            <h4 class="text-xs font-bold text-white tracking-wide">${escapeHtml(pillar.title)}</h4>
          </div>
          <div class="p-3 divide-y divide-slate-800/70 text-xs flex-1">
            ${pillar.rows.map(([k, v]) => `
              <div class="py-1.5 first:pt-0 last:pb-0 flex flex-col gap-0.5">
                <span class="text-[11px] font-medium text-slate-400">${escapeHtml(k)}</span>
                <span class="text-xs text-slate-100 mono break-words">${escapeHtml(v)}</span>
              </div>
            `).join('')}
          </div>
        </div>
      `).join('');
    }

    function renderMetadataSectionGroup(items) {
      if (items.length === 0) {
        return `
          <div class="glass-panel rounded-2xl p-8 text-center">
            <p class="text-sm font-semibold text-slate-300">No matching metadata fields found</p>
            <p class="text-xs text-slate-500 mt-1">Try clearing the filter box or switching to another category tab above.</p>
          </div>
        `;
      }

      const groups = new Map();
      for (const item of items) {
        if (!groups.has(item.section)) groups.set(item.section, []);
        groups.get(item.section).push(item);
      }

      let html = '';
      for (const [sectionTitle, rows] of groups.entries()) {
        html += `
          <div class="glass-panel rounded-2xl overflow-hidden">
            <div class="px-4 py-2.5 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between">
              <h3 class="text-xs font-bold uppercase tracking-wider text-sky-400">${escapeHtml(sectionTitle)}</h3>
              <span class="text-[11px] text-slate-400 mono">${rows.length} ${rows.length === 1 ? 'property' : 'properties'}</span>
            </div>
            <div class="divide-y divide-slate-800/70">
              ${rows.map(r => `
                <div class="px-4 py-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-1 sm:gap-4 hover:bg-slate-800/35 transition group">
                  <div class="flex items-center gap-2 sm:w-2/5 shrink-0">
                    <span class="text-xs font-medium text-slate-300">${escapeHtml(r.key)}</span>
                    ${r.tagHex ? `<span class="text-[10px] px-1.5 py-0.2 rounded bg-slate-800 text-slate-400 mono">${escapeHtml(r.tagHex)}</span>` : ''}
                    ${r.isPII ? `<span class="text-[10px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 font-semibold">PII</span>` : ''}
                  </div>
                  <div class="flex items-center justify-between gap-2 sm:w-3/5 min-w-0">
                    <span class="text-xs text-white mono break-all">${escapeHtml(r.value)}</span>
                    <button type="button" data-copy-val="${escapeHtml(r.value)}" class="copy-val-btn opacity-0 group-hover:opacity-100 focus:opacity-100 px-2 py-1 rounded bg-slate-800 hover:bg-sky-500/20 text-[11px] text-slate-300 hover:text-sky-300 border border-slate-700 transition shrink-0">
                      Copy
                    </button>
                  </div>
                </div>
              `).join('')}
            </div>
          </div>
        `;
      }
      return html;
    }

    function renderActiveReport() {
      const emptyBanner = document.getElementById('emptyStateBanner');
      const activeHeader = document.getElementById('activeFileHeader');
      const controls = document.getElementById('explorerControls');
      const contentArea = document.getElementById('metadataContentArea');
      const btnJson = document.getElementById('btnExportJson');
      const btnCsv = document.getElementById('btnExportCsv');
      const btnCopy = document.getElementById('btnCopyAll');

      const report = state.files[state.activeIndex];
      if (!report) {
        emptyBanner.classList.remove('hidden');
        activeHeader.classList.add('hidden');
        controls.classList.add('hidden');
        contentArea.innerHTML = '';
        btnJson.disabled = true;
        btnCsv.disabled = true;
        btnCopy.disabled = true;
        renderPrivacyAudit(null);
        renderRawVsEditedInspector(null);
        renderUniversalAiInspector(null);
        renderPhotoIntelligence(null);
        return;
      }

      emptyBanner.classList.add('hidden');
      activeHeader.classList.remove('hidden');
      controls.classList.remove('hidden');
      controls.classList.add('flex');
      btnJson.disabled = false;
      btnCsv.disabled = false;
      btnCopy.disabled = false;

      document.getElementById('activeFileName').textContent = report.fileName;
      document.getElementById('activeFormatBadge').textContent = report.magic.format;
      const sigBadge = document.getElementById('signatureMatchBadge');
      if (report.extensionMatchesMagic) {
        sigBadge.className = 'badge-pill bg-emerald-500/15 text-emerald-300 border border-emerald-500/30';
        sigBadge.textContent = 'Signature Verified';
      } else {
        sigBadge.className = 'badge-pill bg-amber-500/20 text-amber-300 border border-amber-500/40';
        sigBadge.textContent = 'Extension Mismatch';
      }

      const sha256Prop = report.forensicsProps.find(p => p.key.includes('SHA-256'));
      document.getElementById('activeFileSub').textContent = `SHA-256: ${sha256Prop ? sha256Prop.value.slice(0, 32) + '…' : 'N/A'} | Magic: 0x${report.magic.magicHex}`;

      const thumb = document.getElementById('filePreviewThumb');
      if (report.thumbUrl) {
        thumb.innerHTML = `<img src="${report.thumbUrl}" alt="Preview" class="w-full h-full object-cover" />`;
      } else {
        thumb.textContent = report.ext.slice(0, 4);
      }

      const allItems = [...report.generalProps, ...report.formatProps, ...report.structureProps, ...report.forensicsProps];
      document.getElementById('totalFieldsCounter').textContent = String(allItems.length);

      document.getElementById('countAll').textContent = String(allItems.length);
      document.getElementById('countFormat').textContent = String(report.generalProps.length + report.formatProps.length);
      document.getElementById('countStructure').textContent = String(report.structureProps.length);
      document.getElementById('countForensics').textContent = String(report.forensicsProps.length);

      const entropyVal = (report.forensicsProps.find(p => p.key.includes('Entropy')) || {}).value || 'N/A';
      const quickCards = [
        { label: 'File Size', value: formatBytes(report.fileSize).split(' (')[0] },
        { label: 'MIME Type', value: report.magic.mime },
        { label: 'Format Specific Tags', value: `${report.formatProps.length} extracted` },
        { label: 'Shannon Entropy', value: entropyVal.split(' — ')[0] }
      ];
      document.getElementById('quickMetricsGrid').innerHTML = quickCards.map(c => `
        <div class="p-3 rounded-xl bg-slate-900/75 border border-slate-800/90">
          <div class="text-[11px] text-slate-400">${escapeHtml(c.label)}</div>
          <div class="text-xs font-semibold text-white mt-0.5 truncate mono">${escapeHtml(c.value)}</div>
        </div>
      `).join('');

      renderPrivacyAudit(report);
      renderRawVsEditedInspector(report);
      renderUniversalAiInspector(report);
      renderPhotoIntelligence(report);

      const q = state.searchQuery.trim().toLowerCase();
      const filterFn = item => !q || item.key.toLowerCase().includes(q) || String(item.value).toLowerCase().includes(q) || item.section.toLowerCase().includes(q);

      if (state.activeTab === 'all') {
        contentArea.innerHTML = renderMetadataSectionGroup(allItems.filter(filterFn));
      } else if (state.activeTab === 'format') {
        contentArea.innerHTML = renderMetadataSectionGroup([...report.generalProps, ...report.formatProps].filter(filterFn));
      } else if (state.activeTab === 'structure') {
        contentArea.innerHTML = renderMetadataSectionGroup(report.structureProps.filter(filterFn));
      } else if (state.activeTab === 'forensics') {
        contentArea.innerHTML = renderMetadataSectionGroup(report.forensicsProps.filter(filterFn));
      } else if (state.activeTab === 'hexdump') {
        contentArea.innerHTML = `
          <div class="glass-panel rounded-2xl overflow-hidden">
            <div class="px-4 py-2.5 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between">
              <h3 class="text-xs font-bold uppercase tracking-wider text-sky-400">Binary Header Hex &amp; ASCII Dump (First 512 Bytes)</h3>
              <span class="text-[11px] text-slate-400 mono">Offset 0x00000000 – 0x00000200</span>
            </div>
            <pre class="p-4 text-[11px] leading-relaxed text-emerald-300 mono overflow-x-auto bg-[#070b12]">${escapeHtml(report.hexHead)}</pre>
          </div>
          ${report.hexTail ? `
            <div class="glass-panel rounded-2xl overflow-hidden">
              <div class="px-4 py-2.5 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between">
                <h3 class="text-xs font-bold uppercase tracking-wider text-indigo-400">Binary Trailer / EOF Hex Dump (Last 256 Bytes)</h3>
              </div>
              <pre class="p-4 text-[11px] leading-relaxed text-indigo-200 mono overflow-x-auto bg-[#070b12]">${escapeHtml(report.hexTail)}</pre>
            </div>
          ` : ''}
          <div class="glass-panel rounded-2xl overflow-hidden">
            <div class="px-4 py-2.5 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between">
              <h3 class="text-xs font-bold uppercase tracking-wider text-amber-400">Extracted Printable ASCII Strings (≥8 chars)</h3>
              <span class="text-[11px] text-slate-400 mono">${report.stringsInfo.printableRuns.length} strings</span>
            </div>
            <div class="p-4 flex flex-wrap gap-1.5 max-h-80 overflow-y-auto bg-[#070b12]">
              ${report.stringsInfo.printableRuns.map(s => `<span class="px-2 py-1 rounded bg-slate-900 border border-slate-800 text-[11px] text-slate-300 mono break-all">${escapeHtml(s)}</span>`).join('')}
            </div>
          </div>
        `;
      } else if (state.activeTab === 'rawjson') {
        const exportObj = buildStructuredExportObject(report);
        contentArea.innerHTML = `
          <div class="glass-panel rounded-2xl overflow-hidden">
            <div class="px-4 py-2.5 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between">
              <h3 class="text-xs font-bold uppercase tracking-wider text-sky-400">Complete Structured JSON Metadata Object</h3>
              <button id="btnCopyJsonInline" type="button" class="px-2.5 py-1 rounded bg-sky-500/20 text-sky-300 border border-sky-500/30 text-xs font-semibold hover:bg-sky-500/30 transition">Copy JSON</button>
            </div>
            <pre class="p-4 text-xs leading-relaxed text-slate-200 mono overflow-x-auto max-h-[540px] bg-[#070b12]">${escapeHtml(JSON.stringify(exportObj, null, 2))}</pre>
          </div>
        `;
        const inlineBtn = document.getElementById('btnCopyJsonInline');
        if (inlineBtn) {
          inlineBtn.addEventListener('click', () => copyTextToClipboard(JSON.stringify(exportObj, null, 2), 'JSON copied to clipboard'));
        }
      }
    }

    function buildStructuredExportObject(report) {
      const grouped = {};
      const all = [...report.generalProps, ...report.formatProps, ...report.structureProps, ...report.forensicsProps];
      for (const item of all) {
        if (!grouped[item.section]) grouped[item.section] = {};
        grouped[item.section][item.key] = item.value;
      }
      const out = {
        metaFinderVersion: '3.0-Offline',
        extractedAt: new Date().toISOString(),
        fileName: report.fileName,
        fileSize: report.fileSize,
        detectedFormat: report.magic.format,
        mimeType: report.magic.mime,
        signatureVerified: report.extensionMatchesMagic,
        totalFieldsExtracted: all.length
      };
      if (report.photoPillars) {
        out.photographIntelligence = {};
        for (const p of report.photoPillars) {
          out.photographIntelligence[p.title] = Object.fromEntries(p.rows);
        }
      }
      out.metadata = grouped;
      return out;
    }

    async function handleIncomingFiles(fileList) {
      if (!fileList || fileList.length === 0) return;
      try {
        for (const file of Array.from(fileList)) {
          const report = await analyzeFile(file);
          state.files.unshift(report);
          state.activeIndex = 0;
        }
        renderFileQueue();
        renderActiveReport();
        showToast(`Extracted metadata from ${fileList.length} file(s)`, 'success');
      } catch (err) {
        showToast(`Error analyzing file: ${err.message || err}`, 'warn');
      }
    }

    // =========================================================================
    // LIVE CAMERA + GPS CAPTURE MODAL LOGIC
    // =========================================================================
    function stopLiveCaptureStream() {
      if (state.liveStream) {
        state.liveStream.getTracks().forEach(t => t.stop());
        state.liveStream = null;
      }
    }

    async function openLiveCaptureModal() {
      const modal = document.getElementById('liveCaptureModal');
      const video = document.getElementById('captureVideoPreview');
      const statusEl = document.getElementById('captureStatusOverlay');
      modal.classList.remove('hidden');
      modal.classList.add('flex');
      statusEl.textContent = 'Requesting camera & live GPS coordinates...';

      // Request Geolocation
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          pos => {
            state.liveGeo = pos.coords;
            statusEl.textContent = `GPS Lock: ${pos.coords.latitude.toFixed(5)}, ${pos.coords.longitude.toFixed(5)} (Alt: ${(pos.coords.altitude || 9.5).toFixed(1)}m)`;
          },
          () => {
            state.liveGeo = { latitude: 22.5075, longitude: 88.2464, altitude: 9.4 };
            statusEl.textContent = 'Using fallback GPS coordinates (Browser geolocation permission declined or unavailable)';
          },
          { enableHighAccuracy: true, timeout: 4000 }
        );
      } else {
        state.liveGeo = { latitude: 22.5075, longitude: 88.2464, altitude: 9.4 };
      }

      try {
        if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
          state.liveStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' }, audio: false });
          video.srcObject = state.liveStream;
        } else {
          statusEl.textContent = 'Camera stream unavailable in sandbox — will synthesize device frame with live GPS & hardware profile.';
        }
      } catch (e) {
        statusEl.textContent = 'Camera stream unavailable in sandbox — will synthesize device frame with live GPS & hardware profile.';
      }
    }

    function closeLiveCaptureModal() {
      stopLiveCaptureStream();
      const modal = document.getElementById('liveCaptureModal');
      modal.classList.add('hidden');
      modal.classList.remove('flex');
    }

    async function snapAndInspectLivePhoto() {
      const geo = state.liveGeo || { latitude: 22.5075, longitude: 88.2464, altitude: 9.4 };
      const ua = navigator.userAgent || 'Browser Device';
      let make = 'Browser / Device Camera';
      let model = navigator.platform || 'Web Client Hardware';
      if (/Android/i.test(ua)) { make = 'Android Device'; model = (ua.match(/Android\s+[^;)]+;\s*([^)]+)\)/) || [null, 'Android Smartphone'])[1]; }
      else if (/iPhone|iPad/i.test(ua)) { make = 'Apple Inc.'; model = 'iPhone / iOS Camera'; }
      else if (/Windows/i.test(ua)) { make = 'Windows PC Camera'; model = 'UVC Integrated Webcam'; }
      else if (/Macintosh/i.test(ua)) { make = 'Apple Inc.'; model = 'FaceTime HD Camera'; }

      const file = await buildSampleAndroidBigEndianPhoto(geo.latitude, geo.longitude, geo.altitude || 9.4, make, model);
      closeLiveCaptureModal();
      await handleIncomingFiles([file]);
    }

    // =========================================================================
    // EVENT LISTENERS INITIALIZATION
    // =========================================================================
    window.addEventListener('DOMContentLoaded', () => {
      const fileInput = document.getElementById('fileInput');
      const dropZone = document.getElementById('dropZone');
      const sampleDrawer = document.getElementById('sampleDrawer');

      document.getElementById('btnOpenFilePicker').addEventListener('click', () => fileInput.click());
      dropZone.addEventListener('click', () => fileInput.click());

      document.getElementById('btnLiveCapture').addEventListener('click', openLiveCaptureModal);
      document.getElementById('btnCloseCaptureModal').addEventListener('click', closeLiveCaptureModal);
      document.getElementById('btnCancelCapture').addEventListener('click', closeLiveCaptureModal);
      document.getElementById('btnSnapAndInspect').addEventListener('click', snapAndInspectLivePhoto);

      fileInput.addEventListener('change', e => {
        if (e.target.files.length > 0) {
          handleIncomingFiles(e.target.files);
          fileInput.value = '';
        }
      });

      ['dragenter', 'dragover'].forEach(evt => {
        dropZone.addEventListener(evt, e => {
          e.preventDefault();
          e.stopPropagation();
          dropZone.classList.add('drop-active');
        });
      });
      ['dragleave', 'drop'].forEach(evt => {
        dropZone.addEventListener(evt, e => {
          e.preventDefault();
          e.stopPropagation();
          dropZone.classList.remove('drop-active');
        });
      });
      dropZone.addEventListener('drop', e => {
        if (e.dataTransfer && e.dataTransfer.files.length > 0) {
          handleIncomingFiles(e.dataTransfer.files);
        }
      });

      document.getElementById('btnToggleSamples').addEventListener('click', () => {
        sampleDrawer.classList.toggle('hidden');
      });

      document.querySelectorAll('.sample-btn').forEach(btn => {
        btn.addEventListener('click', async () => {
          const kind = btn.getAttribute('data-sample');
          let sampleFile = null;
          if (kind === 'jpeg') sampleFile = await buildSampleJpegWithExifAndGps();
          else if (kind === 'androidmm') sampleFile = await buildSampleAndroidBigEndianPhoto();
          else if (kind === 'aiphoto') sampleFile = await buildSampleAiGeneratedPhoto();
          else if (kind === 'pdf') sampleFile = buildSamplePdfDocument();
          else if (kind === 'docx') sampleFile = buildSampleDocx();
          else if (kind === 'pptx') sampleFile = buildSamplePptx();
          else if (kind === 'doc') sampleFile = buildSampleLegacyDoc();
          else if (kind === 'epub') sampleFile = buildSampleEpub();
          else if (kind === 'mp4') sampleFile = buildSampleMp4();
          else if (kind === 'aimp4') sampleFile = buildSampleAiVideoMp4();
          else if (kind === 'editedmp4') sampleFile = buildSampleEditedVideoMp4();
          else if (kind === 'editedwav') sampleFile = buildSampleEditedWavAudio();
          else if (kind === 'csv') sampleFile = buildSampleCsv();
          if (sampleFile) {
            await handleIncomingFiles([sampleFile]);
          }
        });
      });

      document.getElementById('fileQueueList').addEventListener('click', e => {
        const removeBtn = e.target.closest('.remove-queue-btn');
        if (removeBtn) {
          e.stopPropagation();
          const rmIdx = parseInt(removeBtn.getAttribute('data-remove-idx'), 10);
          state.files.splice(rmIdx, 1);
          if (state.activeIndex >= state.files.length) state.activeIndex = state.files.length - 1;
          renderFileQueue();
          renderActiveReport();
          return;
        }
        const itemEl = e.target.closest('.queue-item');
        if (itemEl) {
          state.activeIndex = parseInt(itemEl.getAttribute('data-queue-idx'), 10);
          renderFileQueue();
          renderActiveReport();
        }
      });

      document.getElementById('btnClearQueue').addEventListener('click', () => {
        state.files = [];
        state.activeIndex = -1;
        renderFileQueue();
        renderActiveReport();
        showToast('Cleared file queue', 'info');
      });

      document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
          btn.classList.add('active');
          state.activeTab = btn.getAttribute('data-tab');
          renderActiveReport();
        });
      });

      const searchInput = document.getElementById('searchFilterInput');
      const clearSearchBtn = document.getElementById('btnClearSearch');
      searchInput.addEventListener('input', () => {
        state.searchQuery = searchInput.value;
        clearSearchBtn.classList.toggle('hidden', !state.searchQuery);
        renderActiveReport();
      });
      clearSearchBtn.addEventListener('click', () => {
        searchInput.value = '';
        state.searchQuery = '';
        clearSearchBtn.classList.add('hidden');
        renderActiveReport();
      });

      document.getElementById('metadataContentArea').addEventListener('click', e => {
        const copyBtn = e.target.closest('.copy-val-btn');
        if (copyBtn) {
          const val = copyBtn.getAttribute('data-copy-val');
          copyTextToClipboard(val, 'Value copied to clipboard');
        }
      });

      document.getElementById('btnExportJson').addEventListener('click', () => {
        const report = state.files[state.activeIndex];
        if (!report) return;
        const jsonStr = JSON.stringify(buildStructuredExportObject(report), null, 2);
        const blob = new Blob([jsonStr], { type: 'application/json' });
        triggerDownloadBlob(blob, `${report.fileName}.metadata.json`);
        showToast('Exported JSON metadata report', 'success');
      });

      document.getElementById('btnExportCsv').addEventListener('click', () => {
        const report = state.files[state.activeIndex];
        if (!report) return;
        const all = [...report.generalProps, ...report.formatProps, ...report.structureProps, ...report.forensicsProps];
        const rows = [['Section', 'Property Key', 'Value', 'PII Flag']];
        for (const r of all) {
          rows.push([
            `"${String(r.section).replace(/"/g, '""')}"`,
            `"${String(r.key).replace(/"/g, '""')}"`,
            `"${String(r.value).replace(/"/g, '""')}"`,
            r.isPII ? 'Yes' : 'No'
          ]);
        }
        const csvContent = rows.map(r => r.join(',')).join('\n');
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8' });
        triggerDownloadBlob(blob, `${report.fileName}.metadata.csv`);
        showToast('Exported CSV metadata table', 'success');
      });

      document.getElementById('btnCopyAll').addEventListener('click', () => {
        const report = state.files[state.activeIndex];
        if (!report) return;
        const all = [...report.generalProps, ...report.formatProps, ...report.structureProps, ...report.forensicsProps];
        const lines = [
          `=== META FINDER REPORT: ${report.fileName} ===`,
          `Format: ${report.magic.format} (${report.magic.mime})`,
          `Size: ${formatBytes(report.fileSize)}`,
          ''
        ];
        if (report.photoPillars) {
          lines.push('--- PHOTOGRAPH EXPLICIT INTELLIGENCE (6 PILLARS) ---');
          for (const p of report.photoPillars) {
            lines.push(`[${p.title}]`);
            for (const [k, v] of p.rows) {
              lines.push(`  • ${k}: ${v}`);
            }
          }
          lines.push('');
        }
        for (const r of all) {
          lines.push(`[${r.section}] ${r.key}: ${r.value}`);
        }
        copyTextToClipboard(lines.join('\n'), 'Full metadata report copied to clipboard');
      });

      // Auto-load the rich Camera Photo sample on startup
      buildSampleJpegWithExifAndGps().then(sample => handleIncomingFiles([sample]));
    });