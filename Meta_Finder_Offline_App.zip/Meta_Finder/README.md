# Meta Finder — 100% Offline Universal Document & Media Metadata Inspector

Meta Finder is a standalone, zero-backend browser application that extracts binary, structural, and format-specific metadata locally in memory without uploading files anywhere.

## Quick Start (Offline Usage)
1. Extract this ZIP archive anywhere on your computer or phone.
2. Open **`meta_finder.html`** (or **`index.html`**) directly in any modern browser (Chrome, Edge, Firefox, Brave, Safari).
3. Drag and drop any file(s) onto the dropzone, click **Inspect Local File(s)**, or click **Snap Device Photo + GPS**.

## Key Capabilities
- **Photograph 6-Pillar Intelligence:**
  1. **Camera & Device Info:** Make, model, lens make/model/specs, exposure triad, firmware/software version, body/lens serial numbers, and vendor MakerNote strings (supports both Intel Little-Endian `II` and Motorola Big-Endian `MM`).
  2. **Capture & Digitized Timestamps:** Exact date/time taken (`DateTimeOriginal`), digitized (`DateTimeDigitized`), and modified (`ModifyDate`), with sub-second precision and timezone offsets.
  3. **GPS Geolocation:** Decimal & DMS latitude/longitude, altitude (m above/below sea level), UTC satellite timestamp, heading, speed, and geodetic datum.
  4. **Creator, Copyright & Licensing:** Photographer/Artist (`Artist`, `dc:creator`, IPTC `By-line`), copyright notice, credit/source, and usage rights/licensing URLs.
  5. **Software & Edit History Logs:** Editing app & version (Lightroom, Photoshop, GIMP, Snapseed, etc.), step-by-step XMP `stEvt` edit history log, and Camera Raw (`crs:*`) parametric adjustments.
  6. **AI-Generation Markers & Prompts:** Detects C2PA / Content Credentials (`c2pa`, `jumb`, `caBX`), IPTC `trainedAlgorithmicMedia`, Stable Diffusion (`parameters`), ComfyUI node-graph JSON workflows, and Midjourney flags.
- **Raw / Unedited vs. Software-Edited Authenticity Inspector (Photos, Videos & Audio):**
  Distinguishes direct-from-camera/recorder captures from files modified by photo editors, video NLEs/apps (Premiere Pro, Final Cut, DaVinci Resolve, CapCut, FFmpeg), or audio DAWs (Audacity, Adobe Audition, Pro Tools, Logic Pro, iZotope RX).
- **Universal AI Provenance Detection (All File Types):**
  Inspects Photos, Videos (Sora, Runway, Veo, Luma, Pika, Kling, ComfyUI Video), Audio (Suno, Udio, ElevenLabs), PDFs, Word (`.docx`/`.doc`), PowerPoint (`.pptx`), Excel (`.xlsx`), EPUBs, and CSV/JSON datasets for AI generation signatures and programmatic library footprints.
- **Universal Binary Forensics:**
  SHA-256, SHA-1, MD5, and CRC32 checksums, Shannon entropy calculation, Magic Byte signature verification, Privacy/PII audit, Hex/ASCII header & trailer dump, and JSON/CSV report export.

## Included Files
- `meta_finder.html` / `index.html` — Complete self-contained single-file application (ready to open directly offline).
- `src/app.js` — Extracted JavaScript metadata parsing & UI engine.
- `src/styles.css` — Extracted stylesheet.
